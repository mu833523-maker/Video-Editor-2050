package com.ve2050.editor.ui.text

import android.content.Context
import android.graphics.Typeface
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.ve2050.editor.model.TextFontFamily
import com.ve2050.editor.model.TextOverlay
import com.ve2050.editor.model.TextPreset

object TextDesignHelper {

    val PRO_COLORS = listOf(
        0xFFFFFFFF.toInt() to "Classic White",
        0xFF00E5FF.toInt() to "Cyber Cyan",
        0xFFFFD700.toInt() to "Royal Gold",
        0xFFFF007F.toInt() to "Neon Pink",
        0xFF00FF88.toInt() to "Emerald Glow",
        0xFFFF334B.toInt() to "Crimson Red",
        0xFFFF8C00.toInt() to "Electric Orange",
        0xFFA855F7.toInt() to "Vibrant Purple",
        0xFF38BDF8.toInt() to "Sky Blue",
        0xFFFFFF00.toInt() to "Sun Yellow",
        0xFFE0F7FA.toInt() to "Frost Silver",
        0xFF121216.toInt() to "Onyx Black"
    )

    val URDU_QUICK_PHRASES = listOf(
        "خوش آمدید",
        "زندگی ایک خوبصورت سفر ہے",
        "سبسکرائب کریں",
        "اردو شاعری",
        "دلکش مناظر",
        "محبت اور سکون",
        "New Vlog 2026",
        "CapCut Pro Effect"
    )

    @Composable
    fun getComposeFontFamily(fontFamily: TextFontFamily): FontFamily {
        return when (fontFamily) {
            TextFontFamily.URDU_NASTALIQ, TextFontFamily.ARABIC_URDU -> {
                FontFamily(Font(R.font.noto_nastaliq_urdu))
            }
            TextFontFamily.BEBAS_HEADLINE -> {
                FontFamily(Font(R.font.bebas_neue))
            }
            TextFontFamily.MONTSERRAT -> {
                FontFamily(Font(R.font.montserrat))
            }
            TextFontFamily.PACIFICO_SCRIPT, TextFontFamily.CURSIVE -> {
                FontFamily(Font(R.font.pacifico))
            }
            TextFontFamily.SERIF -> FontFamily.Serif
            TextFontFamily.MONOSPACE -> FontFamily.Monospace
            TextFontFamily.SANS_SERIF -> FontFamily.SansSerif
        }
    }

    fun getTypeface(
        context: Context,
        fontFamily: TextFontFamily,
        isBold: Boolean = false,
        isItalic: Boolean = false
    ): Typeface {
        val base: Typeface = when (fontFamily) {
            TextFontFamily.URDU_NASTALIQ, TextFontFamily.ARABIC_URDU -> {
                try {
                    ResourcesCompat.getFont(context, R.font.noto_nastaliq_urdu) ?: Typeface.DEFAULT
                } catch (e: Exception) {
                    Typeface.DEFAULT
                }
            }
            TextFontFamily.BEBAS_HEADLINE -> {
                try {
                    ResourcesCompat.getFont(context, R.font.bebas_neue) ?: Typeface.DEFAULT_BOLD
                } catch (e: Exception) {
                    Typeface.DEFAULT_BOLD
                }
            }
            TextFontFamily.MONTSERRAT -> {
                try {
                    ResourcesCompat.getFont(context, R.font.montserrat) ?: Typeface.SANS_SERIF
                } catch (e: Exception) {
                    Typeface.SANS_SERIF
                }
            }
            TextFontFamily.PACIFICO_SCRIPT, TextFontFamily.CURSIVE -> {
                try {
                    ResourcesCompat.getFont(context, R.font.pacifico) ?: Typeface.create("cursive", Typeface.NORMAL)
                } catch (e: Exception) {
                    Typeface.create("cursive", Typeface.NORMAL)
                }
            }
            TextFontFamily.SERIF -> Typeface.SERIF
            TextFontFamily.MONOSPACE -> Typeface.MONOSPACE
            TextFontFamily.SANS_SERIF -> Typeface.SANS_SERIF
        }

        val style = when {
            isBold && isItalic -> Typeface.BOLD_ITALIC
            isBold -> Typeface.BOLD
            isItalic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        return Typeface.create(base, style)
    }

    fun applyPreset(overlay: TextOverlay, preset: TextPreset): TextOverlay {
        return when (preset) {
            TextPreset.NONE -> overlay.copy(
                preset = preset,
                color = 0xFFFFFFFF.toInt(),
                strokeWidth = 0f,
                hasShadow = true,
                shadowColor = 0xAA000000.toInt(),
                hasBackground = false
            )
            TextPreset.URDU_NASTALIQ -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.URDU_NASTALIQ,
                color = 0xFFFFFFFF.toInt(),
                strokeWidth = 0f,
                hasShadow = true,
                shadowColor = 0xCC000000.toInt(),
                shadowRadius = 12f,
                hasBackground = true,
                backgroundColor = 0x66000000.toInt(),
                isRtl = true
            )
            TextPreset.CYBER_NEON -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.BEBAS_HEADLINE,
                color = 0xFF00E5FF.toInt(),
                strokeWidth = 2f,
                strokeColor = 0xFFFF007F.toInt(),
                hasShadow = true,
                shadowColor = 0xFFFF007F.toInt(),
                shadowRadius = 25f,
                hasBackground = false
            )
            TextPreset.QUANTUM_GLITCH -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.BEBAS_HEADLINE,
                color = 0xFF00FFFF.toInt(),
                strokeWidth = 1f,
                strokeColor = 0xFFFF0055.toInt(),
                hasShadow = true,
                shadowColor = 0xFFFF0055.toInt(),
                shadowRadius = 18f,
                hasBackground = false
            )
            TextPreset.GOLDEN_METALLIC -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.SERIF,
                color = 0xFFFFD700.toInt(),
                strokeWidth = 1.5f,
                strokeColor = 0xFF4A3500.toInt(),
                hasShadow = true,
                shadowColor = 0xFF4A3500.toInt(),
                shadowRadius = 16f,
                hasBackground = false
            )
            TextPreset.RETRO_SYNTHWAVE -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.PACIFICO_SCRIPT,
                color = 0xFFFF007F.toInt(),
                strokeWidth = 1.5f,
                strokeColor = 0xFF7928CA.toInt(),
                hasShadow = true,
                shadowColor = 0xFF7928CA.toInt(),
                shadowRadius = 20f,
                hasBackground = false
            )
            TextPreset.HOLO_OUTLINE -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.BEBAS_HEADLINE,
                color = 0xFF00E5FF.toInt(),
                strokeWidth = 4f,
                strokeColor = 0xFF00E5FF.toInt(),
                hasShadow = true,
                shadowColor = 0xFF00E5FF.toInt(),
                shadowRadius = 14f,
                hasBackground = false
            )
            TextPreset.DEEP_SHADOW -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.BEBAS_HEADLINE,
                color = 0xFFFFFFFF.toInt(),
                strokeWidth = 0f,
                hasShadow = true,
                shadowColor = 0xFF000000.toInt(),
                shadowRadius = 24f,
                hasBackground = false
            )
            TextPreset.EMERALD_MATRIX -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.MONOSPACE,
                color = 0xFF00FF88.toInt(),
                strokeWidth = 1f,
                strokeColor = 0xFF003311.toInt(),
                hasShadow = true,
                shadowColor = 0xFF00FF66.toInt(),
                shadowRadius = 18f,
                hasBackground = false
            )
            TextPreset.FIRE_BLAZE -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.BEBAS_HEADLINE,
                color = 0xFFFF8C00.toInt(),
                strokeWidth = 1.5f,
                strokeColor = 0xFFFF2200.toInt(),
                hasShadow = true,
                shadowColor = 0xFFFF4500.toInt(),
                shadowRadius = 22f,
                hasBackground = false
            )
            TextPreset.CHROME_FROST -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.MONTSERRAT,
                color = 0xFFE0F7FA.toInt(),
                strokeWidth = 1.5f,
                strokeColor = 0xFF004466.toInt(),
                hasShadow = true,
                shadowColor = 0xFF006699.toInt(),
                shadowRadius = 16f,
                hasBackground = false
            )
            TextPreset.MINIMAL_CAPTION -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.MONTSERRAT,
                color = 0xFFFFFFFF.toInt(),
                strokeWidth = 0f,
                hasShadow = false,
                hasBackground = true,
                backgroundColor = 0xBB111118.toInt()
            )
            TextPreset.NEWS_BANNER -> overlay.copy(
                preset = preset,
                fontFamily = TextFontFamily.BEBAS_HEADLINE,
                color = 0xFFFFEB3B.toInt(),
                strokeWidth = 0f,
                hasShadow = true,
                shadowColor = 0x99000000.toInt(),
                hasBackground = true,
                backgroundColor = 0xEECC0000.toInt()
            )
        }
    }
}
