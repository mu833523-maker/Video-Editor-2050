package com.ve2050.editor.ui.text

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.ve2050.editor.model.TextFontFamily
import com.ve2050.editor.model.TextKeyframe
import com.ve2050.editor.model.TextOverlay
import com.ve2050.editor.model.TextPreset
import kotlin.math.roundToInt

enum class TextStudioTab(val title: String, val icon: String) {
    TEXT("Text", "✏️"),
    FONTS("Fonts", "🔤"),
    STYLE("Colors & Style", "🎨"),
    PRESETS("Presets", "✨"),
    KEYFRAMES("Keyframes", "♦")
}

@Composable
fun TextProStudioDialog(
    initialOverlay: TextOverlay?,
    currentPlayheadMs: Long,
    onDismiss: () -> Unit,
    onSave: (TextOverlay) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    var overlay by remember {
        mutableStateOf(
            initialOverlay ?: TextOverlay(
                text = "خوش آمدید",
                startMs = currentPlayheadMs,
                endMs = currentPlayheadMs + 4000L
            )
        )
    }

    var selectedTab by remember { mutableStateOf(TextStudioTab.TEXT) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(24.dp)),
            color = Color(0xFF10121A),
            border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(0xFF00E5FF).copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Top Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF00E5FF).copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("T", color = Color(0xFF00E5FF), fontWeight = FontWeight.Black, fontSize = 18.sp)
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (initialOverlay == null) "Add Pro Text" else "Edit Pro Text",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Urdu, English, Styles & Keyframes",
                                color = Color(0xFF00E5FF),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (onDelete != null && initialOverlay != null) {
                            IconButton(
                                onClick = onDelete,
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(Color(0xFF33141E), CircleShape)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFFF4D6D), modifier = Modifier.size(18.dp))
                            }
                        }
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(38.dp)
                                .background(Color(0xFF20222E), CircleShape)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Live Preview Canvas Card
                val composeFont = TextDesignHelper.getComposeFontFamily(overlay.fontFamily)
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF08090E),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26293A))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Background pill if enabled
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (overlay.hasBackground) Color(overlay.backgroundColor) else Color.Transparent
                                )
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (overlay.text.isBlank()) "Preview Text" else overlay.text,
                                fontFamily = composeFont,
                                fontSize = (overlay.sizeSp * 0.75f).coerceIn(12f, 32f).sp,
                                fontWeight = if (overlay.isBold) FontWeight.Bold else FontWeight.Normal,
                                fontStyle = if (overlay.isItalic) FontStyle.Italic else FontStyle.Normal,
                                textDecoration = if (overlay.isUnderline) TextDecoration.Underline else TextDecoration.None,
                                color = Color(overlay.color),
                                textAlign = if (overlay.isRtl) TextAlign.Right else TextAlign.Center,
                                maxLines = 2
                            )
                        }

                        // Presets & Keyframe Badge indicator at bottom
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (overlay.keyframes.isNotEmpty()) {
                                Surface(
                                    color = Color(0xFF00E5FF).copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        "♦ ${overlay.keyframes.size} Keyframes",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Surface(
                                color = Color(0xFF25293A),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    overlay.fontFamily.displayName.split(" ").first(),
                                    color = Color(0xFFAAAAAA),
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Navigation Tabs (Horizontal Scrollable)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TextStudioTab.values().forEach { tab ->
                        val isSelected = (selectedTab == tab)
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedTab = tab },
                            label = {
                                Text(
                                    "${tab.icon} ${tab.title}",
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF00E5FF),
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0xFF1B1E2B),
                                labelColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) Color(0xFF00E5FF) else Color(0xFF2D3247)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Tab Content Area
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (selectedTab) {
                        TextStudioTab.TEXT -> {
                            TabTextInput(
                                overlay = overlay,
                                onTextChange = { newText ->
                                    val rtl = com.ve2050.editor.model.isRtlText(newText)
                                    overlay = overlay.copy(
                                        text = newText,
                                        isRtl = rtl,
                                        fontFamily = if (rtl && overlay.fontFamily == TextFontFamily.SANS_SERIF) {
                                            TextFontFamily.URDU_NASTALIQ
                                        } else overlay.fontFamily
                                    )
                                }
                            )
                        }
                        TextStudioTab.FONTS -> {
                            TabFonts(
                                currentFont = overlay.fontFamily,
                                onFontSelect = { newFont ->
                                    overlay = overlay.copy(fontFamily = newFont)
                                }
                            )
                        }
                        TextStudioTab.STYLE -> {
                            TabColorsAndStyle(
                                overlay = overlay,
                                onUpdate = { overlay = it }
                            )
                        }
                        TextStudioTab.PRESETS -> {
                            TabPresets(
                                currentPreset = overlay.preset,
                                onSelectPreset = { preset ->
                                    overlay = TextDesignHelper.applyPreset(overlay, preset)
                                }
                            )
                        }
                        TextStudioTab.KEYFRAMES -> {
                            TabKeyframes(
                                overlay = overlay,
                                currentPlayheadMs = currentPlayheadMs,
                                onUpdate = { overlay = it }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Action Buttons (Done / Save)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFAAAAAA)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333348))
                    ) {
                        Text("Cancel", fontSize = 14.sp)
                    }

                    Button(
                        onClick = {
                            if (overlay.text.isNotBlank()) {
                                onSave(overlay)
                            }
                            onDismiss()
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00E5FF),
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (initialOverlay == null) "ADD TO TIMELINE" else "APPLY CHANGES",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TabTextInput(
    overlay: TextOverlay,
    onTextChange: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        OutlinedTextField(
            value = overlay.text,
            onValueChange = onTextChange,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 100.dp),
            placeholder = { Text("اردو یا English میں لکھیں...", color = Color(0xFF666680)) },
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedBorderColor = Color(0xFF00E5FF),
                unfocusedBorderColor = Color(0xFF2A2D3E),
                focusedContainerColor = Color(0xFF151824),
                unfocusedContainerColor = Color(0xFF151824)
            )
        )

        Spacer(Modifier.height(14.dp))

        Text(
            "QUICK URDU & TITLE TEMPLATES",
            color = Color(0xFF00E5FF),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TextDesignHelper.URDU_QUICK_PHRASES.chunked(2).forEach { rowPhrases ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    rowPhrases.forEach { phrase ->
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onTextChange(phrase) },
                            color = Color(0xFF1B1E2B),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A2E44))
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = phrase,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabFonts(
    currentFont: TextFontFamily,
    onFontSelect: (TextFontFamily) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "CHOOSE TYPOGRAPHY (URDU & LATIN)",
            color = Color(0xFF00E5FF),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        TextFontFamily.values().forEach { font ->
            val isSelected = (currentFont == font)
            val composeFont = TextDesignHelper.getComposeFontFamily(font)

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onFontSelect(font) },
                color = if (isSelected) Color(0xFF102838) else Color(0xFF171924),
                border = androidx.compose.foundation.BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF2A2D3E)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = font.displayName,
                            color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = when (font) {
                                TextFontFamily.URDU_NASTALIQ, TextFontFamily.ARABIC_URDU -> "خوش آمدید پاکستان / شاعری"
                                TextFontFamily.BEBAS_HEADLINE -> "BOLD ACTION TITLE 2026"
                                TextFontFamily.MONTSERRAT -> "Clean Minimalist Studio"
                                TextFontFamily.PACIFICO_SCRIPT, TextFontFamily.CURSIVE -> "Creative Signature Script"
                                TextFontFamily.SERIF -> "Cinematic Hollywood Drama"
                                TextFontFamily.MONOSPACE -> "0101 Tech Matrix Code"
                                TextFontFamily.SANS_SERIF -> "Everyday Mobile Sans"
                            },
                            fontFamily = composeFont,
                            color = Color(0xFFAAAAAA),
                            fontSize = 13.sp,
                            maxLines = 1
                        )
                    }

                    if (isSelected) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF00E5FF),
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabColorsAndStyle(
    overlay: TextOverlay,
    onUpdate: (TextOverlay) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Color Palette
        Text(
            "PRIMARY COLOR",
            color = Color(0xFF00E5FF),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextDesignHelper.PRO_COLORS.forEach { (colorInt, name) ->
                val isSelected = (overlay.color == colorInt)
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(colorInt))
                        .border(
                            width = if (isSelected) 3.dp else 1.dp,
                            color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF444455),
                            shape = CircleShape
                        )
                        .clickable { onUpdate(overlay.copy(color = colorInt)) },
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = name,
                            tint = if (colorInt == 0xFFFFFFFF.toInt() || colorInt == 0xFFFFD700.toInt() || colorInt == 0xFF00E5FF.toInt()) Color.Black else Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Text Size Slider
        Text(
            "FONT SIZE (${overlay.sizeSp.roundToInt()}sp)",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
        Slider(
            value = overlay.sizeSp,
            onValueChange = { onUpdate(overlay.copy(sizeSp = it)) },
            valueRange = 14f..64f,
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF00E5FF),
                activeTrackColor = Color(0xFF00E5FF),
                inactiveTrackColor = Color(0xFF222436)
            )
        )

        Spacer(Modifier.height(10.dp))

        // Formatting Toggles (Bold, Italic, RTL, Alignment)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = overlay.isBold,
                onClick = { onUpdate(overlay.copy(isBold = !overlay.isBold)) },
                label = { Text("Bold (B)", fontWeight = FontWeight.Bold) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF00E5FF),
                    selectedLabelColor = Color.Black
                ),
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = overlay.isItalic,
                onClick = { onUpdate(overlay.copy(isItalic = !overlay.isItalic)) },
                label = { Text("Italic (I)", fontStyle = FontStyle.Italic) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF00E5FF),
                    selectedLabelColor = Color.Black
                ),
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = overlay.isRtl,
                onClick = { onUpdate(overlay.copy(isRtl = !overlay.isRtl)) },
                label = { Text("RTL اردو") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFF00E5FF),
                    selectedLabelColor = Color.Black
                ),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(16.dp))

        // Stroke / Outline Design
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("TEXT OUTLINE (STROKE)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Outline width: ${overlay.strokeWidth.roundToInt()}px", color = Color(0xFFAAAAAA), fontSize = 11.sp)
            }
            Switch(
                checked = overlay.strokeWidth > 0f,
                onCheckedChange = { checked ->
                    onUpdate(overlay.copy(strokeWidth = if (checked) 2.5f else 0f))
                },
                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E5FF))
            )
        }
        if (overlay.strokeWidth > 0f) {
            Slider(
                value = overlay.strokeWidth,
                onValueChange = { onUpdate(overlay.copy(strokeWidth = it)) },
                valueRange = 0.5f..8f,
                colors = SliderDefaults.colors(
                    thumbColor = Color(0xFF00E5FF),
                    activeTrackColor = Color(0xFF00E5FF)
                )
            )
        }

        Spacer(Modifier.height(12.dp))

        // Background Pill Box Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("BACKGROUND PILL", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Readable caption backdrop", color = Color(0xFFAAAAAA), fontSize = 11.sp)
            }
            Switch(
                checked = overlay.hasBackground,
                onCheckedChange = { checked ->
                    onUpdate(overlay.copy(hasBackground = checked))
                },
                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E5FF))
            )
        }

        Spacer(Modifier.height(12.dp))

        // Drop Shadow Toggle
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("3D DROP SHADOW", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("Depth blur and contrast", color = Color(0xFFAAAAAA), fontSize = 11.sp)
            }
            Switch(
                checked = overlay.hasShadow,
                onCheckedChange = { checked ->
                    onUpdate(overlay.copy(hasShadow = checked))
                },
                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF00E5FF))
            )
        }
    }
}

@Composable
private fun TabPresets(
    currentPreset: TextPreset,
    onSelectPreset: (TextPreset) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            "CAPCUT PRO DESIGN PRESETS",
            color = Color(0xFF00E5FF),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        TextPreset.values().forEach { preset ->
            val isSelected = (currentPreset == preset)

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onSelectPreset(preset) },
                color = if (isSelected) Color(0xFF132A38) else Color(0xFF171A26),
                border = androidx.compose.foundation.BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF2A2D3E)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(preset.badge, fontSize = 22.sp)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            preset.displayName,
                            color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }

                    if (isSelected) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF00E5FF),
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabKeyframes(
    overlay: TextOverlay,
    currentPlayheadMs: Long,
    onUpdate: (TextOverlay) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // CapCut Keyframe Info Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF0C1B26),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f))
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("♦", color = Color(0xFF00E5FF), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        "CapCut Keyframe Animation System",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Playhead waqt: ${String.format("%.2f", currentPlayheadMs / 1000f)}s par keyframe set karein. Video chalti hui text ko move aur animate karegi.",
                        color = Color(0xFFAAAAAA),
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // Check if there is already a keyframe near currentPlayheadMs
        val existingNearIndex = overlay.keyframes.indexOfFirst {
            kotlin.math.abs(it.timeMs - currentPlayheadMs) < 300L
        }

        // Add / Remove Keyframe Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val newKf = TextKeyframe(
                        timeMs = currentPlayheadMs,
                        x = overlay.x,
                        y = overlay.y,
                        scale = overlay.scale,
                        rotation = overlay.rotation,
                        opacity = overlay.opacity
                    )
                    val updatedList = (overlay.keyframes.filter {
                        kotlin.math.abs(it.timeMs - currentPlayheadMs) >= 300L
                    } + newKf).sortedBy { it.timeMs }
                    onUpdate(overlay.copy(keyframes = updatedList))
                },
                modifier = Modifier
                    .weight(1f)
                    .height(46.dp),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00E5FF),
                    contentColor = Color.Black
                )
            ) {
                Text("♦ + ADD KEYFRAME", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            if (existingNearIndex >= 0) {
                Button(
                    onClick = {
                        val updatedList = overlay.keyframes.toMutableList().apply {
                            removeAt(existingNearIndex)
                        }
                        onUpdate(overlay.copy(keyframes = updatedList))
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF33141C),
                        contentColor = Color(0xFFFF4D6D)
                    )
                ) {
                    Text("♦ - REMOVE HERE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Text(
            "ACTIVE KEYFRAMES (${overlay.keyframes.size})",
            color = Color(0xFF00E5FF),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(8.dp))

        if (overlay.keyframes.isEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF141724)
            ) {
                Box(
                    modifier = Modifier.padding(18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "Koi keyframe nahi hai. Upar diye button se keyframe add karein.",
                        color = Color(0xFF777788),
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                overlay.keyframes.forEachIndexed { index, kf ->
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF181B28),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C3048))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("♦", color = Color(0xFF00E5FF), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(
                                        "Keyframe #${index + 1} at ${String.format("%.2f", kf.timeMs / 1000f)}s",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        "X:${kf.x.roundToInt()} Y:${kf.y.roundToInt()} Scale:${String.format("%.1f", kf.scale)}x Rot:${kf.rotation.roundToInt()}°",
                                        color = Color(0xFFAAAAAA),
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            IconButton(
                                onClick = {
                                    val list = overlay.keyframes.filter { it.id != kf.id }
                                    onUpdate(overlay.copy(keyframes = list))
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Delete keyframe",
                                    tint = Color(0xFFFF5252),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
