package com.ve2050.editor.ui.text

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ve2050.editor.model.TextKeyframe
import com.ve2050.editor.model.TextOverlay
import kotlin.math.roundToInt

@Composable
fun InteractiveTextOverlayView(
    overlay: TextOverlay,
    currentPositionMs: Long,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onTransformChange: (newX: Float, newY: Float, newScale: Float, newRotation: Float) -> Unit,
    onToggleKeyframe: (timeMs: Long) -> Unit
) {
    // Compute animated transform from keyframes or base properties at current playhead time
    val transform = overlay.getTransformAt(currentPositionMs)
    val composeFont = TextDesignHelper.getComposeFontFamily(overlay.fontFamily)

    val hasKeyframeNear = overlay.keyframes.any {
        kotlin.math.abs(it.timeMs - currentPositionMs) < 350L
    }

    Box(
        modifier = Modifier
            .offset { IntOffset(transform.x.roundToInt(), transform.y.roundToInt()) }
            .graphicsLayer(
                scaleX = transform.scale,
                scaleY = transform.scale,
                rotationZ = transform.rotation,
                alpha = transform.opacity
            )
            .pointerInput(overlay.id) {
                detectTransformGestures { _, pan, zoom, rotation ->
                    val nextScale = (transform.scale * zoom).coerceIn(0.4f, 4.0f)
                    val nextRotation = (transform.rotation + rotation) % 360f
                    val nextX = transform.x + pan.x
                    val nextY = transform.y + pan.y
                    onTransformChange(nextX, nextY, nextScale, nextRotation)
                }
            }
            .clickable { onSelect() }
            .padding(8.dp)
    ) {
        // Selection Bounding Box Container
        Box(
            modifier = Modifier
                .then(
                    if (isSelected) {
                        Modifier
                            .border(
                                width = 1.5.dp,
                                color = Color(0xFF00E5FF),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    } else {
                        Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                    }
                )
        ) {
            // Background Pill if active
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (overlay.hasBackground) Color(overlay.backgroundColor) else Color.Transparent
                    )
                    .then(
                        if (overlay.hasShadow) {
                            Modifier.shadow(
                                elevation = (overlay.shadowRadius / 2f).dp,
                                shape = RoundedCornerShape(8.dp),
                                spotColor = Color(overlay.shadowColor)
                            )
                        } else Modifier
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = overlay.text,
                    fontFamily = composeFont,
                    fontSize = (overlay.sizeSp * 0.7f).coerceIn(12f, 44f).sp,
                    fontWeight = if (overlay.isBold) FontWeight.Bold else FontWeight.Normal,
                    fontStyle = if (overlay.isItalic) FontStyle.Italic else FontStyle.Normal,
                    textDecoration = if (overlay.isUnderline) TextDecoration.Underline else TextDecoration.None,
                    color = Color(overlay.color),
                    textAlign = if (overlay.isRtl) TextAlign.Right else TextAlign.Center,
                    lineHeight = (overlay.sizeSp * 0.85f).sp
                )
            }
        }

        // Overlay Action Handles when selected
        if (isSelected) {
            // Top-Right: Delete button
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 6.dp, y = (-6).dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFCC1133))
                    .clickable { onDelete() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Close, contentDescription = "Delete Text", tint = Color.White, modifier = Modifier.size(14.dp))
            }

            // Top-Left: Edit button
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = (-6).dp, y = (-6).dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00E5FF))
                    .clickable { onEdit() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Edit, contentDescription = "Edit Text", tint = Color.Black, modifier = Modifier.size(13.dp))
            }

            // Bottom-Right: Quick Keyframe diamond badge ♦
            Surface(
                shape = CircleShape,
                color = if (hasKeyframeNear) Color(0xFF00E5FF) else Color(0xFF1E2235),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF)),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 6.dp, y = 6.dp)
                    .size(24.dp)
                    .clickable { onToggleKeyframe(currentPositionMs) }
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = "♦",
                        color = if (hasKeyframeNear) Color.Black else Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            // Bottom-Left: Urdu / Font Badge
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color.Black.copy(alpha = 0.8f),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .offset(x = (-4).dp, y = 6.dp)
            ) {
                Text(
                    text = if (overlay.isRtl) "اردو" else overlay.fontFamily.displayName.split(" ").first(),
                    color = Color(0xFF00E5FF),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }
        }
    }
}
