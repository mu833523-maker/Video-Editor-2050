package com.ve2050.editor.auth

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import coil.compose.AsyncImage
import com.google.firebase.auth.FirebaseUser

@Composable
fun GoogleSignInSection(
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    onUserChanged: (FirebaseUser?) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    LaunchedEffect(Unit) {
        AuthService.isFirebaseReady(context)
    }

    var currentUser by remember { mutableStateOf(AuthService.currentUser) }
    var isLoading by remember { mutableStateOf(false) }
    var showAccountDialog by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val fAuth = AuthService.auth
        if (fAuth != null) {
            val listener = com.google.firebase.auth.FirebaseAuth.AuthStateListener { a ->
                currentUser = a.currentUser
                onUserChanged(a.currentUser)
            }
            fAuth.addAuthStateListener(listener)
            onDispose {
                fAuth.removeAuthStateListener(listener)
            }
        } else {
            onDispose { }
        }
    }

    val user = currentUser
    if (user != null) {
        if (compact) {
            // Compact Profile Avatar with touch target >= 48dp
            Box(
                modifier = modifier
                    .size(48.dp)
                    .clickable { showAccountDialog = true },
                contentAlignment = Alignment.Center
            ) {
                if (user.photoUrl != null) {
                    AsyncImage(
                        model = user.photoUrl,
                        contentDescription = "Profile photo",
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Color(0xFF00E5FF), CircleShape)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E1E28))
                            .border(1.5.dp, Color(0xFF00E5FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Account",
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            if (showAccountDialog) {
                AlertDialog(
                    onDismissRequest = { showAccountDialog = false },
                    containerColor = Color(0xFF161622),
                    title = {
                        Text("Google Account", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(user.displayName ?: "User", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Text(user.email ?: "", color = Color(0xFF8E8E93), fontSize = 13.sp)
                        }
                    },
                    confirmButton = {
                        TextButton(
                            onClick = {
                                showAccountDialog = false
                                isLoading = true
                                AuthService.signOut(credentialManager, scope) {
                                    isLoading = false
                                    currentUser = null
                                    onUserChanged(null)
                                    Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Text("SIGN OUT", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showAccountDialog = false }) {
                            Text("CLOSE", color = Color(0xFFCCCCCC))
                        }
                    }
                )
            }
        } else {
            // Full Authenticated Profile Badge
            Surface(
                modifier = modifier,
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF141414),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (user.photoUrl != null) {
                        AsyncImage(
                            model = user.photoUrl,
                            contentDescription = "Profile photo",
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.AccountCircle,
                            contentDescription = "Account",
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            text = user.displayName ?: "User",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = user.email ?: "",
                            color = Color(0xFFAAAAAA),
                            fontSize = 10.sp,
                            maxLines = 1
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    IconButton(
                        onClick = {
                            isLoading = true
                            AuthService.signOut(credentialManager, scope) {
                                isLoading = false
                                currentUser = null
                                onUserChanged(null)
                                Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Sign Out",
                            tint = Color(0xFFFF5555),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    } else {
        // Sign In with Google Button - Compact and never clipped
        Surface(
            onClick = {
                isLoading = true
                AuthService.isFirebaseReady(context)
                AuthService.signInWithGoogle(
                    context = context,
                    credentialManager = credentialManager,
                    scope = scope,
                    onSuccess = { authedUser ->
                        isLoading = false
                        currentUser = authedUser
                        onUserChanged(authedUser)
                        Toast.makeText(context, "Welcome, ${authedUser.displayName ?: "Creator"}!", Toast.LENGTH_SHORT).show()
                    },
                    onError = { errorMsg ->
                        isLoading = false
                        Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                    },
                    onCancelled = {
                        isLoading = false
                    }
                )
            },
            enabled = !isLoading,
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1E1E28),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333344)),
            modifier = modifier
                .height(40.dp)
                .wrapContentWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color(0xFF00E5FF)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Connecting...",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White,
                        maxLines = 1,
                        softWrap = false
                    )
                } else {
                    Text(
                        "G",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFF4285F4)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (compact) "Sign in" else "Sign in with Google",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }
        }
    }
}
