package com.ve2050.editor.ui.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.exoplayer.ExoPlayer
import com.ve2050.editor.audio.AudioEngine
import com.ve2050.editor.model.SoundEffectType
import com.ve2050.editor.model.TtsVoiceGender
import com.ve2050.editor.model.VoiceCloneProfile
import com.ve2050.editor.model.VoiceEffect
import com.ve2050.editor.model.isRtlText
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AudioStudioTab(val title: String, val urduTitle: String, val icon: String) {
    VOICE_CLONE("AI Voice Clone", "وائس کلوننگ", "🧬"),
    TTS("Text to Voice", "لکھ کر آواز", "🗣️"),
    VOICE_CHANGER("Voice Effects", "آواز بدلیں", "🎛️"),
    RECORD("Voiceover", "ریکارڈ کریں", "🎙️"),
    SFX("SFX Library", "صوتی اثرات", "⚡")
}

@Composable
fun VoiceStudioDialog(
    currentMusicUri: Uri?,
    currentVoiceEffect: VoiceEffect,
    currentVolume: Float,
    audioEngine: AudioEngine,
    onDismiss: () -> Unit,
    onApplyVoiceEffect: (VoiceEffect, Float, Float, Float) -> Unit, // effect, pitch, speed, volume
    onAttachAudioUri: (Uri, String) -> Unit, // uri, title
    onClearAudio: () -> Unit,
    onPickMusicFromFile: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var activeTab by remember { mutableStateOf(AudioStudioTab.TTS) }

    // Preview Player for sounds, recordings, and previews
    var previewPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var isPreviewPlaying by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose {
            previewPlayer?.release()
            previewPlayer = null
            audioEngine.stopSpeaking()
        }
    }

    fun playPreviewUri(uri: Uri, pitch: Float = 1.0f, speed: Float = 1.0f) {
        previewPlayer?.release()
        val player = ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            playbackParameters = PlaybackParameters(speed, pitch)
            prepare()
            play()
        }
        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_ENDED) {
                    isPreviewPlaying = false
                }
            }
        })
        previewPlayer = player
        isPreviewPlaying = true
    }

    fun stopPreview() {
        previewPlayer?.stop()
        previewPlayer?.release()
        previewPlayer = null
        isPreviewPlaying = false
        audioEngine.stopSpeaking()
    }

    Dialog(
        onDismissRequest = {
            stopPreview()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.35f), RoundedCornerShape(24.dp)),
            color = Color(0xFF0F0F16)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF161622))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF00E5FF).copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("🎙️", fontSize = 18.sp)
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                "Voice & Audio Pro Studio",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                "Text-To-Speech • Voice Changer • Mic Record • SFX",
                                color = Color(0xFF00E5FF),
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            stopPreview()
                            onDismiss()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                // Tab Bar
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF12121C))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(AudioStudioTab.values()) { tab ->
                        val isSelected = activeTab == tab
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color(0xFF1A1A26),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) Color(0xFF00E5FF) else Color(0xFF2C2C3E)
                            ),
                            modifier = Modifier.clickable {
                                stopPreview()
                                activeTab = tab
                            }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(tab.icon, fontSize = 15.sp)
                                Spacer(Modifier.width(6.dp))
                                Column {
                                    Text(
                                        tab.title,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        tab.urduTitle,
                                        color = if (isSelected) Color(0xFF80EAFF) else Color.Gray,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }

                Divider(color = Color(0xFF242436), thickness = 1.dp)

                // Tab Content Body
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (activeTab) {
                        AudioStudioTab.VOICE_CLONE -> {
                            VoiceCloneSection(
                                audioEngine = audioEngine,
                                onPreviewVoice = { text, profile ->
                                    audioEngine.speakPreview(
                                        text = text,
                                        pitch = profile.recommendedPitch,
                                        speed = profile.recommendedSpeed,
                                        voiceGender = profile.gender
                                    )
                                },
                                onStopVoice = { audioEngine.stopSpeaking() },
                                onAddClonedVoiceToProject = { text, profile ->
                                    audioEngine.synthesizeVoiceCloneToFile(text, profile) { uri ->
                                        if (uri != null) {
                                            onAttachAudioUri(uri, "${profile.name}: ${text.take(15)}")
                                            onDismiss()
                                        }
                                    }
                                }
                            )
                        }

                        AudioStudioTab.TTS -> {
                            TtsVoiceSection(
                                audioEngine = audioEngine,
                                onPreviewVoice = { text, pitch, speed, gender ->
                                    audioEngine.speakPreview(text, pitch, speed, gender)
                                },
                                onStopVoice = {
                                    audioEngine.stopSpeaking()
                                },
                                onAddVoiceToProject = { text, pitch, speed, gender ->
                                    audioEngine.synthesizeSpeechToFile(text, pitch, speed, gender) { uri ->
                                        if (uri != null) {
                                            val label = if (gender == TtsVoiceGender.FEMALE) "Girl AI Voice" else "Boy AI Voice"
                                            onAttachAudioUri(uri, "$label: ${text.take(15)}")
                                            onDismiss()
                                        }
                                    }
                                }
                            )
                        }

                        AudioStudioTab.VOICE_CHANGER -> {
                            VoiceChangerSection(
                                currentEffect = currentVoiceEffect,
                                currentVolume = currentVolume,
                                currentMusicUri = currentMusicUri,
                                onPreviewEffect = { effect, pitch, speed ->
                                    if (currentMusicUri != null) {
                                        playPreviewUri(currentMusicUri, pitch, speed)
                                    }
                                },
                                onStopPreview = { stopPreview() },
                                onApplyEffect = { effect, pitch, speed, volume ->
                                    stopPreview()
                                    onApplyVoiceEffect(effect, pitch, speed, volume)
                                    onDismiss()
                                },
                                onPickFile = {
                                    stopPreview()
                                    onPickMusicFromFile()
                                    onDismiss()
                                },
                                onClearAudio = {
                                    stopPreview()
                                    onClearAudio()
                                    onDismiss()
                                }
                            )
                        }

                        AudioStudioTab.RECORD -> {
                            VoiceRecorderSection(
                                audioEngine = audioEngine,
                                onPreviewRecording = { uri, pitch, speed ->
                                    playPreviewUri(uri, pitch, speed)
                                },
                                onStopPreview = { stopPreview() },
                                onAddRecordingToProject = { uri, name ->
                                    stopPreview()
                                    onAttachAudioUri(uri, name)
                                    onDismiss()
                                }
                            )
                        }

                        AudioStudioTab.SFX -> {
                            SfxLibrarySection(
                                audioEngine = audioEngine,
                                onPlaySfx = { type ->
                                    coroutineScope.launch {
                                        val uri = audioEngine.getOrCreateSfx(type)
                                        playPreviewUri(uri)
                                    }
                                },
                                onAddSfxToProject = { type ->
                                    coroutineScope.launch {
                                        val uri = audioEngine.getOrCreateSfx(type)
                                        onAttachAudioUri(uri, "SFX: ${type.title}")
                                        onDismiss()
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

// ========================================================
// 1. Text-To-Speech (AI Voice Generator)
// ========================================================
@Composable
private fun TtsVoiceSection(
    audioEngine: AudioEngine,
    onPreviewVoice: (String, Float, Float, TtsVoiceGender) -> Unit,
    onStopVoice: () -> Unit,
    onAddVoiceToProject: (String, Float, Float, TtsVoiceGender) -> Unit
) {
    var textInput by remember { mutableStateOf("اس ویڈیو کو لائک اور سبسکرائب کریں") }
    var selectedGender by remember { mutableStateOf(TtsVoiceGender.FEMALE) }
    var pitch by remember { mutableStateOf(selectedGender.pitch) }
    var speed by remember { mutableStateOf(selectedGender.speed) }
    var isSpeaking by remember { mutableStateOf(false) }
    var isSynthesizing by remember { mutableStateOf(false) }

    val quickPhrases = listOf(
        "اس ویڈیو کو لائک اور سبسکرائب کریں" to "Urdu Like",
        "Welcome to my new video!" to "English Intro",
        "یہ ویڈیو آخر تک ضرور دیکھیں" to "Urdu Watch Till End",
        "Subscribe for more amazing tips!" to "English Subscribe",
        "آج کا دن بہت زبردست ہے" to "Urdu Great Day"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                "1. Type Text in Any Language (اردو / English / Hindi):",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF00E5FF),
                    unfocusedBorderColor = Color(0xFF2E2E42),
                    focusedContainerColor = Color(0xFF14141E),
                    unfocusedContainerColor = Color(0xFF14141E),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                textStyle = LocalTextStyle.current.copy(
                    fontSize = 15.sp,
                    textDirection = if (isRtlText(textInput)) TextDirection.Rtl else TextDirection.Ltr
                ),
                placeholder = {
                    Text(
                        "Enter script or Urdu text here...",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                }
            )
        }

        // Quick Suggestions
        item {
            Text(
                "Quick Phrase Suggestions:",
                color = Color(0xFFAAAAAA),
                fontSize = 11.sp
            )
            Spacer(Modifier.height(4.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(quickPhrases) { (phrase, tag) ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1E1E2C),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333348)),
                        modifier = Modifier.clickable { textInput = phrase }
                    ) {
                        Text(
                            "$tag: ${phrase.take(18)}...",
                            color = Color(0xFF80EAFF),
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Voice Character / Gender selection
        item {
            Text(
                "2. Choose Voice Persona (لڑکی / لڑکا / روبوٹ):",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TtsVoiceGender.values().forEach { gender ->
                    val isChosen = selectedGender == gender
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isChosen) Color(0xFF00E5FF).copy(alpha = 0.18f) else Color(0xFF181824),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isChosen) Color(0xFF00E5FF) else Color(0xFF282838)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedGender = gender
                                pitch = gender.pitch
                                speed = gender.speed
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(gender.icon, fontSize = 22.sp)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(
                                        gender.displayName,
                                        color = if (isChosen) Color(0xFF00E5FF) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        gender.urduLabel,
                                        color = if (isChosen) Color(0xFF80EAFF) else Color.LightGray,
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isChosen) Color(0xFF00E5FF) else Color(0xFF28283A)
                            ) {
                                Text(
                                    gender.tag,
                                    color = if (isChosen) Color.Black else Color.LightGray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Sliders for Fine-Tuning
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF161622),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Voice Pitch (سر کی بلندی):", color = Color.LightGray, fontSize = 12.sp)
                        Text(String.format("%.2fx", pitch), color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Slider(
                        value = pitch,
                        onValueChange = { pitch = it },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF)
                        )
                    )

                    Spacer(Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Speaking Speed (بولنے کی رفتار):", color = Color.LightGray, fontSize = 12.sp)
                        Text(String.format("%.2fx", speed), color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Slider(
                        value = speed,
                        onValueChange = { speed = it },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF)
                        )
                    )
                }
            }
        }

        // Actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        if (isSpeaking) {
                            onStopVoice()
                            isSpeaking = false
                        } else {
                            if (textInput.isNotBlank()) {
                                onPreviewVoice(textInput, pitch, speed, selectedGender)
                                isSpeaking = true
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF)),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        if (isSpeaking) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(if (isSpeaking) "Stop Preview" else "Test Voice ▶", color = Color(0xFF00E5FF), fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        if (textInput.isNotBlank() && !isSynthesizing) {
                            isSynthesizing = true
                            onAddVoiceToProject(textInput, pitch, speed, selectedGender)
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    modifier = Modifier.weight(1.3f)
                ) {
                    if (isSynthesizing) {
                        CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Generating...", color = Color.Black, fontSize = 12.sp)
                    } else {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Add to Video Track", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ========================================================
// 2. Voice Changer & Effects Section
// ========================================================
@Composable
private fun VoiceChangerSection(
    currentEffect: VoiceEffect,
    currentVolume: Float,
    currentMusicUri: Uri?,
    onPreviewEffect: (VoiceEffect, Float, Float) -> Unit,
    onStopPreview: () -> Unit,
    onApplyEffect: (VoiceEffect, Float, Float, Float) -> Unit,
    onPickFile: () -> Unit,
    onClearAudio: () -> Unit
) {
    var selectedEffect by remember { mutableStateOf(currentEffect) }
    var pitch by remember { mutableStateOf(currentEffect.pitch) }
    var speed by remember { mutableStateOf(currentEffect.speed) }
    var volume by remember { mutableStateOf(currentVolume) }
    var isPreviewing by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Track Status Header
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF161622),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C3E)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎵", fontSize = 20.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(
                                if (currentMusicUri != null) "Audio Track Active ✔" else "No Music Track Loaded",
                                color = if (currentMusicUri != null) Color(0xFF00E5FF) else Color.LightGray,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                if (currentMusicUri != null) "Voice changer applies directly to audio & video" else "Import audio or use TTS to apply effects",
                                color = Color.Gray,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = onPickFile,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF252538)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("📁 Pick File", color = Color.White, fontSize = 11.sp)
                        }

                        if (currentMusicUri != null) {
                            IconButton(onClick = onClearAudio, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "Clear", tint = Color.Red, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // Voice Presets
        item {
            Text(
                "Voice Effect Presets (آواز کی قسمیں):",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                VoiceEffect.values().forEach { effect ->
                    val isChosen = selectedEffect == effect
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isChosen) Color(0xFF00E5FF).copy(alpha = 0.18f) else Color(0xFF171724),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isChosen) Color(0xFF00E5FF) else Color(0xFF282838)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedEffect = effect
                                pitch = effect.pitch
                                speed = effect.speed
                                if (currentMusicUri != null) {
                                    onPreviewEffect(effect, pitch, speed)
                                    isPreviewing = true
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(effect.icon, fontSize = 22.sp)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(
                                        effect.displayName,
                                        color = if (isChosen) Color(0xFF00E5FF) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        "${effect.urduLabel} • ${effect.description}",
                                        color = if (isChosen) Color(0xFF80EAFF) else Color.LightGray,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Text(
                                "${String.format("%.2f", effect.pitch)}x",
                                color = if (isChosen) Color(0xFF00E5FF) else Color.Gray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Sliders
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF161622),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Pitch (آواز کی موٹائی / باریکی):", color = Color.LightGray, fontSize = 12.sp)
                        Text(String.format("%.2fx", pitch), color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Slider(
                        value = pitch,
                        onValueChange = {
                            pitch = it
                            if (currentMusicUri != null && isPreviewing) onPreviewEffect(selectedEffect, pitch, speed)
                        },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF00E5FF), activeTrackColor = Color(0xFF00E5FF))
                    )

                    Spacer(Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Volume Boost (آواز کا والیوم):", color = Color.LightGray, fontSize = 12.sp)
                        Text("${(volume * 100).toInt()}%", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Slider(
                        value = volume,
                        onValueChange = { volume = it },
                        valueRange = 0.0f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = Color(0xFF00E5FF), activeTrackColor = Color(0xFF00E5FF))
                    )
                }
            }
        }

        // Action Buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (currentMusicUri != null) {
                    OutlinedButton(
                        onClick = {
                            if (isPreviewing) {
                                onStopPreview()
                                isPreviewing = false
                            } else {
                                onPreviewEffect(selectedEffect, pitch, speed)
                                isPreviewing = true
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(if (isPreviewing) Icons.Default.Stop else Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF00E5FF))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isPreviewing) "Stop" else "Test Sound", color = Color(0xFF00E5FF), fontSize = 12.sp)
                    }
                }

                Button(
                    onClick = {
                        onApplyEffect(selectedEffect, pitch, speed, volume)
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    modifier = Modifier.weight(1.3f)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Apply Voice Effect", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}

// ========================================================
// 3. Voice Recorder Section (Mic Voiceover)
// ========================================================
@Composable
private fun VoiceRecorderSection(
    audioEngine: AudioEngine,
    onPreviewRecording: (Uri, Float, Float) -> Unit,
    onStopPreview: () -> Unit,
    onAddRecordingToProject: (Uri, String) -> Unit
) {
    val context = LocalContext.current
    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasPermission = isGranted
    }

    var isRecording by remember { mutableStateOf(false) }
    var recordingSeconds by remember { mutableStateOf(0) }
    var recordedUri by remember { mutableStateOf<Uri?>(null) }
    var recordedAmplitudes by remember { mutableStateOf(listOf<Float>()) }
    var selectedEffect by remember { mutableStateOf(VoiceEffect.ORIGINAL) }
    var pitch by remember { mutableStateOf(1.0f) }
    var speed by remember { mutableStateOf(1.0f) }
    var isPlayingBack by remember { mutableStateOf(false) }

    // Amplitude polling timer while recording
    LaunchedEffect(isRecording) {
        if (isRecording) {
            recordingSeconds = 0
            val amps = mutableListOf<Float>()
            while (isRecording) {
                delay(100)
                val amp = (audioEngine.getMaxAmplitude() / 32767f).coerceIn(0.05f, 1.0f)
                amps.add(amp)
                if (amps.size > 28) amps.removeAt(0)
                recordedAmplitudes = amps.toList()
                if (amps.size % 10 == 0) recordingSeconds++
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Voiceover Microphone Studio",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
            Text(
                "Record your live voice & transform it to Girl, Boy, Robot or Monster!",
                color = Color(0xFF00E5FF),
                fontSize = 11.sp
            )
        }

        // Live Equalizer Visualizer Card
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF161622),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isRecording) Color.Red else Color(0xFF2C2C3E)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        if (isRecording) "🔴 RECORDING: ${String.format("%02d:%02d", recordingSeconds / 60, recordingSeconds % 60)}"
                        else if (recordedUri != null) "✔ Voice Recorded (${recordingSeconds}s)"
                        else "Tap Red Mic Below to Record",
                        color = if (isRecording) Color.Red else if (recordedUri != null) Color(0xFF00E5FF) else Color.LightGray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Spacer(Modifier.height(14.dp))

                    // Bouncing Bars
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val bars = if (isRecording) recordedAmplitudes else List(24) { 0.15f }
                        bars.takeLast(24).forEach { heightRatio ->
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height((55.dp * heightRatio).coerceAtLeast(6.dp))
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(
                                        if (isRecording) Brush.verticalGradient(listOf(Color(0xFF00E5FF), Color.Red))
                                        else Brush.verticalGradient(listOf(Color(0xFF00E5FF), Color(0xFF007799)))
                                    )
                            )
                        }
                    }
                }
            }
        }

        // Mic Button
        item {
            if (!hasPermission) {
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
                ) {
                    Icon(Icons.Default.Mic, contentDescription = null, tint = Color.Black)
                    Spacer(Modifier.width(8.dp))
                    Text("Grant Mic Permission", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            } else {
                Surface(
                    shape = CircleShape,
                    color = if (isRecording) Color.Red else Color(0xFF222236),
                    border = androidx.compose.foundation.BorderStroke(3.dp, if (isRecording) Color.White else Color(0xFF00E5FF)),
                    modifier = Modifier
                        .size(72.dp)
                        .clickable {
                            if (!isRecording) {
                                audioEngine.startRecording()
                                isRecording = true
                                recordedUri = null
                            } else {
                                val uri = audioEngine.stopRecording()
                                isRecording = false
                                recordedUri = uri
                            }
                        }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Mic Action",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    if (isRecording) "Tap to Stop" else "Tap to Record",
                    color = Color.LightGray,
                    fontSize = 11.sp
                )
            }
        }

        // If recording is done, show Voice Changer filters!
        if (recordedUri != null) {
            item {
                Divider(color = Color(0xFF28283C), thickness = 1.dp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Transform Your Voice (اپنی آواز بدلیں):",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(6.dp))

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(VoiceEffect.values()) { effect ->
                        val isSel = selectedEffect == effect
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSel) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color(0xFF1B1B2A),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSel) Color(0xFF00E5FF) else Color(0xFF2C2C3E)),
                            modifier = Modifier.clickable {
                                selectedEffect = effect
                                pitch = effect.pitch
                                speed = effect.speed
                                recordedUri?.let { onPreviewRecording(it, pitch, speed) }
                                isPlayingBack = true
                            }
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(effect.icon, fontSize = 20.sp)
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    effect.displayName,
                                    color = if (isSel) Color(0xFF00E5FF) else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                                Text(effect.urduLabel, color = Color.Gray, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            if (isPlayingBack) {
                                onStopPreview()
                                isPlayingBack = false
                            } else {
                                recordedUri?.let { onPreviewRecording(it, pitch, speed) }
                                isPlayingBack = true
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(if (isPlayingBack) Icons.Default.Stop else Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF00E5FF))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isPlayingBack) "Stop" else "Listen ▶", color = Color(0xFF00E5FF), fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            recordedUri?.let { uri ->
                                val name = "Voiceover (${selectedEffect.displayName})"
                                onAddRecordingToProject(uri, name)
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                        modifier = Modifier.weight(1.3f)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Add to Video Track", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ========================================================
// 4. SFX Library Section (Free Sound Effects Gift)
// ========================================================
@Composable
private fun SfxLibrarySection(
    audioEngine: AudioEngine,
    onPlaySfx: (SoundEffectType) -> Unit,
    onAddSfxToProject: (SoundEffectType) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "CapCut Free Sound Effects Library (صوتی اثرات):",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                "Instant offline sound effects ready to insert into your video!",
                color = Color(0xFF00E5FF),
                fontSize = 11.sp
            )
        }

        items(SoundEffectType.values()) { sfx ->
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF161622),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF28283C)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF00E5FF).copy(alpha = 0.15f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(sfx.icon, fontSize = 18.sp)
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                sfx.title,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                "${sfx.urduTitle} • ${sfx.category} (${sfx.durationMs}ms)",
                                color = Color.LightGray,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { onPlaySfx(sfx) },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = Color(0xFF00E5FF))
                        }

                        Button(
                            onClick = { onAddSfxToProject(sfx) },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("Use", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

// ========================================================
// AI Voice Cloning Studio (10-20s Sample + 5,000 Word TTS)
// ========================================================
@Composable
fun VoiceCloneSection(
    audioEngine: AudioEngine,
    onPreviewVoice: (String, VoiceCloneProfile) -> Unit,
    onStopVoice: () -> Unit,
    onAddClonedVoiceToProject: (String, VoiceCloneProfile) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
    }

    // Voice sample recording states
    var isRecordingSample by remember { mutableStateOf(false) }
    var recordingSeconds by remember { mutableIntStateOf(0) }
    var recordedSampleUri by remember { mutableStateOf<Uri?>(null) }
    var isAnalyzingSample by remember { mutableStateOf(false) }
    var amplitudeList by remember { mutableStateOf(listOf<Float>()) }

    // User's trained profile and presets
    var userTrainedProfile by remember {
        mutableStateOf(
            VoiceCloneProfile(
                name = "My Voice (Mine)",
                urduName = "میری اصلی آواز",
                sampleDurationSec = 15,
                detectedPitchHz = 138f,
                recommendedPitch = 0.96f,
                recommendedSpeed = 1.0f,
                gender = TtsVoiceGender.MALE,
                toneWarmth = 1.1f,
                isTrained = false
            )
        )
    }

    val presetProfiles = remember {
        listOf(
            VoiceCloneProfile(
                name = "Deep Male Clone",
                urduName = "مردانہ گھمبیر آواز",
                sampleDurationSec = 20,
                detectedPitchHz = 110f,
                recommendedPitch = 0.72f,
                recommendedSpeed = 0.95f,
                gender = TtsVoiceGender.MALE,
                toneWarmth = 1.2f,
                isTrained = true
            ),
            VoiceCloneProfile(
                name = "Sweet Girl Clone",
                urduName = "پیاری لڑکی کی آواز",
                sampleDurationSec = 18,
                detectedPitchHz = 210f,
                recommendedPitch = 1.42f,
                recommendedSpeed = 1.02f,
                gender = TtsVoiceGender.FEMALE,
                toneWarmth = 1.1f,
                isTrained = true
            ),
            VoiceCloneProfile(
                name = "Urdu Storyteller Clone",
                urduName = "داستان گو (اردو)",
                sampleDurationSec = 20,
                detectedPitchHz = 150f,
                recommendedPitch = 1.15f,
                recommendedSpeed = 0.90f,
                gender = TtsVoiceGender.FEMALE,
                toneWarmth = 1.25f,
                isTrained = true
            ),
            VoiceCloneProfile(
                name = "Pro Broadcaster Clone",
                urduName = "پروفیشنل براڈکاسٹر",
                sampleDurationSec = 20,
                detectedPitchHz = 95f,
                recommendedPitch = 0.62f,
                recommendedSpeed = 0.94f,
                gender = TtsVoiceGender.MALE,
                toneWarmth = 1.3f,
                isTrained = true
            )
        )
    }

    var selectedProfile by remember { mutableStateOf(userTrainedProfile) }

    // Text for cloned synthesis (supporting up to 5,000 words)
    var scriptText by remember {
        mutableStateOf("السلام علیکم! یہ میری اپنی کلون شدہ آواز میں تیار کردہ ویڈیو ہے۔")
    }

    // Tuning sliders
    var pitchFineTune by remember { mutableFloatStateOf(0f) } // -0.3f .. +0.3f
    var speedFineTune by remember { mutableFloatStateOf(0f) } // -0.3f .. +0.3f

    var isPreviewing by remember { mutableStateOf(false) }
    var isSynthesizing by remember { mutableStateOf(false) }

    // Word count calculation
    val wordCount = remember(scriptText) {
        if (scriptText.isBlank()) 0 else scriptText.trim().split("\\s+".toRegex()).size
    }

    // Live Recording loop for amplitude and timer
    LaunchedEffect(isRecordingSample) {
        if (isRecordingSample) {
            recordingSeconds = 0
            amplitudeList = emptyList()
            while (isRecordingSample) {
                delay(100)
                val amp = (audioEngine.getMaxAmplitude().toFloat() / 32767f).coerceIn(0.05f, 1f)
                amplitudeList = (amplitudeList + amp).takeLast(28)
                if (amplitudeList.size % 10 == 0) {
                    recordingSeconds++
                    if (recordingSeconds >= 25) {
                        // Stop automatically at 25s
                        isRecordingSample = false
                        val uri = audioEngine.stopRecording()
                        if (uri != null) {
                            recordedSampleUri = uri
                            isAnalyzingSample = true
                            coroutineScope.launch {
                                val trained = audioEngine.analyzeRecordedVoiceSample(uri, recordingSeconds)
                                userTrainedProfile = trained.copy(isTrained = true)
                                selectedProfile = userTrainedProfile
                                isAnalyzingSample = false
                            }
                        }
                    }
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Banner info
        item {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFF131A28),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E5FF).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🧬", fontSize = 22.sp)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "AI Voice Clone Engine (اپنی آواز کا کلون)",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            "10-20 سیکنڈ سیمپل ریکارڈ کریں، پھر 5000 الفاظ تک لکھ کر ہو بہو اپنی آواز میں ویڈیو ڈبنگ کریں!",
                            color = Color(0xFF00E5FF),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Section 1: Record 10-20s Sample
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF151522),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF28283C)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "1. Record 10-20s Voice Sample",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (userTrainedProfile.isTrained) Color(0xFF00FF88).copy(alpha = 0.2f) else Color(0xFFFF9900).copy(alpha = 0.2f)
                        ) {
                            Text(
                                if (userTrainedProfile.isTrained) "✓ Profile Cloned" else "Record 10-20s",
                                color = if (userTrainedProfile.isTrained) Color(0xFF00FF88) else Color(0xFFFFB74D),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Reading prompt for user
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF101018),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF202030)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                "Read this aloud while recording:",
                                color = Color.Gray,
                                fontSize = 10.sp
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "« السلام علیکم! یہ میری اصلی آواز کا سیمپل ہے، جس سے میں اپنی مرضی کے الفاظ اپنی آواز میں کلون کروں گا۔ »",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Visualizer & Progress bar
                    if (isRecordingSample) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0B1220))
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            amplitudeList.forEach { amp ->
                                val barHeight = (amp * 28f).coerceIn(4f, 28f)
                                Box(
                                    modifier = Modifier
                                        .width(4.dp)
                                        .height(barHeight.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(Color(0xFF00E5FF))
                                )
                                Spacer(Modifier.width(3.dp))
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Recording: ${recordingSeconds}s / 20s (Recommended: 10s-20s)",
                            color = Color(0xFF00E5FF),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    } else if (isAnalyzingSample) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = Color(0xFF00E5FF),
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Analyzing timbre, pitch & acoustic profile...",
                                color = Color(0xFF80EAFF),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Record Button
                    Button(
                        onClick = {
                            if (!hasMicPermission) {
                                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                return@Button
                            }
                            if (!isRecordingSample) {
                                val file = audioEngine.startRecording()
                                if (file != null) {
                                    isRecordingSample = true
                                }
                            } else {
                                isRecordingSample = false
                                val uri = audioEngine.stopRecording()
                                if (uri != null) {
                                    recordedSampleUri = uri
                                    isAnalyzingSample = true
                                    coroutineScope.launch {
                                        val trained = audioEngine.analyzeRecordedVoiceSample(uri, recordingSeconds)
                                        userTrainedProfile = trained.copy(isTrained = true)
                                        selectedProfile = userTrainedProfile
                                        isAnalyzingSample = false
                                    }
                                }
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRecordingSample) Color(0xFFFF3366) else Color(0xFF00E5FF)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            if (isRecordingSample) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (isRecordingSample) "Stop & Train Profile (${recordingSeconds}s)" else "Record 10-20s Voice Sample",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Section 2: Choose Voice Profile
        item {
            Column {
                Text(
                    "2. Select Active Voice Profile",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // User profile first
                    item {
                        val isSelected = selectedProfile.id == userTrainedProfile.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color(0xFF181826),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) Color(0xFF00E5FF) else Color(0xFF28283C)
                            ),
                            modifier = Modifier
                                .width(150.dp)
                                .clickable { selectedProfile = userTrainedProfile }
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("🌟", fontSize = 16.sp)
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        userTrainedProfile.name,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    if (userTrainedProfile.isTrained) "Pitch: ${userTrainedProfile.detectedPitchHz.toInt()}Hz (Trained)" else "Default Profile",
                                    color = if (userTrainedProfile.isTrained) Color(0xFF00FF88) else Color.Gray,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }

                    // Preset clones
                    items(presetProfiles) { preset ->
                        val isSelected = selectedProfile.id == preset.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color(0xFF181826),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) Color(0xFF00E5FF) else Color(0xFF28283C)
                            ),
                            modifier = Modifier
                                .width(150.dp)
                                .clickable { selectedProfile = preset }
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(if (preset.gender == TtsVoiceGender.FEMALE) "👧" else "👨", fontSize = 16.sp)
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        preset.name,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    preset.urduName,
                                    color = Color.LightGray,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Section 3: 5,000 Word Script Input
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF151522),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF28283C)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "3. Script to Synthesize in Cloned Voice",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            "$wordCount / 5,000 words",
                            color = if (wordCount > 5000) Color(0xFFFF5555) else Color(0xFF00E5FF),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(Modifier.height(6.dp))

                    // Preset chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        item {
                            SuggestionChip(
                                onClick = {
                                    scriptText = "السلام علیکم ناظرین! آج کی اس خاص ویڈیو میں ہم دیکھنے والے ہیں ایک زبردست طریقہ جو آپ کے کام کو آسان بنا دے گا۔"
                                },
                                label = { Text("Urdu Video Intro", fontSize = 10.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    scriptText = "زندگی میں کامیابی کا راز محنت اور لگن میں ہے، ہر لمحہ ایک نئی امید لے کر آتا ہے۔"
                                },
                                label = { Text("Inspirational Quote", fontSize = 10.sp) }
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = {
                                    scriptText = "Hey everyone! Welcome back. Today we have something truly exciting to share with you all."
                                },
                                label = { Text("English Vlog", fontSize = 10.sp) }
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    val isUrdu = scriptText.any { it in '\u0600'..'\u06FF' }
                    OutlinedTextField(
                        value = scriptText,
                        onValueChange = { scriptText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 100.dp, max = 160.dp),
                        placeholder = {
                            Text(
                                "5000 الفاظ تک کوئی بھی متن لکھیں (اردو یا انگریزی)...",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        },
                        textStyle = androidx.compose.ui.text.TextStyle(
                            color = Color.White,
                            fontSize = 13.sp,
                            textAlign = if (isUrdu) TextAlign.Right else TextAlign.Left,
                            textDirection = if (isUrdu) TextDirection.Rtl else TextDirection.Ltr
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF00E5FF),
                            unfocusedBorderColor = Color(0xFF333348)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(Modifier.height(10.dp))

                    // Fine-tuning sliders
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Pitch Tuning", color = Color.Gray, fontSize = 10.sp)
                                Text(
                                    String.format("%.2f", (selectedProfile.recommendedPitch + pitchFineTune)),
                                    color = Color(0xFF00E5FF),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Slider(
                                value = pitchFineTune,
                                onValueChange = { pitchFineTune = it },
                                valueRange = -0.3f..0.3f,
                                colors = SliderDefaults.colors(
                                    thumbColor = Color(0xFF00E5FF),
                                    activeTrackColor = Color(0xFF00E5FF)
                                )
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Speed", color = Color.Gray, fontSize = 10.sp)
                                Text(
                                    String.format("%.2fx", (selectedProfile.recommendedSpeed + speedFineTune)),
                                    color = Color(0xFF00E5FF),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Slider(
                                value = speedFineTune,
                                onValueChange = { speedFineTune = it },
                                valueRange = -0.3f..0.3f,
                                colors = SliderDefaults.colors(
                                    thumbColor = Color(0xFF00E5FF),
                                    activeTrackColor = Color(0xFF00E5FF)
                                )
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (isPreviewing) {
                                    onStopVoice()
                                    isPreviewing = false
                                } else {
                                    val tunedProfile = selectedProfile.copy(
                                        recommendedPitch = selectedProfile.recommendedPitch + pitchFineTune,
                                        recommendedSpeed = selectedProfile.recommendedSpeed + speedFineTune
                                    )
                                    onPreviewVoice(scriptText, tunedProfile)
                                    isPreviewing = true
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                if (isPreviewing) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                if (isPreviewing) "Stop" else "Preview",
                                color = Color(0xFF00E5FF),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }

                        Button(
                            onClick = {
                                isSynthesizing = true
                                val tunedProfile = selectedProfile.copy(
                                    recommendedPitch = selectedProfile.recommendedPitch + pitchFineTune,
                                    recommendedSpeed = selectedProfile.recommendedSpeed + speedFineTune
                                )
                                onAddClonedVoiceToProject(scriptText, tunedProfile)
                            },
                            enabled = !isSynthesizing && scriptText.isNotBlank(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                            modifier = Modifier.weight(1.3f)
                        ) {
                            if (isSynthesizing) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Insert to Timeline", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
