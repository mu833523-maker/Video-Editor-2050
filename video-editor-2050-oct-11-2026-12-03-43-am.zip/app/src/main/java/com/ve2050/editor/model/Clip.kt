package com.ve2050.editor.model

import android.net.Uri
import java.util.UUID

enum class TrackType(val label: String, val icon: String) {
    VIDEO("Video Track", "🎬"),
    OVERLAY("Holo Overlay", "🌌"),
    AUDIO("Audio Track", "🎵"),
    TEXT("Cyber Titles", "🔤"),
    EFFECT("Quantum FX", "⚡")
}

enum class VideoFilter(val displayName: String, val description: String) {
    NONE("Normal Raw", "Standard uncolored stream"),
    CYBER_NEON("Cyber Neon", "Intense cyan & magenta contrast with glowing highlights"),
    HOLO_SCANLINES("Holo Scanlines", "Holographic CRT raster lines & chromatic shift"),
    QUANTUM_GLITCH("Quantum Glitch", "Digital pixel offset & cyber interference"),
    MATRIX_HUD("Matrix HUD", "Digital matrix grid & cyber telemetry readout"),
    SYNTHWAVE_GLOW("Synthwave Glow", "Warm 80s synth sunset orange and deep violet"),
    THERMAL_VISION("Thermal Vision", "Infrared heat-map color spectrum"),
    VINTAGE_2020("Vintage 2020s", "Pre-quantum nostalgic digital video look")
}

enum class TransitionType(val title: String) {
    NONE("Cut"),
    CYBER_SLICE("Cyber Slice"),
    WARP_DISSOLVE("Warp Dissolve"),
    NEON_FLASH("Neon Flash"),
    QUANTUM_PIXEL("Quantum Pixel")
}

enum class AspectRatio(val displayName: String, val ratioWidth: Float, val ratioHeight: Float) {
    RATIO_16_9("16:9 Cinema", 16f, 9f),
    RATIO_9_16("9:16 Holo-Reel", 9f, 16f),
    RATIO_1_1("1:1 Quantum", 1f, 1f),
    RATIO_21_9("21:9 Ultra Cyber", 21f, 9f)
}

data class Clip(
    val id: String = java.util.UUID.randomUUID().toString(),
    val uri: Uri = Uri.EMPTY,
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val durationMs: Long = (endMs - startMs).coerceAtLeast(0L),
    val title: String = "Clip",
    val sourceUri: String? = if (uri != Uri.EMPTY) uri.toString() else null,
    val trackType: TrackType = TrackType.VIDEO,
    val startTimeMs: Long = startMs,
    val sourceDurationMs: Long = if (endMs > startMs) endMs - startMs else durationMs,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val filter: VideoFilter = VideoFilter.NONE,
    val filterIntensity: Float = 0.85f,
    val textOverlay: String? = null,
    val accentColorHex: String = "#00F0FF",
    val hologramDepth: Float = 0.5f,
    val aiTags: List<String> = emptyList(),
    val transitionIn: TransitionType = TransitionType.NONE
) {
    val endTimeMs: Long get() = (if (startTimeMs > 0L) startTimeMs else startMs) + durationMs

    constructor(
        id: String = java.util.UUID.randomUUID().toString(),
        title: String,
        sourceUri: String? = null,
        trackType: TrackType = TrackType.VIDEO,
        startTimeMs: Long = 0L,
        durationMs: Long = 0L,
        sourceDurationMs: Long = durationMs,
        trimStartMs: Long = 0L,
        trimEndMs: Long = 0L,
        speed: Float = 1f,
        volume: Float = 1f,
        filter: VideoFilter = VideoFilter.NONE,
        filterIntensity: Float = 0.85f,
        textOverlay: String? = null,
        accentColorHex: String = "#00F0FF",
        hologramDepth: Float = 0.5f,
        aiTags: List<String> = emptyList(),
        transitionIn: TransitionType = TransitionType.NONE
    ) : this(
        id = id,
        uri = if (!sourceUri.isNullOrEmpty()) Uri.parse(sourceUri) else Uri.EMPTY,
        startMs = startTimeMs,
        endMs = startTimeMs + durationMs,
        speed = speed,
        volume = volume,
        durationMs = durationMs,
        title = title,
        sourceUri = sourceUri,
        trackType = trackType,
        startTimeMs = startTimeMs,
        sourceDurationMs = sourceDurationMs,
        trimStartMs = trimStartMs,
        trimEndMs = trimEndMs,
        filter = filter,
        filterIntensity = filterIntensity,
        textOverlay = textOverlay,
        accentColorHex = accentColorHex,
        hologramDepth = hologramDepth,
        aiTags = aiTags,
        transitionIn = transitionIn
    )
}

enum class TextPreset(val displayName: String, val badge: String) {
    NONE("Classic White", "⚪"),
    URDU_NASTALIQ("Urdu Poetry (نستعلیق)", "✒️"),
    CYBER_NEON("Cyber Neon", "🌌"),
    QUANTUM_GLITCH("Quantum Glitch", "⚡"),
    GOLDEN_METALLIC("Golden Luxury", "👑"),
    RETRO_SYNTHWAVE("Synthwave Sunset", "🌆"),
    HOLO_OUTLINE("Holo Outline", "🔲"),
    DEEP_SHADOW("Cinematic 3D", "🎬"),
    EMERALD_MATRIX("Matrix Phosphor", "🟩"),
    FIRE_BLAZE("Fiery Blaze", "🔥"),
    CHROME_FROST("Chrome Frost", "❄️"),
    MINIMAL_CAPTION("Caption Pill", "💬"),
    NEWS_BANNER("Breaking News Banner", "📰")
}

enum class TextFontFamily(val displayName: String, val fontResName: String? = null) {
    SANS_SERIF("Modern Sans (Default)"),
    URDU_NASTALIQ("Urdu Nastaliq (نستعلیق)", "noto_nastaliq_urdu"),
    BEBAS_HEADLINE("Bebas Headline (BOLD)", "bebas_neue"),
    MONTSERRAT("Montserrat (Geometric)", "montserrat"),
    PACIFICO_SCRIPT("Pacifico (Creative Script)", "pacifico"),
    SERIF("Cinematic Serif"),
    MONOSPACE("Cyber Mono"),
    CURSIVE("Creative Script"),
    ARABIC_URDU("Urdu / Arabic RTL", "noto_nastaliq_urdu")
}

enum class TextAnimation(val displayName: String, val icon: String) {
    NONE("Static", "⏹️"),
    FADE("Fade", "🌫️"),
    POP("Spring Pop", "💥"),
    SLIDE("Slide", "➡️"),
    TYPEWRITER("Typewriter", "⌨️"),
    BOUNCE("Elastic Bounce", "🏀")
}

fun isRtlText(text: String): Boolean {
    return text.any { char ->
        val code = char.code
        (code in 0x0600..0x06FF) ||
        (code in 0x0750..0x077F) ||
        (code in 0x08A0..0x08FF) ||
        (code in 0xFB50..0xFDFF) ||
        (code in 0xFE70..0xFEFF)
    }
}

data class TextKeyframe(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timeMs: Long,
    val x: Float,
    val y: Float,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f
)

data class TextTransform(
    val x: Float,
    val y: Float,
    val scale: Float,
    val rotation: Float,
    val opacity: Float
)

data class TextOverlay(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val startMs: Long = 0L,
    val endMs: Long = 5000L,
    val x: Float = 0f,
    val y: Float = 0f,
    val sizeSp: Float = 28f,
    val color: Int = 0xFFFFFFFF.toInt(),
    val preset: TextPreset = TextPreset.CYBER_NEON,
    val fontFamily: TextFontFamily = if (isRtlText(text)) TextFontFamily.URDU_NASTALIQ else TextFontFamily.SANS_SERIF,
    val isBold: Boolean = true,
    val isItalic: Boolean = false,
    val isUnderline: Boolean = false,
    val isRtl: Boolean = isRtlText(text),
    val animIn: TextAnimation = TextAnimation.POP,
    val animOut: TextAnimation = TextAnimation.FADE,
    val animDurationMs: Long = 600L,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f,
    // Styling & Design
    val strokeColor: Int = 0xFF000000.toInt(),
    val strokeWidth: Float = 0f,
    val hasShadow: Boolean = true,
    val shadowColor: Int = 0xAA000000.toInt(),
    val shadowRadius: Float = 8f,
    val hasBackground: Boolean = false,
    val backgroundColor: Int = 0x99000000.toInt(),
    // Keyframes
    val keyframes: List<TextKeyframe> = emptyList()
) {
    fun getTransformAt(timeMs: Long): TextTransform {
        if (keyframes.isEmpty()) {
            return TextTransform(x, y, scale, rotation, opacity)
        }
        val sorted = keyframes.sortedBy { it.timeMs }
        if (timeMs <= sorted.first().timeMs) {
            val first = sorted.first()
            return TextTransform(first.x, first.y, first.scale, first.rotation, first.opacity)
        }
        if (timeMs >= sorted.last().timeMs) {
            val last = sorted.last()
            return TextTransform(last.x, last.y, last.scale, last.rotation, last.opacity)
        }
        for (i in 0 until sorted.size - 1) {
            val k1 = sorted[i]
            val k2 = sorted[i + 1]
            if (timeMs in k1.timeMs..k2.timeMs) {
                val span = (k2.timeMs - k1.timeMs).coerceAtLeast(1L)
                val p = ((timeMs - k1.timeMs).toFloat() / span.toFloat()).coerceIn(0f, 1f)
                val t = (kotlin.math.sin((p - 0.5f) * kotlin.math.PI.toFloat()) / 2f + 0.5f)
                return TextTransform(
                    x = k1.x + (k2.x - k1.x) * t,
                    y = k1.y + (k2.y - k1.y) * t,
                    scale = k1.scale + (k2.scale - k1.scale) * t,
                    rotation = k1.rotation + (k2.rotation - k1.rotation) * t,
                    opacity = (k1.opacity + (k2.opacity - k1.opacity) * t).coerceIn(0f, 1f)
                )
            }
        }
        return TextTransform(x, y, scale, rotation, opacity)
    }
}

data class TimelineTrack(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: TrackType,
    val isMuted: Boolean = false,
    val isLocked: Boolean = false,
    val clips: List<Clip> = emptyList()
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    val fps: Int = 60,
    val tracks: List<TimelineTrack> = emptyList(),
    val durationMs: Long = 45000L,
    val updatedAt: Long = System.currentTimeMillis(),
    val aiSummary: String? = null
)

data class ExportConfig(
    val resolution: String = "4K Ultra UHD (3840x2160)",
    val fps: Int = 60,
    val codec: String = "AV1 Neural (2050)",
    val bitrateMbps: Int = 50,
    val applyHoloScanlines: Boolean = true,
    val audioMastering: String = "Spatial Cyber Audio 7.1"
)

enum class OverlayMask(val displayName: String, val icon: String) {
    NONE("Free / No Mask", "⬜"),
    RECTANGLE("Rounded Rect", "🔲"),
    CIRCLE("Circle Mask", "⚪"),
    HEART("Heart Mask", "❤️")
}

data class OverlayClip(
    val uri: Uri = Uri.EMPTY,
    val startMs: Long = 0L,
    val durationMs: Long = 5000L,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f,
    val mask: OverlayMask = OverlayMask.NONE,
    val isChromaKeyEnabled: Boolean = false,
    val chromaKeyColorHex: String = "#00FF00",
    val chromaKeyIntensity: Float = 0.5f
)

enum class VoiceEffect(
    val displayName: String,
    val urduLabel: String,
    val icon: String,
    val pitch: Float,
    val speed: Float,
    val description: String
) {
    ORIGINAL("Original Voice", "اصل آواز", "🎤", 1.0f, 1.0f, "Standard clean unaltered audio"),
    FEMALE_GIRL("Sweet Girl", "لڑکی کی آواز", "👧", 1.45f, 1.05f, "Sweet, high-pitch feminine voice"),
    DEEP_MALE("Deep Male", "مردانہ / لڑکا آواز", "👨", 0.72f, 0.95f, "Deep baritone, authoritative male tone"),
    CHIPMUNK("Chipmunk", "چپمنک تیز آواز", "🐿️", 1.80f, 1.15f, "Funny ultra high-pitch cartoon voice"),
    ROBOT("Cyber Robot", "روبوٹ آواز", "🤖", 0.88f, 0.95f, "Futuristic cyber synthetic tone"),
    MONSTER("Deep Monster", "راکشس بھاری آواز", "👹", 0.55f, 0.88f, "Heavy beast resonant rumble"),
    RADIO("Old Radio", "ریڈیو ایفیکٹ", "📻", 1.15f, 1.0f, "Vintage radio lo-fi megaphone voice"),
    STUDIO_PODCAST("Studio Warmth", "سٹوڈیو پوڈکاسٹ", "🎙️", 0.96f, 1.0f, "Crisp warm broadcaster studio voice")
}

enum class TtsVoiceGender(
    val displayName: String,
    val urduLabel: String,
    val pitch: Float,
    val speed: Float,
    val icon: String,
    val tag: String
) {
    FEMALE("Girl / Female", "لڑکی کی آواز", 1.42f, 1.02f, "👧", "Sweet Girl"),
    MALE("Boy / Male", "لڑکے کی آواز", 0.74f, 0.95f, "👨", "Deep Guy"),
    SWEET_NARRATOR("Storyteller Girl", "پیاری کہانی آواز", 1.25f, 0.92f, "👩", "Soft Tale"),
    DEEP_BROADCASTER("Pro Broadcaster", "گھمبیر براڈکاسٹر", 0.65f, 0.95f, "🎙️", "Pro Mic"),
    CYBER_AI("Cyber Bot", "سائبر روبوٹ", 0.90f, 1.10f, "🤖", "Neural AI")
}

enum class SoundEffectType(
    val title: String,
    val urduTitle: String,
    val icon: String,
    val category: String,
    val durationMs: Int
) {
    WHOOSH("Cinematic Whoosh", "تیز ہوا وش", "💨", "Transitions", 600),
    DING("Ding / Bell Notification", "گھنٹی ڈنگ", "🔔", "Notices", 800),
    CAMERA("Camera Shutter Click", "کیمرہ کلک", "📸", "Action", 350),
    CYBER_ZAP("Cyber Glitch Zap", "سائبر جھٹکا", "⚡", "Futuristic", 700),
    IMPACT("Deep Sub Boom", "دھماکہ سب بوم", "💥", "Cinematic", 900),
    POP("Bubble Pop", "ببل پاپ", "💧", "Cute", 250)
}

/**
 * AI Voice Cloning Profile:
 * Stores acoustic parameters extracted from a 10-20 sec sample of the user's voice
 */
data class VoiceCloneProfile(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "My Voice (Mine)",
    val urduName: String = "میری اصلی آواز",
    val sampleUri: Uri? = null,
    val sampleDurationSec: Int = 15,
    val detectedPitchHz: Float = 142f,
    val recommendedPitch: Float = 1.0f,
    val recommendedSpeed: Float = 1.0f,
    val gender: TtsVoiceGender = TtsVoiceGender.MALE,
    val toneWarmth: Float = 1.0f,
    val isTrained: Boolean = true,
    val createdTimeMs: Long = System.currentTimeMillis()
)

/**
 * Rhythm Beat Marker for Timeline Auto Beat Sync
 */
data class BeatMarker(
    val timeMs: Long,
    val intensity: Float = 0.8f,
    val isDownbeat: Boolean = false
)

/**
 * 2027 Next-Gen Velocity Speed Curves (CapCut-grade)
 */
enum class SpeedCurvePreset(
    val title: String,
    val urduTitle: String,
    val icon: String,
    val description: String,
    val points: List<Float>
) {
    STANDARD("Linear", "سیدھی رفتار", "➡️", "Uniform speed across clip", listOf(1.0f, 1.0f, 1.0f, 1.0f, 1.0f)),
    HERO_MONTAGE("Hero Velocity", "ہیرو مونتاج و رفتار", "⚡", "Slow-mo drop on beat, fast snap ramp", listOf(1.0f, 0.25f, 3.2f, 1.5f, 1.0f)),
    BULLET_TIME("Bullet Matrix", "بلٹ ٹائم فریز", "🎬", "Smooth flow into deep freeze, launch punch", listOf(1.2f, 0.15f, 0.15f, 2.8f, 1.0f)),
    WAVE_FLOW("Montage Wave", "موجی لہر رفتار", "🌊", "Harmonic sine velocity wave for b-roll", listOf(0.5f, 2.2f, 0.4f, 2.5f, 0.8f)),
    JUMP_RAMP("Jump Ramp", "تیز اڑان", "🔥", "Progressive acceleration into fast climax", listOf(0.4f, 0.7f, 1.4f, 2.8f, 4.0f)),
    BEAT_PULSE("Beat Pulse", "بیٹ پلس دھڑکن", "🎵", "Rhythmic pulse synced to music drops", listOf(1.5f, 0.3f, 2.5f, 0.3f, 1.8f))
}
