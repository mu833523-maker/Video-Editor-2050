package com.ve2050.editor

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ve2050.editor.auth.AuthService
import com.ve2050.editor.engine.NotificationEngine
import com.ve2050.editor.ui.EditorScreen
import com.ve2050.editor.ui.HomeScreen
import com.ve2050.editor.ui.theme.VE2050Theme

open class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AuthService.isFirebaseReady(this)
        NotificationEngine.createNotificationChannel(this)
        setContent {
            VE2050Theme {
                val context = LocalContext.current
                val notifLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission(),
                    onResult = {}
                )

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                val nav = rememberNavController()
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    enterTransition = {
                        fadeIn(animationSpec = tween(250)) +
                            slideIntoContainer(
                                towards = AnimatedContentTransitionScope.SlideDirection.Start,
                                animationSpec = tween(250)
                            )
                    },
                    exitTransition = {
                        fadeOut(animationSpec = tween(200))
                    },
                    popEnterTransition = {
                        fadeIn(animationSpec = tween(200))
                    },
                    popExitTransition = {
                        fadeOut(animationSpec = tween(250)) +
                            slideOutOfContainer(
                                towards = AnimatedContentTransitionScope.SlideDirection.End,
                                animationSpec = tween(250)
                            )
                    }
                ) {
                    composable("home") {
                        HomeScreen(onNewProject = { nav.navigate("editor") })
                    }
                    composable("editor") {
                        EditorScreen(onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
