package com.ve2050.editor.ui.speed

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.ve2050.editor.model.SpeedCurvePreset

/**
 * 2027 Pro Level Velocity & Speed Curve Studio
 * Interactive Bezier Speed Curve Canvas + Preset Velocity Montages
 */
@Composable
fun SpeedCurveStudioDialog(
    initialSpeed: Float = 1.0f,
    onDismiss: () -> Unit,
    onApplySpeedCurve: (preset: SpeedCurvePreset, averageSpeed: Float) -> Unit
) {
    var selectedPreset by remember { mutableStateOf(SpeedCurvePreset.HERO_MONTAGE) }
    var curvePoints by remember { mutableStateOf(selectedPreset.points.toMutableList()) }

    // When preset changes, load its control points
    LaunchedEffect(selectedPreset) {
        curvePoints = selectedPreset.points.toMutableList()
    }

    // Live preview playback simulation
    var isPreviewing by remember { mutableStateOf(false) }
    val infiniteTransition = rememberInfiniteTransition(label = "speedCurvePlayhead")
    val previewProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "progress"
    )

    // Current speed under preview playhead
    val currentSampledSpeed by remember(previewProgress, curvePoints) {
        derivedStateOf {
            if (curvePoints.isEmpty()) 1.0f
            else {
                val indexFloat = previewProgress * (curvePoints.size - 1)
                val idx = indexFloat.toInt().coerceIn(0, curvePoints.size - 1)
                val nextIdx = (idx + 1).coerceAtMost(curvePoints.size - 1)
                val frac = indexFloat - idx
                val v1 = curvePoints[idx]
                val v2 = curvePoints[nextIdx]
                v1 + (v2 - v1) * frac
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(24.dp))
                .border(
                    1.dp,
                    Brush.linearGradient(
                        listOf(Color(0xFF00E5FF), Color(0xFF9D4EDD), Color(0xFF00E5FF).copy(alpha = 0.2f))
                    ),
                    RoundedCornerShape(24.dp)
                ),
            color = Color(0xFF0D0F18)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF00E5FF).copy(alpha = 0.15f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("⚡", fontSize = 20.sp)
                            }
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "2027 Velocity Curve Studio",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFFFB703).copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        "OPTICAL FLOW",
                                        color = Color(0xFFFFB703),
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                "رفتار کا وکر اور اسپیڈ مونتاج (CapCut Pro Velocity)",
                                color = Color(0xFF00E5FF),
                                fontSize = 10.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                Spacer(Modifier.height(14.dp))

                // Interactive Speed Curve Canvas
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF090A10),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF202334)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Box(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                        // Speed readout overlay
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    "Current Speed: ${String.format("%.2f", currentSampledSpeed)}x",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    selectedPreset.title,
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF141724),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C3048))
                            ) {
                                Text(
                                    "0.1x – 5.0x Range",
                                    color = Color(0xFF9E9EAE),
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }

                        // Canvas drawing curve & nodes
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 40.dp, bottom = 20.dp)
                                .pointerInput(curvePoints) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        val canvasW = size.width
                                        val canvasH = size.height
                                        val touchX = change.position.x
                                        val touchY = change.position.y

                                        // Find closest node along X
                                        var closestIdx = 0
                                        var minDist = Float.MAX_VALUE
                                        for (i in curvePoints.indices) {
                                            val nodeX = (i.toFloat() / (curvePoints.size - 1)) * canvasW
                                            val d = kotlin.math.abs(nodeX - touchX)
                                            if (d < minDist) {
                                                minDist = d
                                                closestIdx = i
                                            }
                                        }

                                        // Map touchY (0 at top = 5x, canvasH at bottom = 0.1x)
                                        val newSpeed = ((1f - (touchY / canvasH).coerceIn(0f, 1f)) * 4.9f + 0.1f)
                                        val updated = curvePoints.toMutableList()
                                        updated[closestIdx] = newSpeed
                                        curvePoints = updated
                                    }
                                }
                        ) {
                            val w = size.width
                            val h = size.height

                            // Draw subtle grid lines (1x line, 2x line, 4x line)
                            val oneXLineY = h * (1f - (1f - 0.1f) / 4.9f)
                            drawLine(
                                color = Color(0xFF333850),
                                start = Offset(0f, oneXLineY),
                                end = Offset(w, oneXLineY),
                                strokeWidth = 1.dp.toPx()
                            )

                            // Construct smooth Bezier path across points
                            val path = Path()
                            val fillPath = Path()

                            val pointOffsets = curvePoints.mapIndexed { i, speed ->
                                val x = (i.toFloat() / (curvePoints.size - 1)) * w
                                val normalizedY = (speed.coerceIn(0.1f, 5.0f) - 0.1f) / 4.9f
                                val y = h * (1f - normalizedY)
                                Offset(x, y)
                            }

                            if (pointOffsets.isNotEmpty()) {
                                path.moveTo(pointOffsets[0].x, pointOffsets[0].y)
                                fillPath.moveTo(pointOffsets[0].x, h)
                                fillPath.lineTo(pointOffsets[0].x, pointOffsets[0].y)

                                for (i in 0 until pointOffsets.size - 1) {
                                    val p0 = pointOffsets[i]
                                    val p1 = pointOffsets[i + 1]
                                    val cx = (p0.x + p1.x) / 2f
                                    path.cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
                                    fillPath.cubicTo(cx, p0.y, cx, p1.y, p1.x, p1.y)
                                }

                                fillPath.lineTo(w, h)
                                fillPath.close()

                                // Draw gradient area fill
                                drawPath(
                                    path = fillPath,
                                    brush = Brush.verticalGradient(
                                        listOf(Color(0xFF00E5FF).copy(alpha = 0.35f), Color(0xFF7000FF).copy(alpha = 0.05f))
                                    )
                                )

                                // Draw main neon glow stroke
                                drawPath(
                                    path = path,
                                    brush = Brush.horizontalGradient(
                                        listOf(Color(0xFF00E5FF), Color(0xFFD946EF), Color(0xFF00E5FF))
                                    ),
                                    style = Stroke(width = 3.5.dp.toPx())
                                )

                                // Draw control nodes
                                pointOffsets.forEachIndexed { idx, pt ->
                                    drawCircle(
                                        color = Color(0xFF00E5FF),
                                        radius = 7.dp.toPx(),
                                        center = pt
                                    )
                                    drawCircle(
                                        color = Color.White,
                                        radius = 3.5.dp.toPx(),
                                        center = pt
                                    )
                                }

                                // Draw animated playhead scrubbing line
                                val playheadX = previewProgress * w
                                drawLine(
                                    color = Color(0xFFFFD700),
                                    start = Offset(playheadX, 0f),
                                    end = Offset(playheadX, h),
                                    strokeWidth = 2.dp.toPx()
                                )
                                drawCircle(
                                    color = Color(0xFFFFD700),
                                    radius = 5.dp.toPx(),
                                    center = Offset(playheadX, 0f)
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                // Velocity Presets Row
                Text(
                    "Select Velocity Preset (وکر کا انتخاب)",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(8.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(SpeedCurvePreset.values()) { preset ->
                        val isSelected = selectedPreset == preset
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) Color(0xFF00E5FF).copy(alpha = 0.18f) else Color(0xFF141724),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) Color(0xFF00E5FF) else Color(0xFF262A3C)
                            ),
                            modifier = Modifier
                                .width(135.dp)
                                .clickable { selectedPreset = preset }
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(preset.icon, fontSize = 16.sp)
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        preset.title,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    preset.urduTitle,
                                    color = if (isSelected) Color(0xFF80EAFF) else Color.Gray,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF33384D)),
                        modifier = Modifier.weight(1f).height(46.dp)
                    ) {
                        Text("Cancel", color = Color.LightGray, fontSize = 13.sp)
                    }

                    Button(
                        onClick = {
                            val avg = if (curvePoints.isNotEmpty()) curvePoints.average().toFloat() else 1f
                            onApplySpeedCurve(selectedPreset, avg)
                            onDismiss()
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00E5FF)
                        ),
                        modifier = Modifier.weight(1.4f).height(46.dp)
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "Apply Curve",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}
