package com.ve2050.editor.engine

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object NotificationEngine {

    private const val CHANNEL_ID = "ve2050_export_channel"
    private const val CHANNEL_NAME = "Video Export & Alerts"
    private const val CHANNEL_DESC = "Notifications for video rendering progress and completed exports"

    private const val PROGRESS_NOTIFICATION_ID = 20501
    private const val SUCCESS_NOTIFICATION_ID = 20502
    private const val ERROR_NOTIFICATION_ID = 20503

    private var isChannelCreated = false

    fun createNotificationChannel(context: Context) {
        if (isChannelCreated) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = CHANNEL_DESC
                enableVibration(true)
                setShowBadge(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
        isChannelCreated = true
    }

    fun showExportProgress(context: Context, progressPercent: Int) {
        try {
            createNotificationChannel(context)
            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Exporting Video")
                .setContentText("Rendering at pro quality • $progressPercent%")
                .setProgress(100, progressPercent, false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)

            val manager = NotificationManagerCompat.from(context)
            manager.notify(PROGRESS_NOTIFICATION_ID, builder.build())
        } catch (_: SecurityException) {
            // Android 13+ permission not granted yet - fail gracefully
        } catch (_: Exception) {}
    }

    fun showExportSuccess(context: Context, videoUri: Uri?) {
        try {
            createNotificationChannel(context)
            dismissProgress(context)

            // Content intent to open the exported video
            val viewIntent = if (videoUri != null) {
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(videoUri, "video/mp4")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                context.packageManager.getLaunchIntentForPackage(context.packageName)
            }

            val pendingIntent = viewIntent?.let {
                PendingIntent.getActivity(
                    context,
                    0,
                    it,
                    PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
                )
            }

            // Share action intent directly from notification
            val shareAction = videoUri?.let { uri ->
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooserIntent = Intent.createChooser(shareIntent, "Share Video")
                val sharePendingIntent = PendingIntent.getActivity(
                    context,
                    1,
                    chooserIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
                )
                NotificationCompat.Action.Builder(
                    android.R.drawable.ic_menu_share,
                    "Share Video",
                    sharePendingIntent
                ).build()
            }

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Export Complete! 🎉")
                .setContentText("Your video is saved to Gallery / Movies folder.")
                .setStyle(NotificationCompat.BigTextStyle().bigText("Your video has been rendered successfully and saved to your Movies folder in high definition. Tap to play."))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)

            if (pendingIntent != null) {
                builder.setContentIntent(pendingIntent)
            }
            if (shareAction != null) {
                builder.addAction(shareAction)
            }

            val manager = NotificationManagerCompat.from(context)
            manager.notify(SUCCESS_NOTIFICATION_ID, builder.build())
        } catch (_: SecurityException) {
            // Android 13+ permission not granted yet - fail gracefully
        } catch (_: Exception) {}
    }

    fun showExportError(context: Context, errorMessage: String) {
        try {
            createNotificationChannel(context)
            dismissProgress(context)

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Export Failed")
                .setContentText(errorMessage)
                .setStyle(NotificationCompat.BigTextStyle().bigText(errorMessage))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)

            val manager = NotificationManagerCompat.from(context)
            manager.notify(ERROR_NOTIFICATION_ID, builder.build())
        } catch (_: SecurityException) {
        } catch (_: Exception) {}
    }

    fun dismissProgress(context: Context) {
        try {
            val manager = NotificationManagerCompat.from(context)
            manager.cancel(PROGRESS_NOTIFICATION_ID)
        } catch (_: Exception) {}
    }
}
