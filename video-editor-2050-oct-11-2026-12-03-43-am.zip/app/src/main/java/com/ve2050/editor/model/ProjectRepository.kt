package com.ve2050.editor.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ProjectDraft(
    val id: String,
    val title: String,
    val clipsCount: Int,
    val durationMs: Long,
    val updatedAt: Long,
    val aspectRatio: String = "9:16"
)

object ProjectRepository {
    private const val PREFS_NAME = "ve_projects_store"
    private const val KEY_PROJECTS = "saved_projects"

    fun getProjects(context: Context): List<ProjectDraft> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_PROJECTS, null) ?: return emptyList()
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<ProjectDraft>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    ProjectDraft(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        clipsCount = obj.getInt("clipsCount"),
                        durationMs = obj.getLong("durationMs"),
                        updatedAt = obj.getLong("updatedAt"),
                        aspectRatio = obj.optString("aspectRatio", "9:16")
                    )
                )
            }
            list.sortedByDescending { it.updatedAt }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveProject(context: Context, draft: ProjectDraft) {
        val current = getProjects(context).toMutableList()
        val index = current.indexOfFirst { it.id == draft.id }
        if (index >= 0) {
            current[index] = draft
        } else {
            current.add(0, draft)
        }
        persist(context, current)
    }

    fun deleteProject(context: Context, id: String) {
        val current = getProjects(context).filter { it.id != id }
        persist(context, current)
    }

    private fun persist(context: Context, list: List<ProjectDraft>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("title", item.title)
                put("clipsCount", item.clipsCount)
                put("durationMs", item.durationMs)
                put("updatedAt", item.updatedAt)
                put("aspectRatio", item.aspectRatio)
            }
            array.put(obj)
        }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PROJECTS, array.toString()).apply()
    }
}
