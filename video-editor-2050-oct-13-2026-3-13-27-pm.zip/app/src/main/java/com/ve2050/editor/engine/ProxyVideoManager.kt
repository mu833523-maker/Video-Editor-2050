package com.ve2050.editor.engine

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

/**
 * High-performance Proxy Video Manager:
 * Generates low-resolution, lightweight 540p proxy files in the background using Media3 Transformer
 * for silky-smooth 60fps preview and scrubbing in ExoPlayer without decoder hitching.
 * The original high-resolution video file is preserved untouched for final export.
 */
@OptIn(UnstableApi::class)
object ProxyVideoManager {

    private val proxyCache = mutableMapOf<String, Uri>()
    private val _isOptimizing = MutableStateFlow(false)
    val isOptimizing: StateFlow<Boolean> = _isOptimizing.asStateFlow()

    fun getCachedProxy(uri: Uri): Uri? {
        val key = uri.toString()
        val cached = proxyCache[key]
        if (cached != null) {
            val file = File(cached.path ?: "")
            if (file.exists() && file.length() > 0) return cached
        }
        return null
    }

    suspend fun generateProxy(
        context: Context,
        originalUri: Uri,
        targetHeight: Int = 540,
        onReady: (Uri) -> Unit
    ) = withContext(Dispatchers.IO) {
        if (originalUri == Uri.EMPTY) return@withContext
        val key = originalUri.toString()
        val cached = getCachedProxy(originalUri)
        if (cached != null) {
            withContext(Dispatchers.Main) { onReady(cached) }
            return@withContext
        }

        // Check if video is already low resolution
        var origHeight = 0
        var retriever: MediaMetadataRetriever? = null
        try {
            retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, originalUri)
            val hStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            origHeight = hStr?.toIntOrNull() ?: 0
        } catch (_: Exception) {
        } finally {
            try { retriever?.release() } catch (_: Exception) {}
        }

        if (origHeight in 1..targetHeight) {
            // Already <= 540p, original is lightweight enough
            proxyCache[key] = originalUri
            withContext(Dispatchers.Main) { onReady(originalUri) }
            return@withContext
        }

        val proxyDir = File(context.cacheDir, "proxies").apply { mkdirs() }
        val hash = try {
            MessageDigest.getInstance("MD5").digest(originalUri.toString().toByteArray())
                .joinToString("") { "%02x".format(it) }.take(12)
        } catch (_: Exception) {
            originalUri.hashCode().toString()
        }
        val proxyFile = File(proxyDir, "proxy_${hash}_${targetHeight}p.mp4")

        if (proxyFile.exists() && proxyFile.length() > 2048) {
            val proxyUri = Uri.fromFile(proxyFile)
            proxyCache[key] = proxyUri
            withContext(Dispatchers.Main) { onReady(proxyUri) }
            return@withContext
        }

        try {
            _isOptimizing.value = true
            val editedItem = EditedMediaItem.Builder(MediaItem.fromUri(originalUri))
                .setEffects(Effects(emptyList(), listOf(Presentation.createForHeight(targetHeight))))
                .build()

            val composition = Composition.Builder(
                EditedMediaItemSequence(listOf(editedItem))
            ).build()

            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(c: Composition, r: ExportResult) {
                        _isOptimizing.value = false
                        val proxyUri = Uri.fromFile(proxyFile)
                        proxyCache[key] = proxyUri
                        onReady(proxyUri)
                    }

                    override fun onError(c: Composition, r: ExportResult, e: ExportException) {
                        _isOptimizing.value = false
                        try { proxyFile.delete() } catch (_: Exception) {}
                    }
                })
                .build()

            withContext(Dispatchers.Main) {
                transformer.start(composition, proxyFile.absolutePath)
            }
        } catch (e: Exception) {
            _isOptimizing.value = false
            proxyCache[key] = originalUri
            withContext(Dispatchers.Main) { onReady(originalUri) }
        }
    }
}
