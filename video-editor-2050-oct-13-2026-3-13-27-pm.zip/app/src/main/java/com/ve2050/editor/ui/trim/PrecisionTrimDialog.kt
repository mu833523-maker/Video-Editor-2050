package com.ve2050.editor.ui.trim

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PrecisionTrimDialog(
    initialStartMs: Long,
    initialEndMs: Long,
    maxDurationMs: Long,
    onDismiss: () -> Unit,
    onApply: (startMs: Long, endMs: Long) -> Unit
) {
    var startMs by remember { mutableLongStateOf(initialStartMs) }
    var endMs by remember { mutableLongStateOf(initialEndMs) }

    val currentDurationMs = (endMs - startMs).coerceAtLeast(500L)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF14141E),
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.ContentCut,
                    contentDescription = null,
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "Precision Trim",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Duration banner
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF1B2836),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "TRIMMED DURATION",
                            color = Color(0xFF88AABB),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "${String.format("%.2f", currentDurationMs / 1000f)}s",
                            color = Color(0xFF00E5FF),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))

                // Start Trim Controls
                Text("TRIM IN (START): ${String.format("%.2f", startMs / 1000f)}s", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(
                        onClick = { startMs = (startMs - 500L).coerceAtLeast(0L) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("-0.5s", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { startMs = (startMs - 100L).coerceAtLeast(0L) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("-0.1s", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { startMs = (startMs + 100L).coerceAtMost(endMs - 500L) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("+0.1s", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { startMs = (startMs + 500L).coerceAtMost(endMs - 500L) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("+0.5s", fontSize = 11.sp)
                    }
                }

                Spacer(Modifier.height(16.dp))

                // End Trim Controls
                Text("TRIM OUT (END): ${String.format("%.2f", endMs / 1000f)}s", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedButton(
                        onClick = { endMs = (endMs - 500L).coerceAtLeast(startMs + 500L) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("-0.5s", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { endMs = (endMs - 100L).coerceAtLeast(startMs + 500L) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("-0.1s", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { endMs = (endMs + 100L).coerceAtMost(maxOf(maxDurationMs, endMs + 5000L)) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("+0.1s", fontSize = 11.sp)
                    }
                    OutlinedButton(
                        onClick = { endMs = (endMs + 500L).coerceAtMost(maxOf(maxDurationMs, endMs + 5000L)) },
                        modifier = Modifier.weight(1f).height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("+0.5s", fontSize = 11.sp)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onApply(startMs, endMs) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00E5FF),
                    contentColor = Color.Black
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.height(48.dp)
            ) {
                Text("APPLY TRIM", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.height(48.dp)
            ) {
                Text("CANCEL", color = Color(0xFFAAAAAA))
            }
        }
    )
}
