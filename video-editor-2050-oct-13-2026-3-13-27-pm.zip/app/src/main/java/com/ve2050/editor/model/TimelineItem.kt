package com.ve2050.editor.model

import android.net.Uri

enum class TimelineItemType {
    VIDEO,
    OVERLAY,
    AUDIO,
    TEXT,
    STICKER,
    EFFECT,
    FILTER
}

data class TimelineEffectClip(
    val id: String = java.util.UUID.randomUUID().toString(),
    val filter: VideoFilter,
    val title: String = filter.displayName,
    val startMs: Long = 0L,
    val durationMs: Long = 4000L,
    val intensity: Float = 1.0f,
    val layer: Int = 0
) {
    val endMs: Long get() = startMs + durationMs
}

data class TimelineStickerClip(
    val id: String = java.util.UUID.randomUUID().toString(),
    val textOrEmoji: String,
    val title: String,
    val startMs: Long = 0L,
    val durationMs: Long = 3000L,
    val x: Float = 0f,
    val y: Float = 0f,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val layer: Int = 0
) {
    val endMs: Long get() = startMs + durationMs
}

data class TimelineAudioClip(
    val id: String = java.util.UUID.randomUUID().toString(),
    val uri: Uri,
    val title: String = "Audio",
    val startMs: Long = 0L,
    val durationMs: Long = 5000L,
    val volume: Float = 1.0f,
    val layer: Int = 0
) {
    val endMs: Long get() = startMs + durationMs
}
