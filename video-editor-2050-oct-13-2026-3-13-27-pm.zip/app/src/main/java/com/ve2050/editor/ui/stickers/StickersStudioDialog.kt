package com.ve2050.editor.ui.stickers

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ve2050.editor.model.TextAnimation
import com.ve2050.editor.model.TextOverlay
import com.ve2050.editor.model.TextPreset

data class StickerItem(
    val title: String,
    val icon: String,
    val preset: TextPreset = TextPreset.CYBER_NEON,
    val animation: TextAnimation = TextAnimation.POP,
    val badgeColor: Long = 0xFF00E5FF
)

enum class StickerCategory(val label: String, val icon: String) {
    VLOG("Vlog & Social", "🎬"),
    REACTIONS("Reactions", "🔥"),
    WEDDING("Wedding & Shadi", "💍"),
    CYBER("Cyber Neon", "⚡"),
    BADGES("Pro Badges", "🏷️")
}

@Composable
fun StickersStudioDialog(
    currentPlayheadMs: Long,
    onDismiss: () -> Unit,
    onAddSticker: (TextOverlay) -> Unit
) {
    var selectedCategory by remember { mutableStateOf(StickerCategory.VLOG) }

    val stickersMap = remember {
        mapOf(
            StickerCategory.VLOG to listOf(
                StickerItem("SUBSCRIBE", "🔔", TextPreset.FIRE_BLAZE, TextAnimation.BOUNCE, 0xFFFF0055),
                StickerItem("LIKE & SHARE", "👍", TextPreset.CYBER_NEON, TextAnimation.POP, 0xFF00E5FF),
                StickerItem("NEW VLOG", "📹", TextPreset.GOLDEN_METALLIC, TextAnimation.SLIDE, 0xFFFFD700),
                StickerItem("4K ULTRA HD", "💎", TextPreset.CHROME_FROST, TextAnimation.POP, 0xFF00FFCC),
                StickerItem("WATCH TILL END", "👀", TextPreset.MINIMAL_CAPTION, TextAnimation.FADE, 0xFFFFFFFF),
                StickerItem("COMMENT BELOW", "💬", TextPreset.NEWS_BANNER, TextAnimation.SLIDE, 0xFF38BDF8)
            ),
            StickerCategory.REACTIONS to listOf(
                StickerItem("FIRE 🔥", "🔥", TextPreset.FIRE_BLAZE, TextAnimation.POP, 0xFFFF5500),
                StickerItem("LOVE IT ❤️", "💖", TextPreset.GOLDEN_METALLIC, TextAnimation.BOUNCE, 0xFFFF3377),
                StickerItem("OMG! 😱", "⚡", TextPreset.QUANTUM_GLITCH, TextAnimation.POP, 0xFFFFCC00),
                StickerItem("PARTY 🎉", "🎊", TextPreset.CYBER_NEON, TextAnimation.BOUNCE, 0xFF00FF88),
                StickerItem("ROCKET 🚀", "🚀", TextPreset.FIRE_BLAZE, TextAnimation.SLIDE, 0xFFFF4400),
                StickerItem("100% PERFECT 💯", "💯", TextPreset.GOLDEN_METALLIC, TextAnimation.POP, 0xFFFFD700)
            ),
            StickerCategory.WEDDING to listOf(
                StickerItem("گلاب کے پھول 🌹", "🌹", TextPreset.URDU_NASTALIQ, TextAnimation.FADE, 0xFFFF2266),
                StickerItem("شادی مبارک 💍", "💍", TextPreset.GOLDEN_METALLIC, TextAnimation.POP, 0xFFFFD700),
                StickerItem("محبت اور دل 💖", "💖", TextPreset.GOLDEN_METALLIC, TextAnimation.BOUNCE, 0xFFFF4081),
                StickerItem("بارات و جشن 🎊", "🎊", TextPreset.URDU_NASTALIQ, TextAnimation.POP, 0xFFFF9900),
                StickerItem("گولڈن چمک ✨", "✨", TextPreset.GOLDEN_METALLIC, TextAnimation.FADE, 0xFFFFEA00),
                StickerItem("مہندی نائٹ 🌸", "🌸", TextPreset.URDU_NASTALIQ, TextAnimation.POP, 0xFF00E676)
            ),
            StickerCategory.CYBER to listOf(
                StickerItem("CYBERPUNK 2050", "🌌", TextPreset.CYBER_NEON, TextAnimation.POP, 0xFF00E5FF),
                StickerItem("NEON ARROW ➔", "➔", TextPreset.CYBER_NEON, TextAnimation.SLIDE, 0xFF00FF88),
                StickerItem("QUANTUM GLITCH", "⚡", TextPreset.QUANTUM_GLITCH, TextAnimation.POP, 0xFFFF0055),
                StickerItem("MATRIX CODE", "📟", TextPreset.EMERALD_MATRIX, TextAnimation.TYPEWRITER, 0xFF00FF66),
                StickerItem("WARNING / DANGER", "⚠️", TextPreset.FIRE_BLAZE, TextAnimation.BOUNCE, 0xFFFFCC00),
                StickerItem("SYNTHWAVE SUNSET", "🌆", TextPreset.RETRO_SYNTHWAVE, TextAnimation.FADE, 0xFFFF77AA)
            ),
            StickerCategory.BADGES to listOf(
                StickerItem("★ PRO CREATOR", "⭐", TextPreset.GOLDEN_METALLIC, TextAnimation.POP, 0xFFFFD700),
                StickerItem("🔴 LIVE NOW", "🔴", TextPreset.FIRE_BLAZE, TextAnimation.BOUNCE, 0xFFFF0000),
                StickerItem("TRENDING #1", "📈", TextPreset.CYBER_NEON, TextAnimation.POP, 0xFF00E5FF),
                StickerItem("VIP EDITION", "👑", TextPreset.GOLDEN_METALLIC, TextAnimation.POP, 0xFFFFD700),
                StickerItem("VERIFIED ✓", "✓", TextPreset.CHROME_FROST, TextAnimation.POP, 0xFF00E5FF),
                StickerItem("HOT DROP 🔥", "🔥", TextPreset.FIRE_BLAZE, TextAnimation.SLIDE, 0xFFFF3300)
            )
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF14141E),
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Stickers & Badges",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray, modifier = Modifier.size(18.dp))
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Category tabs
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(StickerCategory.values()) { cat ->
                        val isSelected = (selectedCategory == cat)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF1C1C2A),
                            modifier = Modifier.clickable { selectedCategory = cat }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(cat.icon, fontSize = 12.sp)
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    cat.label,
                                    color = if (isSelected) Color.Black else Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                // Stickers grid
                val currentStickers = stickersMap[selectedCategory] ?: emptyList()
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.height(260.dp)
                ) {
                    items(currentStickers) { sticker ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1A1A28),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(sticker.badgeColor).copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(64.dp)
                                .clickable {
                                    val newOverlay = TextOverlay(
                                        text = sticker.title,
                                        startMs = currentPlayheadMs,
                                        endMs = currentPlayheadMs + 4000L,
                                        preset = sticker.preset,
                                        animIn = sticker.animation,
                                        color = sticker.badgeColor.toInt(),
                                        sizeSp = 24f,
                                        isBold = true
                                    )
                                    onAddSticker(newOverlay)
                                    onDismiss()
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(sticker.icon, fontSize = 22.sp)
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(
                                        sticker.title,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                    Text(
                                        "Tap to insert",
                                        color = Color(sticker.badgeColor),
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {}
    )
}
