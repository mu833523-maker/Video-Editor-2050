package com.ve2050.editor.model

/**
 * Immutable Single Source of Truth for timeline and playback state.
 * Shared across TimelineView, PlayerManager, EditorViewModel, and all tool views.
 */
data class TimelineState(
    val playheadMs: Long = 0L,
    val totalDurationMs: Long = 0L,
    val isPlaying: Boolean = false,
    val isScrubbing: Boolean = false,
    val zoomFactor: Float = 1.0f,
    val selectedTrackType: TrackType = TrackType.VIDEO,
    val selectedClipIndex: Int = 0,
    val selectedClipId: String? = null,
    val selectedTextId: String? = null,
    val isOverlaySelected: Boolean = false,
    val isAudioSelected: Boolean = false,
    val isSnappedToCut: Boolean = false
) {
    val currentSeconds: Float get() = playheadMs / 1000f
    val totalSeconds: Float get() = totalDurationMs / 1000f
    val formattedTimecode: String get() {
        val mins = playheadMs / 60000
        val secs = (playheadMs % 60000) / 1000
        val millis = (playheadMs % 1000) / 10
        return String.format("%02d:%02d.%02d", mins, secs, millis)
    }
}
