package com.ve2050.editor.ui.vfx

import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.ve2050.editor.model.VideoFilter
import kotlin.math.PI
import kotlin.math.sin

private data class PetalParticle(
    val initialXRatio: Float,
    val speed: Float,
    val sizePx: Float,
    val swayAmplitude: Float,
    val swayFrequency: Float,
    val initialPhase: Float,
    val isDeepRed: Boolean
)

private data class BokehParticle(
    val xRatio: Float,
    val yRatio: Float,
    val radiusPx: Float,
    val pulseSpeed: Float,
    val maxAlpha: Float,
    val isSparkle: Boolean
)

private data class HeartParticle(
    val xRatio: Float,
    val speed: Float,
    val sizePx: Float,
    val swayPhase: Float
)

private data class ConfettiParticle(
    val xRatio: Float,
    val speed: Float,
    val widthPx: Float,
    val heightPx: Float,
    val color: Color,
    val rotationSpeed: Float
)

private data class SnowflakeParticle(
    val xRatio: Float,
    val speed: Float,
    val radiusPx: Float,
    val swayPhase: Float
)

/**
 * CapCut-grade High Performance VFX Particle & Shader Overlay
 * Runs directly on 60fps Compose Canvas with zero battery drain or frame drops.
 */
@Composable
fun VfxShaderOverlay(
    filter: VideoFilter,
    intensity: Float = 1.0f,
    modifier: Modifier = Modifier
) {
    if (filter == VideoFilter.NONE) return

    val infiniteTransition = rememberInfiniteTransition(label = "vfx_anim")

    // Continuous progress cycle 0f..1f (6 seconds duration)
    val timeCycle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "timeCycle"
    )

    // Secondary faster cycle for pulsing / shimmering
    val shimmerCycle by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shimmerCycle"
    )

    Box(modifier = modifier.fillMaxSize()) {
        when (filter) {
            // ----------------------------------------------------
            // 1. WEDDING & CELEBRATION VFX
            // ----------------------------------------------------
            VideoFilter.SHADI_ROSE_PETALS -> {
                // Warm romantic tint layer
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0x22FF1493), Color(0x11FF69B4), Color(0x268B0000))
                            )
                        )
                )

                val petals = remember {
                    List(24) { i ->
                        PetalParticle(
                            initialXRatio = (i * 0.042f + (i * 0.17f) % 0.9f) % 1.0f,
                            speed = 0.6f + ((i * 37) % 50) / 100f,
                            sizePx = 18f + ((i * 19) % 22),
                            swayAmplitude = 30f + ((i * 23) % 40),
                            swayFrequency = 1.5f + ((i * 13) % 3),
                            initialPhase = ((i * 1.3f) % (2f * PI.toFloat())),
                            isDeepRed = i % 2 == 0
                        )
                    }
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    petals.forEachIndexed { idx, petal ->
                        val yProgress = (timeCycle * petal.speed + (idx * 0.07f)) % 1.0f
                        val y = yProgress * (h + petal.sizePx * 2) - petal.sizePx
                        val sway = sin((timeCycle * 2 * PI * petal.swayFrequency + petal.initialPhase).toDouble()).toFloat() * petal.swayAmplitude
                        val x = (petal.initialXRatio * w + sway).coerceIn(0f, w)
                        val angle = (timeCycle * 360f * petal.speed + idx * 45f) % 360f

                        rotate(degrees = angle, pivot = Offset(x, y)) {
                            drawRosePetal(
                                center = Offset(x, y),
                                size = petal.sizePx,
                                isDeepRed = petal.isDeepRed,
                                alpha = (0.85f * intensity).coerceIn(0.2f, 1f)
                            )
                        }
                    }
                }
            }

            VideoFilter.SHADI_GOLDEN_BOKEH -> {
                // Luxury Golden Ambient Grade
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0x25FFD700), Color(0x15FFA500), Color(0x301A0F00))
                            )
                        )
                )

                val bokehs = remember {
                    List(20) { i ->
                        BokehParticle(
                            xRatio = ((i * 53) % 100) / 100f,
                            yRatio = ((i * 71) % 100) / 100f,
                            radiusPx = 12f + ((i * 29) % 40),
                            pulseSpeed = 0.8f + ((i * 17) % 15) / 10f,
                            maxAlpha = 0.25f + ((i * 11) % 45) / 100f,
                            isSparkle = i % 3 == 0
                        )
                    }
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    bokehs.forEachIndexed { idx, bokeh ->
                        val yFloat = ((bokeh.yRatio - timeCycle * 0.4f * bokeh.pulseSpeed + 2f) % 1.0f) * h
                        val xFloat = (bokeh.xRatio * w + sin((timeCycle * 4f + idx).toDouble()).toFloat() * 15f)
                        val curAlpha = ((sin((timeCycle * 2 * PI * bokeh.pulseSpeed + idx).toDouble()).toFloat() + 1f) / 2f * bokeh.maxAlpha * intensity).coerceIn(0f, 1f)

                        if (bokeh.isSparkle) {
                            drawSparkleStar(
                                center = Offset(xFloat, yFloat),
                                radius = bokeh.radiusPx * 0.8f,
                                color = Color(0xFFFFF4D0).copy(alpha = curAlpha.coerceAtMost(0.9f))
                            )
                        } else {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(
                                        Color(0xFFFFDF70).copy(alpha = curAlpha),
                                        Color(0xFFFFB800).copy(alpha = curAlpha * 0.4f),
                                        Color.Transparent
                                    ),
                                    center = Offset(xFloat, yFloat),
                                    radius = bokeh.radiusPx
                                ),
                                radius = bokeh.radiusPx,
                                center = Offset(xFloat, yFloat)
                            )
                        }
                    }
                }
            }

            VideoFilter.ROMANTIC_HEARTS -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0x20FF1744), Color(0x10FF4081), Color(0x22880E4F))
                            )
                        )
                )

                val hearts = remember {
                    List(16) { i ->
                        HeartParticle(
                            xRatio = ((i * 61) % 100) / 100f,
                            speed = 0.5f + ((i * 31) % 40) / 100f,
                            sizePx = 16f + ((i * 17) % 20),
                            swayPhase = (i * 1.5f) % (2f * PI.toFloat())
                        )
                    }
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    hearts.forEachIndexed { idx, heart ->
                        val yProgress = (1.0f - (timeCycle * heart.speed + idx * 0.08f) % 1.0f)
                        val y = yProgress * (h + heart.sizePx * 2)
                        val sway = sin((timeCycle * 3f + heart.swayPhase).toDouble()).toFloat() * 20f
                        val x = (heart.xRatio * w + sway).coerceIn(10f, w - 10f)
                        val alpha = (sin(yProgress * PI).toFloat() * 0.8f * intensity).coerceIn(0.1f, 0.9f)

                        drawHeart(
                            center = Offset(x, y),
                            size = heart.sizePx,
                            color = Color(0xFFFF3366).copy(alpha = alpha)
                        )
                    }
                }
            }

            VideoFilter.SHADI_WARM_GLOW -> {
                // Festive Wedding Warm Lighting & Golden Glow
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0x35FFB300),
                                    Color(0x25FF6F00),
                                    Color(0x304A148C)
                                )
                            )
                        )
                )
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val pulse = (shimmerCycle * 0.35f * intensity)
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color(0xFFFFD54F).copy(alpha = pulse), Color.Transparent),
                            center = Offset(size.width * 0.5f, size.height * 0.4f),
                            radius = size.width * 0.7f
                        )
                    )
                }
            }

            VideoFilter.CELEBRATION_CONFETTI -> {
                val confettiList = remember {
                    val colors = listOf(
                        Color(0xFFFFD700), Color(0xFFFF2A6D), Color(0xFF00F0FF),
                        Color(0xFF00E676), Color(0xFFFF9100), Color(0xFFD500F9)
                    )
                    List(30) { i ->
                        ConfettiParticle(
                            xRatio = ((i * 37) % 100) / 100f,
                            speed = 0.7f + ((i * 29) % 60) / 100f,
                            widthPx = 10f + ((i * 7) % 8),
                            heightPx = 16f + ((i * 11) % 12),
                            color = colors[i % colors.size],
                            rotationSpeed = 180f + ((i * 47) % 200)
                        )
                    }
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    confettiList.forEachIndexed { idx, c ->
                        val yProgress = (timeCycle * c.speed + idx * 0.05f) % 1.0f
                        val y = yProgress * (h + 40f) - 20f
                        val sway = sin((timeCycle * 5f + idx).toDouble()).toFloat() * 18f
                        val x = (c.xRatio * w + sway).coerceIn(0f, w)
                        val angle = (timeCycle * c.rotationSpeed + idx * 30f) % 360f

                        rotate(degrees = angle, pivot = Offset(x, y)) {
                            drawRoundRect(
                                color = c.color.copy(alpha = (0.9f * intensity).coerceIn(0.2f, 1f)),
                                topLeft = Offset(x - c.widthPx / 2f, y - c.heightPx / 2f),
                                size = Size(c.widthPx, c.heightPx),
                                cornerRadius = CornerRadius(2f, 2f)
                            )
                        }
                    }
                }
            }

            VideoFilter.FAIRY_LIGHTS -> {
                val fireflies = remember {
                    List(18) { i ->
                        BokehParticle(
                            xRatio = ((i * 47) % 100) / 100f,
                            yRatio = ((i * 67) % 100) / 100f,
                            radiusPx = 8f + ((i * 13) % 12),
                            pulseSpeed = 1.2f + ((i * 23) % 20) / 10f,
                            maxAlpha = 0.5f + ((i * 19) % 40) / 100f,
                            isSparkle = true
                        )
                    }
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    fireflies.forEachIndexed { idx, f ->
                        val x = (f.xRatio * w + sin((timeCycle * 3f * f.pulseSpeed + idx).toDouble()).toFloat() * 30f)
                        val y = (f.yRatio * h + sin((timeCycle * 2.5f * f.pulseSpeed + idx * 2).toDouble()).toFloat() * 25f)
                        val alpha = ((sin((timeCycle * 2 * PI * f.pulseSpeed + idx).toDouble()).toFloat() + 1f) / 2f * f.maxAlpha * intensity).coerceIn(0f, 1f)

                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(
                                    Color(0xFFE8F5E9).copy(alpha = alpha),
                                    Color(0xFF69F0AE).copy(alpha = alpha * 0.6f),
                                    Color.Transparent
                                ),
                                center = Offset(x, y),
                                radius = f.radiusPx * 2f
                            ),
                            radius = f.radiusPx * 2f,
                            center = Offset(x, y)
                        )
                    }
                }
            }

            // ----------------------------------------------------
            // 2. ULTRA-HD & CLARITY ENHANCERS
            // ----------------------------------------------------
            VideoFilter.ULTRA_HD_4K -> {
                // High Micro-Contrast, Edge Sharpness Simulation, Deep Rich Tone
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0x1800E5FF),
                                    Color(0x08FFFFFF),
                                    Color(0x2805050A)
                                )
                            )
                        )
                )
                // Crisp Edge Vignette
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                listOf(Color.Transparent, Color(0x35000000))
                            )
                        )
                )
            }

            VideoFilter.HDR_VIVID -> {
                // Vivid Contrast & Punchy Saturation Overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0x18FF007F),
                                    Color(0x1400F5D4),
                                    Color(0x240A0A14)
                                )
                            )
                        )
                )
            }

            VideoFilter.CINEMA_GOLD -> {
                // Hollywood Teal & Orange Blockbuster Grade
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0x25FF9100),
                                    Color(0x12FFD54F),
                                    Color(0x32004D40)
                                )
                            )
                        )
                )
            }

            VideoFilter.BEAUTY_SKIN_GLOW -> {
                // Dreamy Skin Smoothing & Soft Facial Radiance
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0x22FFE0B2),
                                    Color(0x14F8BBD0),
                                    Color(0x18212121)
                                )
                            )
                        )
                )
            }

            VideoFilter.DRAMATIC_NOIR -> {
                // High contrast cinematic black and white with silver sheen
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0x40000000),
                                    Color(0x20FFFFFF),
                                    Color(0x50000000)
                                )
                            )
                        )
                )
            }

            // ----------------------------------------------------
            // 3. ATMOSPHERE & WEATHER
            // ----------------------------------------------------
            VideoFilter.WINTER_SNOW -> {
                val snowflakes = remember {
                    List(35) { i ->
                        SnowflakeParticle(
                            xRatio = ((i * 31) % 100) / 100f,
                            speed = 0.5f + ((i * 19) % 50) / 100f,
                            radiusPx = 2f + ((i * 7) % 6),
                            swayPhase = (i * 1.8f) % (2f * PI.toFloat())
                        )
                    }
                }

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    snowflakes.forEachIndexed { idx, s ->
                        val yProgress = (timeCycle * s.speed + idx * 0.04f) % 1.0f
                        val y = yProgress * (h + 20f)
                        val sway = sin((timeCycle * 3f + s.swayPhase).toDouble()).toFloat() * 12f
                        val x = (s.xRatio * w + sway).coerceIn(0f, w)

                        drawCircle(
                            color = Color.White.copy(alpha = (0.75f * intensity).coerceIn(0.2f, 0.95f)),
                            radius = s.radiusPx,
                            center = Offset(x, y)
                        )
                    }
                }
            }

            VideoFilter.CINEMATIC_RAIN -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val rainCount = 40
                    for (i in 0 until rainCount) {
                        val xSeed = ((i * 43) % 100) / 100f * w
                        val yProgress = (timeCycle * 2.5f + i * 0.03f) % 1.0f
                        val yStart = yProgress * (h + 80f) - 40f
                        val length = 28f + (i % 15)

                        drawLine(
                            color = Color(0x66B0C4DE),
                            start = Offset(xSeed, yStart),
                            end = Offset(xSeed - 6f, yStart + length),
                            strokeWidth = 1.2f
                        )
                    }
                }
            }

            VideoFilter.GOLDEN_LIGHT_LEAKS -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val pulse = (shimmerCycle * 0.4f * intensity)
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(
                                Color(0xFFFFB300).copy(alpha = pulse),
                                Color(0xFFFF6F00).copy(alpha = pulse * 0.5f),
                                Color.Transparent
                            ),
                            center = Offset(0f, 0f),
                            radius = size.width * 0.85f
                        )
                    )
                }
            }

            // ----------------------------------------------------
            // 4. CYBER & RETRO (Existing Classic)
            // ----------------------------------------------------
            VideoFilter.CYBER_NEON -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0x3300E5FF), Color(0x44FF007F))
                            )
                        )
                )
            }

            VideoFilter.HOLO_SCANLINES -> {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val step = 8f
                    var y = 0f
                    while (y < size.height) {
                        drawLine(
                            color = Color(0x4400E5FF),
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 1.5f
                        )
                        y += step
                    }
                }
            }

            VideoFilter.QUANTUM_GLITCH -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x33FF00AA))
                )
            }

            VideoFilter.MATRIX_HUD -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x3000FF66))
                )
            }

            VideoFilter.SYNTHWAVE_GLOW -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0x33FFB300), Color(0x448E24AA))
                            )
                        )
                )
            }

            VideoFilter.THERMAL_VISION -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0x350022FF), Color(0x3500FF44), Color(0x35FF1100))
                            )
                        )
                )
            }

            VideoFilter.VINTAGE_2020 -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0x288D6E63))
                )
            }

            VideoFilter.NONE -> {}
        }
    }
}

/**
 * Draws an organic romantic rose petal shape
 */
private fun DrawScope.drawRosePetal(
    center: Offset,
    size: Float,
    isDeepRed: Boolean,
    alpha: Float
) {
    val path = Path().apply {
        moveTo(center.x, center.y - size)
        cubicTo(
            center.x + size * 0.8f, center.y - size * 0.6f,
            center.x + size * 0.7f, center.y + size * 0.6f,
            center.x, center.y + size
        )
        cubicTo(
            center.x - size * 0.7f, center.y + size * 0.6f,
            center.x - size * 0.8f, center.y - size * 0.6f,
            center.x, center.y - size
        )
        close()
    }

    val baseColor = if (isDeepRed) Color(0xFFD81B60) else Color(0xFFFF4081)
    val highlightColor = if (isDeepRed) Color(0xFFAD1457) else Color(0xFFFF80AB)

    drawPath(
        path = path,
        brush = Brush.radialGradient(
            listOf(highlightColor.copy(alpha = alpha), baseColor.copy(alpha = alpha)),
            center = center,
            radius = size
        ),
        style = Fill
    )
}

/**
 * Draws a 4-point sparkling star for wedding bokeh & fairy lights
 */
private fun DrawScope.drawSparkleStar(
    center: Offset,
    radius: Float,
    color: Color
) {
    val path = Path().apply {
        moveTo(center.x, center.y - radius)
        quadraticTo(center.x, center.y, center.x + radius, center.y)
        quadraticTo(center.x, center.y, center.x, center.y + radius)
        quadraticTo(center.x, center.y, center.x - radius, center.y)
        quadraticTo(center.x, center.y, center.x, center.y - radius)
        close()
    }
    drawPath(path = path, color = color)
}

/**
 * Draws a romantic heart shape
 */
private fun DrawScope.drawHeart(
    center: Offset,
    size: Float,
    color: Color
) {
    val path = Path().apply {
        val s = size * 0.8f
        moveTo(center.x, center.y + s)
        cubicTo(center.x - s * 1.5f, center.y - s * 0.3f, center.x - s * 1.2f, center.y - s * 1.2f, center.x, center.y - s * 0.5f)
        cubicTo(center.x + s * 1.2f, center.y - s * 1.2f, center.x + s * 1.5f, center.y - s * 0.3f, center.x, center.y + s)
        close()
    }
    drawPath(path = path, color = color)
}
