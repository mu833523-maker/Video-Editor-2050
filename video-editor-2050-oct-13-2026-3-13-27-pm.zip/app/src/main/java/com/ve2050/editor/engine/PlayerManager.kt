package com.ve2050.editor.engine

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import com.ve2050.editor.model.Clip

/**
 * CapCut-grade Media3 Playback Engine:
 * - Single source of truth for all playback streams (Main Video, Audio, PiP Overlay).
 * - Multi-clip timeline mapping with exact clipping configurations.
 * - Instant frame-accurate scrubbing with dynamic SeekParameters.
 * - 60fps synchronized position polling during active playback.
 */
@OptIn(UnstableApi::class)
class PlayerManager(
    private val context: Context,
    private val onPositionUpdate: (Long) -> Unit,
    private val onPlaybackStateChange: (Boolean) -> Unit
) {

    val exoPlayer: ExoPlayer = ExoPlayer.Builder(context).build().apply {
        repeatMode = Player.REPEAT_MODE_OFF
        setSeekParameters(SeekParameters.EXACT)
    }

    var musicPlayer: ExoPlayer? = null
        private set

    var overlayPlayer: ExoPlayer? = null
        private set

    private var currentClips: List<Clip> = emptyList()
    private var isPlayingInternal: Boolean = false
    private var lastReportedPositionMs: Long = 0L

    private val mainHandler = Handler(Looper.getMainLooper())
    private val progressTicker = object : Runnable {
        override fun run() {
            if (isPlayingInternal) {
                val currentTimelineMs = calculateCurrentTimelinePositionMs()
                if (currentTimelineMs != lastReportedPositionMs) {
                    lastReportedPositionMs = currentTimelineMs
                    onPositionUpdate(currentTimelineMs)
                }
                mainHandler.postDelayed(this, 16L) // ~60 FPS smooth ticker
            }
        }
    }

    init {
        PlaybackCoordinator.registerPlayer(exoPlayer)

        exoPlayer.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                isPlayingInternal = isPlaying
                onPlaybackStateChange(isPlaying)
                if (isPlaying) {
                    musicPlayer?.play()
                    startTicker()
                } else {
                    musicPlayer?.pause()
                    overlayPlayer?.pause()
                    stopTicker()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    isPlayingInternal = false
                    onPlaybackStateChange(false)
                    stopTicker()
                    val totalMs = getTotalDurationMs()
                    lastReportedPositionMs = totalMs
                    onPositionUpdate(totalMs)
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val curIdx = exoPlayer.currentMediaItemIndex
                if (curIdx in currentClips.indices) {
                    val clip = currentClips[curIdx]
                    exoPlayer.setPlaybackSpeed(clip.speed)
                }
            }
        })
    }

    private fun startTicker() {
        mainHandler.removeCallbacks(progressTicker)
        mainHandler.post(progressTicker)
    }

    private fun stopTicker() {
        mainHandler.removeCallbacks(progressTicker)
    }

    fun getTotalDurationMs(): Long {
        return currentClips.sumOf { if (it.durationMs > 0) it.durationMs else 4000L }
    }

    /**
     * Rebuilds media items with frame-accurate clipping configurations.
     */
    fun setClips(clips: List<Clip>, targetSeekPositionMs: Long? = null) {
        currentClips = clips
        val validClips = clips.filter { it.uri != Uri.EMPTY }

        if (validClips.isEmpty()) {
            exoPlayer.clearMediaItems()
            lastReportedPositionMs = 0L
            onPositionUpdate(0L)
            return
        }

        val mediaItems = validClips.map { clip ->
            val builder = MediaItem.Builder().setUri(clip.previewUri)
            if (clip.endMs > clip.startMs) {
                builder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(clip.startMs)
                        .setEndPositionMs(clip.endMs)
                        .build()
                )
            }
            builder.build()
        }

        val currentIdx = exoPlayer.currentMediaItemIndex
        val currentPos = exoPlayer.currentPosition
        exoPlayer.setMediaItems(mediaItems)
        exoPlayer.prepare()

        val seekTarget = targetSeekPositionMs ?: lastReportedPositionMs
        seekTo(seekTarget, isScrubbing = false)
    }

    /**
     * Single Source of Truth Seek:
     * Maps timeline timeMs to exact clip index and offset, seeking both video and audio.
     */
    fun seekTo(timeMs: Long, isScrubbing: Boolean) {
        val totalMs = getTotalDurationMs()
        val clampedTimeMs = timeMs.coerceIn(0L, maxOf(totalMs, 0L))
        lastReportedPositionMs = clampedTimeMs

        // Dynamic seek parameters: CLOSEST_SYNC during active scrub for zero-lag 60fps,
        // and EXACT on release / tap for frame accuracy.
        exoPlayer.setSeekParameters(if (isScrubbing) SeekParameters.CLOSEST_SYNC else SeekParameters.EXACT)

        if (currentClips.isNotEmpty() && exoPlayer.mediaItemCount > 0) {
            var accumulated = 0L
            var targetIndex = -1
            var offsetInClip = 0L

            for (i in currentClips.indices) {
                val clipDur = if (currentClips[i].durationMs > 0) currentClips[i].durationMs else 4000L
                if (clampedTimeMs <= accumulated + clipDur || i == currentClips.lastIndex) {
                    targetIndex = i
                    offsetInClip = (clampedTimeMs - accumulated).coerceIn(0L, clipDur)
                    break
                }
                accumulated += clipDur
            }

            if (targetIndex in 0 until exoPlayer.mediaItemCount) {
                exoPlayer.seekTo(targetIndex, offsetInClip)
                if (targetIndex in currentClips.indices) {
                    exoPlayer.setPlaybackSpeed(currentClips[targetIndex].speed)
                }
            }
        }

        // Sync Music
        musicPlayer?.let { mPlayer ->
            try {
                if (mPlayer.playbackState != Player.STATE_IDLE) {
                    mPlayer.seekTo(clampedTimeMs)
                }
            } catch (_: Exception) {}
        }

        onPositionUpdate(clampedTimeMs)
    }

    fun play() {
        if (currentClips.isEmpty()) return
        val totalMs = getTotalDurationMs()
        if (lastReportedPositionMs >= totalMs && totalMs > 0) {
            seekTo(0L, isScrubbing = false)
        }
        exoPlayer.play()
    }

    fun pause() {
        exoPlayer.pause()
        musicPlayer?.pause()
        overlayPlayer?.pause()
    }

    fun togglePlay() {
        if (isPlayingInternal) pause() else play()
    }

    fun stepFrame(deltaMs: Long) {
        val target = (lastReportedPositionMs + deltaMs).coerceIn(0L, getTotalDurationMs())
        seekTo(target, isScrubbing = false)
    }

    fun setAudioTrack(uri: Uri?, volume: Float = 1.0f, pitch: Float = 1.0f, speed: Float = 1.0f) {
        musicPlayer?.let {
            PlaybackCoordinator.unregisterPlayer(it)
            it.release()
        }
        musicPlayer = null

        if (uri != null && uri != Uri.EMPTY) {
            val player = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                playbackParameters = PlaybackParameters(speed, pitch)
                this.volume = volume.coerceIn(0f, 1f)
                repeatMode = Player.REPEAT_MODE_OFF
                prepare()
                seekTo(lastReportedPositionMs)
                if (isPlayingInternal) {
                    play()
                }
            }
            PlaybackCoordinator.registerPlayer(player)
            musicPlayer = player
        }
    }

    fun setOverlayTrack(uri: Uri?, startMs: Long, durationMs: Long) {
        overlayPlayer?.let {
            PlaybackCoordinator.unregisterPlayer(it)
            it.release()
        }
        overlayPlayer = null

        if (uri != null && uri != Uri.EMPTY) {
            val player = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                repeatMode = Player.REPEAT_MODE_OFF
                prepare()
            }
            PlaybackCoordinator.registerPlayer(player)
            overlayPlayer = player
        }
    }

    fun calculateCurrentTimelinePositionMs(): Long {
        if (currentClips.isEmpty() || exoPlayer.mediaItemCount == 0) return 0L
        val curIndex = exoPlayer.currentMediaItemIndex
        val posInItem = exoPlayer.currentPosition.coerceAtLeast(0L)

        var accumulated = 0L
        for (i in 0 until minOf(curIndex, currentClips.size)) {
            accumulated += if (currentClips[i].durationMs > 0) currentClips[i].durationMs else 4000L
        }
        val totalMs = getTotalDurationMs()
        return (accumulated + posInItem).coerceIn(0L, maxOf(totalMs, 0L))
    }

    fun release() {
        stopTicker()
        PlaybackCoordinator.unregisterPlayer(exoPlayer)
        exoPlayer.release()

        musicPlayer?.let {
            PlaybackCoordinator.unregisterPlayer(it)
            it.release()
        }
        musicPlayer = null

        overlayPlayer?.let {
            PlaybackCoordinator.unregisterPlayer(it)
            it.release()
        }
        overlayPlayer = null
    }
}
