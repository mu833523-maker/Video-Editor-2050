package com.ve2050.editor.engine

import android.util.Log
import androidx.media3.exoplayer.ExoPlayer
import com.ve2050.editor.audio.AudioEngine
import java.util.Collections
import java.util.WeakHashMap

/**
 * Global Playback Coordinator to guarantee ZERO background audio or video leakage:
 * - Automatically pauses all media players when navigating back to HomeScreen.
 * - Automatically pauses everything when MainActivity enters onPause/onStop.
 * - Stops TTS speech synthesis and voice clone previews instantly.
 */
object PlaybackCoordinator {

    private const val TAG = "PlaybackCoordinator"

    private val registeredPlayers = Collections.newSetFromMap(WeakHashMap<ExoPlayer, Boolean>())
    private var registeredAudioEngine: AudioEngine? = null

    fun registerPlayer(player: ExoPlayer) {
        synchronized(registeredPlayers) {
            registeredPlayers.add(player)
        }
    }

    fun unregisterPlayer(player: ExoPlayer) {
        synchronized(registeredPlayers) {
            registeredPlayers.remove(player)
        }
    }

    fun registerAudioEngine(audioEngine: AudioEngine) {
        registeredAudioEngine = audioEngine
    }

    fun unregisterAudioEngine(audioEngine: AudioEngine) {
        if (registeredAudioEngine == audioEngine) {
            registeredAudioEngine = null
        }
    }

    /**
     * Instantly pauses all active ExoPlayer instances and silences TTS speech.
     * Guaranteed safe to call from any thread or lifecycle event.
     */
    fun pauseAll() {
        try {
            synchronized(registeredPlayers) {
                val iterator = registeredPlayers.iterator()
                while (iterator.hasNext()) {
                    val p = iterator.next()
                    try {
                        if (p.isPlaying) {
                            p.pause()
                        }
                    } catch (e: Exception) {
                        Log.w(TAG, "Error pausing player", e)
                    }
                }
            }
            registeredAudioEngine?.stopSpeaking()
        } catch (e: Exception) {
            Log.e(TAG, "Error in pauseAll", e)
        }
    }

    /**
     * Forcefully stops and releases all active players and engines upon app exit.
     */
    fun stopAndReleaseAll() {
        try {
            synchronized(registeredPlayers) {
                val iterator = registeredPlayers.iterator()
                while (iterator.hasNext()) {
                    val p = iterator.next()
                    try {
                        p.stop()
                        p.release()
                    } catch (e: Exception) {
                        Log.w(TAG, "Error releasing player", e)
                    }
                }
                registeredPlayers.clear()
            }
            registeredAudioEngine?.stopSpeaking()
            registeredAudioEngine?.release()
            registeredAudioEngine = null
        } catch (e: Exception) {
            Log.e(TAG, "Error in stopAndReleaseAll", e)
        }
    }
}
