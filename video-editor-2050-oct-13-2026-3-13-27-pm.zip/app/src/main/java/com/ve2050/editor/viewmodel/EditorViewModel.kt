package com.ve2050.editor.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ve2050.editor.engine.PlayerManager
import com.ve2050.editor.engine.ProxyVideoManager
import com.ve2050.editor.engine.ThumbnailExtractor
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.TextOverlay
import com.ve2050.editor.model.TimelineState
import com.ve2050.editor.model.TrackType
import com.ve2050.editor.model.VideoFilter
import com.ve2050.editor.model.VoiceEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class EditorSnapshot(
    val clips: List<Clip>,
    val selectedIndex: Int,
    val textOverlays: List<TextOverlay>,
    val overlayUri: Uri?,
    val overlayStartMs: Long,
    val overlayDurationMs: Long,
    val musicUri: Uri?,
    val musicName: String
)

class EditorViewModel(application: Application) : AndroidViewModel(application) {

    private val _timelineState = MutableStateFlow(TimelineState())
    val timelineState: StateFlow<TimelineState> = _timelineState.asStateFlow()

    private val _clips = MutableStateFlow<List<Clip>>(emptyList())
    val clips: StateFlow<List<Clip>> = _clips.asStateFlow()

    private val _textOverlays = MutableStateFlow<List<TextOverlay>>(emptyList())
    val textOverlays: StateFlow<List<TextOverlay>> = _textOverlays.asStateFlow()

    private val _musicUri = MutableStateFlow<Uri?>(null)
    val musicUri: StateFlow<Uri?> = _musicUri.asStateFlow()

    private val _musicName = MutableStateFlow("No audio track")
    val musicName: StateFlow<String> = _musicName.asStateFlow()

    private val _overlayUri = MutableStateFlow<Uri?>(null)
    val overlayUri: StateFlow<Uri?> = _overlayUri.asStateFlow()

    private val _overlayStartMs = MutableStateFlow(0L)
    val overlayStartMs: StateFlow<Long> = _overlayStartMs.asStateFlow()

    private val _overlayDurationMs = MutableStateFlow(5000L)
    val overlayDurationMs: StateFlow<Long> = _overlayDurationMs.asStateFlow()

    private val _aspectRatio = MutableStateFlow("9:16")
    val aspectRatio: StateFlow<String> = _aspectRatio.asStateFlow()

    private val _voiceEffect = MutableStateFlow(VoiceEffect.ORIGINAL)
    val voiceEffect: StateFlow<VoiceEffect> = _voiceEffect.asStateFlow()

    private val _audioVolume = MutableStateFlow(1.0f)
    val audioVolume: StateFlow<Float> = _audioVolume.asStateFlow()

    private val _audioPitch = MutableStateFlow(1.0f)
    val audioPitch: StateFlow<Float> = _audioPitch.asStateFlow()

    private val _audioSpeed = MutableStateFlow(1.0f)
    val audioSpeed: StateFlow<Float> = _audioSpeed.asStateFlow()

    private val undoStack = mutableListOf<EditorSnapshot>()
    private val redoStack = mutableListOf<EditorSnapshot>()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    val playerManager = PlayerManager(
        context = application,
        onPositionUpdate = { positionMs ->
            _timelineState.value = _timelineState.value.copy(playheadMs = positionMs)
        },
        onPlaybackStateChange = { isPlaying ->
            _timelineState.value = _timelineState.value.copy(isPlaying = isPlaying)
        }
    )

    init {
        updateTotalDuration()
    }

    private fun updateTotalDuration() {
        val totalMs = _clips.value.sumOf { if (it.durationMs > 0) it.durationMs else 4000L }
        _timelineState.value = _timelineState.value.copy(totalDurationMs = totalMs)
    }

    private fun saveSnapshotForUndo() {
        undoStack.add(
            EditorSnapshot(
                clips = _clips.value,
                selectedIndex = _timelineState.value.selectedClipIndex,
                textOverlays = _textOverlays.value,
                overlayUri = _overlayUri.value,
                overlayStartMs = _overlayStartMs.value,
                overlayDurationMs = _overlayDurationMs.value,
                musicUri = _musicUri.value,
                musicName = _musicName.value
            )
        )
        if (undoStack.size > 25) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = false
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        val last = undoStack.removeAt(undoStack.lastIndex)
        redoStack.add(
            EditorSnapshot(
                clips = _clips.value,
                selectedIndex = _timelineState.value.selectedClipIndex,
                textOverlays = _textOverlays.value,
                overlayUri = _overlayUri.value,
                overlayStartMs = _overlayStartMs.value,
                overlayDurationMs = _overlayDurationMs.value,
                musicUri = _musicUri.value,
                musicName = _musicName.value
            )
        )
        _clips.value = last.clips
        _textOverlays.value = last.textOverlays
        _overlayUri.value = last.overlayUri
        _overlayStartMs.value = last.overlayStartMs
        _overlayDurationMs.value = last.overlayDurationMs
        _musicUri.value = last.musicUri
        _musicName.value = last.musicName

        updateTotalDuration()
        playerManager.setClips(last.clips, _timelineState.value.playheadMs)
        playerManager.setAudioTrack(last.musicUri, _audioVolume.value, _audioPitch.value, _audioSpeed.value)
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val next = redoStack.removeAt(redoStack.lastIndex)
        undoStack.add(
            EditorSnapshot(
                clips = _clips.value,
                selectedIndex = _timelineState.value.selectedClipIndex,
                textOverlays = _textOverlays.value,
                overlayUri = _overlayUri.value,
                overlayStartMs = _overlayStartMs.value,
                overlayDurationMs = _overlayDurationMs.value,
                musicUri = _musicUri.value,
                musicName = _musicName.value
            )
        )
        _clips.value = next.clips
        _textOverlays.value = next.textOverlays
        _overlayUri.value = next.overlayUri
        _overlayStartMs.value = next.overlayStartMs
        _overlayDurationMs.value = next.overlayDurationMs
        _musicUri.value = next.musicUri
        _musicName.value = next.musicName

        updateTotalDuration()
        playerManager.setClips(next.clips, _timelineState.value.playheadMs)
        playerManager.setAudioTrack(next.musicUri, _audioVolume.value, _audioPitch.value, _audioSpeed.value)
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    /**
     * Single Source of Truth Playhead Seek:
     * Updates TimelineState immediately and synchronizes PlayerManager.
     */
    fun seekTo(timeMs: Long, isScrubbing: Boolean) {
        val totalMs = _timelineState.value.totalDurationMs
        val clampedTimeMs = timeMs.coerceIn(0L, maxOf(totalMs, 0L))

        _timelineState.value = _timelineState.value.copy(
            playheadMs = clampedTimeMs,
            isScrubbing = isScrubbing
        )

        playerManager.seekTo(clampedTimeMs, isScrubbing)
    }

    fun togglePlay() {
        playerManager.togglePlay()
    }

    fun play() {
        playerManager.play()
    }

    fun pause() {
        playerManager.pause()
    }

    fun stepForward(deltaMs: Long = 100L) {
        playerManager.stepFrame(deltaMs)
    }

    fun stepBackward(deltaMs: Long = 100L) {
        playerManager.stepFrame(-deltaMs)
    }

    fun setZoomFactor(factor: Float) {
        _timelineState.value = _timelineState.value.copy(zoomFactor = factor.coerceIn(0.5f, 3.5f))
    }

    /**
     * Select clip by index or ID and immediately move playhead to the tapped position or clip start.
     */
    fun selectClip(index: Int, seekToTimeMs: Long? = null) {
        if (index in _clips.value.indices) {
            val clip = _clips.value[index]
            val clipTimelineStartMs = getClipTimelineStartTime(index)
            val targetSeekMs = seekToTimeMs ?: clipTimelineStartMs

            _timelineState.value = _timelineState.value.copy(
                selectedClipIndex = index,
                selectedClipId = clip.id,
                selectedTrackType = TrackType.VIDEO,
                selectedTextId = null,
                isOverlaySelected = false,
                isAudioSelected = false
            )

            seekTo(targetSeekMs, isScrubbing = false)
        }
    }

    fun selectClipById(clipId: String, seekToTimeMs: Long? = null) {
        val index = _clips.value.indexOfFirst { it.id == clipId }
        if (index != -1) {
            selectClip(index, seekToTimeMs)
        }
    }

    fun selectText(textId: String) {
        val text = _textOverlays.value.find { it.id == textId }
        if (text != null) {
            _timelineState.value = _timelineState.value.copy(
                selectedTextId = textId,
                selectedTrackType = TrackType.TEXT,
                isOverlaySelected = false,
                isAudioSelected = false
            )
            seekTo(text.startMs, isScrubbing = false)
        }
    }

    fun selectAudio(seekToTimeMs: Long? = null) {
        _timelineState.value = _timelineState.value.copy(
            selectedTrackType = TrackType.AUDIO,
            isAudioSelected = true,
            selectedTextId = null,
            isOverlaySelected = false
        )
        if (seekToTimeMs != null) {
            seekTo(seekToTimeMs, isScrubbing = false)
        }
    }

    fun selectOverlay(seekToTimeMs: Long? = null) {
        val targetMs = seekToTimeMs ?: _overlayStartMs.value
        _timelineState.value = _timelineState.value.copy(
            selectedTrackType = TrackType.OVERLAY,
            isOverlaySelected = true,
            selectedTextId = null,
            isAudioSelected = false
        )
        seekTo(targetMs, isScrubbing = false)
    }

    fun getClipTimelineStartTime(index: Int): Long {
        var start = 0L
        for (i in 0 until minOf(index, _clips.value.size)) {
            start += if (_clips.value[i].durationMs > 0) _clips.value[i].durationMs else 4000L
        }
        return start
    }

    fun addClips(uris: List<Uri>, onCompleted: (() -> Unit)? = null) {
        if (uris.isEmpty()) return
        saveSnapshotForUndo()

        viewModelScope.launch {
            val newClips = uris.map { uri ->
                val duration = ThumbnailExtractor.extractDurationMs(getApplication(), uri)
                Clip(
                    uri = uri,
                    startMs = 0L,
                    endMs = duration,
                    durationMs = duration
                )
            }

            val updatedList = _clips.value + newClips
            _clips.value = updatedList
            updateTotalDuration()
            playerManager.setClips(updatedList, _timelineState.value.playheadMs)

            // Background proxy generation for lag-free preview & scrubbing
            newClips.forEach { clip ->
                viewModelScope.launch(Dispatchers.IO) {
                    ProxyVideoManager.generateProxy(getApplication(), clip.uri) { proxyUri ->
                        _clips.value = _clips.value.map {
                            if (it.id == clip.id) it.copy(proxyUri = proxyUri) else it
                        }
                        playerManager.setClips(_clips.value, _timelineState.value.playheadMs)
                    }
                }
            }

            onCompleted?.invoke()
        }
    }

    fun splitClipAtPlayhead(): Boolean {
        val currentPlayhead = _timelineState.value.playheadMs
        val clipsList = _clips.value
        if (clipsList.isEmpty()) return false

        var accumulated = 0L
        var targetIndex = -1
        var offsetInClip = 0L

        for (i in clipsList.indices) {
            val dur = if (clipsList[i].durationMs > 0) clipsList[i].durationMs else 4000L
            if (currentPlayhead in accumulated until (accumulated + dur)) {
                targetIndex = i
                offsetInClip = currentPlayhead - accumulated
                break
            }
            accumulated += dur
        }

        if (targetIndex == -1) {
            targetIndex = _timelineState.value.selectedClipIndex.coerceIn(0, clipsList.lastIndex)
            val clipDur = if (clipsList[targetIndex].durationMs > 0) clipsList[targetIndex].durationMs else 4000L
            offsetInClip = (clipDur / 2).coerceAtLeast(400L)
        }

        val clip = clipsList[targetIndex]
        val clipDur = if (clip.durationMs > 0) clip.durationMs else 4000L

        if (offsetInClip < 250L || offsetInClip > clipDur - 250L) {
            return false // Prevent sub-frame slices
        }

        saveSnapshotForUndo()

        val firstClip = clip.copy(
            id = UUID.randomUUID().toString(),
            endMs = clip.startMs + offsetInClip,
            durationMs = offsetInClip
        )
        val secondClip = clip.copy(
            id = UUID.randomUUID().toString(),
            startMs = clip.startMs + offsetInClip,
            durationMs = clipDur - offsetInClip,
            endMs = clip.startMs + clipDur
        )

        val updated = clipsList.toMutableList().apply {
            set(targetIndex, firstClip)
            add(targetIndex + 1, secondClip)
        }

        _clips.value = updated
        updateTotalDuration()
        playerManager.setClips(updated, currentPlayhead)
        selectClip(targetIndex + 1, currentPlayhead)
        return true
    }

    fun trimClip(index: Int, newStartMs: Long, newEndMs: Long) {
        if (index !in _clips.value.indices) return
        saveSnapshotForUndo()

        val dur = (newEndMs - newStartMs).coerceAtLeast(500L)
        val updatedClip = _clips.value[index].copy(
            startMs = newStartMs,
            endMs = newEndMs,
            durationMs = dur
        )
        val updatedList = _clips.value.toMutableList().apply { set(index, updatedClip) }
        _clips.value = updatedList
        updateTotalDuration()
        playerManager.setClips(updatedList, _timelineState.value.playheadMs)
    }

    fun reorderClips(fromIndex: Int, toIndex: Int) {
        if (fromIndex in _clips.value.indices && toIndex in _clips.value.indices && fromIndex != toIndex) {
            saveSnapshotForUndo()
            val list = _clips.value.toMutableList()
            val item = list.removeAt(fromIndex)
            list.add(toIndex, item)
            _clips.value = list
            playerManager.setClips(list, _timelineState.value.playheadMs)
            selectClip(toIndex, _timelineState.value.playheadMs)
        }
    }

    fun deleteSelectedClip() {
        val index = _timelineState.value.selectedClipIndex
        if (index in _clips.value.indices) {
            saveSnapshotForUndo()
            val list = _clips.value.toMutableList()
            list.removeAt(index)
            _clips.value = list
            updateTotalDuration()
            val newIdx = (index - 1).coerceAtLeast(0)
            playerManager.setClips(list, _timelineState.value.playheadMs)
            if (list.isNotEmpty()) {
                selectClip(newIdx)
            } else {
                _timelineState.value = _timelineState.value.copy(selectedClipIndex = 0, selectedClipId = null)
            }
        }
    }

    fun duplicateSelectedClip() {
        val index = _timelineState.value.selectedClipIndex
        val clip = _clips.value.getOrNull(index) ?: return
        saveSnapshotForUndo()

        val dup = clip.copy(id = UUID.randomUUID().toString())
        val list = _clips.value.toMutableList().apply { add(index + 1, dup) }
        _clips.value = list
        updateTotalDuration()
        playerManager.setClips(list, _timelineState.value.playheadMs)
        selectClip(index + 1)
    }

    fun setClipSpeed(speed: Float) {
        val index = _timelineState.value.selectedClipIndex
        val clip = _clips.value.getOrNull(index) ?: return
        saveSnapshotForUndo()

        val updated = clip.copy(speed = speed)
        val list = _clips.value.toMutableList().apply { set(index, updated) }
        _clips.value = list
        playerManager.setClips(list, _timelineState.value.playheadMs)
    }

    fun setClipVolume(volume: Float) {
        val index = _timelineState.value.selectedClipIndex
        val clip = _clips.value.getOrNull(index) ?: return
        saveSnapshotForUndo()

        val updated = clip.copy(volume = volume)
        val list = _clips.value.toMutableList().apply { set(index, updated) }
        _clips.value = list
    }

    fun setClipFilter(filter: VideoFilter) {
        val index = _timelineState.value.selectedClipIndex
        val clip = _clips.value.getOrNull(index) ?: return
        saveSnapshotForUndo()

        val updated = clip.copy(filter = filter)
        val list = _clips.value.toMutableList().apply { set(index, updated) }
        _clips.value = list
    }

    fun setClipAdjustments(brightness: Float, contrast: Float, saturation: Float, hdEnhance: Boolean) {
        val index = _timelineState.value.selectedClipIndex
        val clip = _clips.value.getOrNull(index) ?: return
        saveSnapshotForUndo()

        val updated = clip.copy(
            brightness = brightness,
            contrast = contrast,
            saturation = saturation,
            hdEnhance = hdEnhance
        )
        val list = _clips.value.toMutableList().apply { set(index, updated) }
        _clips.value = list
    }

    fun setClipTransform(rotationDegrees: Float, isMirrored: Boolean, ratio: String) {
        val index = _timelineState.value.selectedClipIndex
        val clip = _clips.value.getOrNull(index) ?: return
        saveSnapshotForUndo()

        val updated = clip.copy(
            rotationDegrees = rotationDegrees,
            isMirrored = isMirrored
        )
        val list = _clips.value.toMutableList().apply { set(index, updated) }
        _clips.value = list
        _aspectRatio.value = ratio
    }

    fun setAudioTrack(uri: Uri?, name: String) {
        saveSnapshotForUndo()
        _musicUri.value = uri
        _musicName.value = name
        playerManager.setAudioTrack(uri, _audioVolume.value, _audioPitch.value, _audioSpeed.value)
    }

    fun setOverlayTrack(uri: Uri?, startMs: Long, durationMs: Long) {
        saveSnapshotForUndo()
        _overlayUri.value = uri
        _overlayStartMs.value = startMs
        _overlayDurationMs.value = durationMs
        playerManager.setOverlayTrack(uri, startMs, durationMs)
    }

    fun addTextOverlay(textOverlay: TextOverlay) {
        saveSnapshotForUndo()
        _textOverlays.value = _textOverlays.value + textOverlay
        selectText(textOverlay.id)
    }

    fun updateTextOverlay(updated: TextOverlay) {
        saveSnapshotForUndo()
        _textOverlays.value = _textOverlays.value.map { if (it.id == updated.id) updated else it }
    }

    fun deleteTextOverlay(id: String) {
        saveSnapshotForUndo()
        _textOverlays.value = _textOverlays.value.filter { it.id != id }
        if (_timelineState.value.selectedTextId == id) {
            _timelineState.value = _timelineState.value.copy(selectedTextId = null)
        }
    }

    fun trimTextOverlay(id: String, startMs: Long, endMs: Long) {
        saveSnapshotForUndo()
        _textOverlays.value = _textOverlays.value.map {
            if (it.id == id) it.copy(startMs = startMs, endMs = endMs) else it
        }
    }

    fun moveTextOverlay(id: String, newStartMs: Long) {
        saveSnapshotForUndo()
        _textOverlays.value = _textOverlays.value.map {
            if (it.id == id) {
                val dur = it.endMs - it.startMs
                it.copy(startMs = newStartMs, endMs = newStartMs + dur)
            } else it
        }
    }

    override fun onCleared() {
        super.onCleared()
        playerManager.release()
    }
}
