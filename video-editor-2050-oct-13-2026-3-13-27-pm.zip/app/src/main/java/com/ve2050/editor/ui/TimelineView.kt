package com.ve2050.editor.ui

import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ve2050.editor.engine.ThumbnailExtractor
import com.ve2050.editor.model.*
import com.ve2050.editor.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun TimelineView(
    clips: List<Clip>,
    selectedIndex: Int,
    currentPositionMs: Long = 0L,
    totalDurationMs: Long = 0L,
    isPlaying: Boolean = false,
    // Overlay PiP
    overlayUri: Uri? = null,
    overlayScale: Float = 1f,
    overlayStartMs: Long = 0L,
    overlayDurationMs: Long = 5000L,
    isOverlaySelected: Boolean = false,
    // Multi-track Text Overlays
    textOverlays: List<TextOverlay> = emptyList(),
    selectedTextOverlayId: String? = null,
    // Audio / Voiceover
    musicUri: Uri? = null,
    musicName: String? = null,
    musicStartMs: Long = 0L,
    audioClips: List<TimelineAudioClip> = emptyList(),
    selectedAudioId: String? = null,
    // Stickers
    stickerClips: List<TimelineStickerClip> = emptyList(),
    selectedStickerId: String? = null,
    // Effects & Filters
    effectClips: List<TimelineEffectClip> = emptyList(),
    selectedEffectId: String? = null,
    // Callbacks
    onSeek: (Long) -> Unit = {},
    onSelect: (Int) -> Unit = {},
    onReorder: (Int, Int) -> Unit = { _, _ -> },
    onTrimClip: (Int, Long, Long) -> Unit = { _, _, _ -> },
    onTrimOverlay: ((Long, Long) -> Unit)? = null,
    onMoveOverlay: ((Long) -> Unit)? = null,
    onSelectOverlay: (() -> Unit)? = null,
    onSelectTextOverlay: ((String) -> Unit)? = null,
    onTrimTextOverlay: ((String, Long, Long) -> Unit)? = null,
    onMoveTextOverlay: ((String, Long, Int) -> Unit)? = null,
    onDeleteOverlay: (() -> Unit)? = null,
    onDeleteMusic: (() -> Unit)? = null,
    onSelectMusic: (() -> Unit)? = null,
    onSelectMusicWithTime: ((Long) -> Unit)? = null,
    onSelectAudioClip: ((String) -> Unit)? = null,
    onMoveAudioClip: ((String, Long, Int) -> Unit)? = null,
    onTrimAudioClip: ((String, Long, Long) -> Unit)? = null,
    onSelectStickerClip: ((String) -> Unit)? = null,
    onMoveStickerClip: ((String, Long, Int) -> Unit)? = null,
    onTrimStickerClip: ((String, Long, Long) -> Unit)? = null,
    onSelectEffectClip: ((String) -> Unit)? = null,
    onMoveEffectClip: ((String, Long, Int) -> Unit)? = null,
    onTrimEffectClip: ((String, Long, Long) -> Unit)? = null,
    onDeleteTextOverlay: ((String) -> Unit)? = null,
    onAddClip: (() -> Unit)? = null,
    onSplitClip: (() -> Unit)? = null,
    onOpenTransition: ((Int) -> Unit)? = null,
    onSelectWithTime: ((Int, Long) -> Unit)? = null,
    beatMarkers: List<BeatMarker> = emptyList(),
    isBeatSyncEnabled: Boolean = false,
    onToggleBeatSync: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current

    // Zoom state (dp per second scaling)
    var zoomFactor by remember { mutableFloatStateOf(1f) }
    val baseDpPerSecond = 50f
    val dpPerSecond = (baseDpPerSecond * zoomFactor).coerceIn(25f, 200f)

    // Reorder state
    var draggedClipIndex by remember { mutableStateOf<Int?>(null) }
    var dragAccumulatedX by remember { mutableFloatStateOf(0f) }

    // Scroll state for synchronized multi-track scrolling
    val scrollState = rememberScrollState()

    // Total duration calculation
    val effectiveTotalMs = remember(clips, totalDurationMs, effectClips, textOverlays, audioClips, stickerClips) {
        val calculated = clips.sumOf { if (it.durationMs > 0) it.durationMs else 4000L }
        val maxEffect = effectClips.maxOfOrNull { it.endMs } ?: 0L
        val maxText = textOverlays.maxOfOrNull { it.endMs } ?: 0L
        val maxAudio = audioClips.maxOfOrNull { it.endMs } ?: 0L
        val maxSticker = stickerClips.maxOfOrNull { it.endMs } ?: 0L
        val highest = maxOf(calculated, totalDurationMs, maxEffect, maxText, maxAudio, maxSticker)
        if (highest > 0) maxOf(highest, 10000L) else 10000L
    }

    // Scrubbing detection & seek callback
    val isScrollDragged by scrollState.interactionSource.collectIsDraggedAsState()
    var isUserScrubbing by remember { mutableStateOf(false) }

    // Throttled seeking (~50ms) for smooth preview without decoder hitching
    var lastSeekTimeMs by remember { mutableLongStateOf(0L) }
    var isSnappedToCut by remember { mutableStateOf(false) }

    // Precalculate snap points
    val snapPoints = remember(clips, overlayStartMs, overlayDurationMs, textOverlays, beatMarkers, isBeatSyncEnabled, effectClips) {
        val points = mutableListOf<Long>(0L)
        var acc = 0L
        clips.forEach { clip ->
            acc += if (clip.durationMs > 0) clip.durationMs else 4000L
            points.add(acc)
        }
        if (overlayUri != null) {
            points.add(overlayStartMs)
            points.add(overlayStartMs + overlayDurationMs)
        }
        textOverlays.forEach { text ->
            points.add(text.startMs)
            points.add(text.endMs)
        }
        effectClips.forEach { fx ->
            points.add(fx.startMs)
            points.add(fx.endMs)
        }
        if (isBeatSyncEnabled) {
            beatMarkers.forEach { points.add(it.timeMs) }
        }
        points.distinct().sorted()
    }

    fun applyMagneticSnapping(rawTimeMs: Long): Long {
        val snapThresholdMs = 120L
        val nearest = snapPoints.minByOrNull { kotlin.math.abs(it - rawTimeMs) }
        return if (nearest != null && kotlin.math.abs(nearest - rawTimeMs) <= snapThresholdMs) {
            isSnappedToCut = true
            nearest
        } else {
            isSnappedToCut = false
            rawTimeMs
        }
    }

    // When scrolling timeline, calculate time under fixed center playhead and throttle seeks to ~50ms
    LaunchedEffect(scrollState.value, isScrollDragged, isUserScrubbing) {
        if (isScrollDragged || isUserScrubbing || (!isPlaying && scrollState.isScrollInProgress)) {
            val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
            if (pxPerSec > 0) {
                val rawScrolledTimeMs = ((scrollState.value / pxPerSec) * 1000f).toLong().coerceIn(0L, effectiveTotalMs)
                val targetTimeMs = applyMagneticSnapping(rawScrolledTimeMs)

                val now = System.currentTimeMillis()
                if (now - lastSeekTimeMs >= 50L || !scrollState.isScrollInProgress) {
                    lastSeekTimeMs = now
                    onSeek(targetTimeMs)
                }
            }
        } else if (!isPlaying && !isScrollDragged && !isUserScrubbing && scrollState.value > 0) {
            val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
            if (pxPerSec > 0) {
                val rawScrolledTimeMs = ((scrollState.value / pxPerSec) * 1000f).toLong().coerceIn(0L, effectiveTotalMs)
                val targetTimeMs = applyMagneticSnapping(rawScrolledTimeMs)
                onSeek(targetTimeMs)
            }
        }
    }

    // Auto-scroll timeline to center the playhead whenever position updates (playback or tap seek)
    LaunchedEffect(currentPositionMs, dpPerSecond, isScrollDragged, isUserScrubbing) {
        if (!isScrollDragged && !isUserScrubbing && !scrollState.isScrollInProgress) {
            val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
            if (pxPerSec > 0) {
                val targetScrollPx = ((currentPositionMs / 1000f) * pxPerSec).roundToInt()
                if (kotlin.math.abs(scrollState.value - targetScrollPx) > 2) {
                    scrollState.scrollTo(targetScrollPx)
                }
            }
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp, vertical = 2.dp),
        color = Color(0xFF0E0E14),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E28))
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(bottom = 2.dp)) {
            // CapCut Multi-Track Control Header (Timecode, Beat Sync, Zoom buttons)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Timecode readout
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Movie,
                        contentDescription = null,
                        tint = if (isSnappedToCut) Color(0xFF00FF88) else Color(0xFF00E5FF),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    val mins = currentPositionMs / 60000
                    val secs = (currentPositionMs % 60000) / 1000
                    val millis = (currentPositionMs % 1000) / 10
                    Text(
                        String.format("%02d:%02d.%02d", mins, secs, millis),
                        color = if (isSnappedToCut) Color(0xFF00FF88) else Color.White,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "/ ${effectiveTotalMs / 1000}s",
                        color = Color(0xFF6E6E80),
                        fontSize = 10.sp
                    )
                }

                // Middle actions: Split & Beat Sync
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (onSplitClip != null) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF1A1A28),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f)),
                            modifier = Modifier.clickable { onSplitClip() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.ContentCut, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(11.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("Split", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (onToggleBeatSync != null) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isBeatSyncEnabled) Color(0xFF00FF88).copy(alpha = 0.2f) else Color(0xFF181824),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isBeatSyncEnabled) Color(0xFF00FF88) else Color(0xFF2A2A3A)),
                            modifier = Modifier.clickable { onToggleBeatSync() }
                        ) {
                            Text(
                                text = if (isBeatSyncEnabled) "🎵 Beats" else "🎵 Sync",
                                color = if (isBeatSyncEnabled) Color(0xFF00FF88) else Color(0xFFA0A0BA),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Right: Zoom controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .clickable { zoomFactor = (zoomFactor - 0.25f).coerceAtLeast(0.5f) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "Zoom out", tint = Color(0xFFA0A0BA), modifier = Modifier.size(15.dp))
                    }
                    Text(
                        text = "${String.format("%.1f", zoomFactor)}x",
                        color = Color(0xFF00E5FF),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .clickable { zoomFactor = (zoomFactor + 0.25f).coerceAtMost(3.5f) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "Zoom in", tint = Color(0xFFA0A0BA), modifier = Modifier.size(15.dp))
                    }
                }
            }

            // Timeline Viewport with Fixed Center Playhead
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, zoom, _ ->
                            zoomFactor = (zoomFactor * zoom).coerceIn(0.5f, 3.5f)
                        }
                    }
            ) {
                val viewportWidth = maxWidth
                val halfViewportWidth = viewportWidth / 2

                val verticalTrackScrollState = rememberScrollState()

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(scrollState)
                        .verticalScroll(verticalTrackScrollState)
                        .pointerInput(effectiveTotalMs, dpPerSecond) {
                            detectTapGestures(
                                onPress = {
                                    isUserScrubbing = true
                                    tryAwaitRelease()
                                    isUserScrubbing = false
                                },
                                onTap = { offset ->
                                    val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                    val halfViewportPx = with(density) { halfViewportWidth.toPx() }
                                    if (pxPerSec > 0) {
                                        val timelineX = offset.x - halfViewportPx
                                        val tappedTimeMs = ((timelineX / pxPerSec) * 1000f).toLong().coerceIn(0L, effectiveTotalMs)
                                        val snappedMs = applyMagneticSnapping(tappedTimeMs)
                                        onSeek(snappedMs)
                                    }
                                }
                            )
                        }
                ) {
                    Column(
                        modifier = Modifier
                            .padding(start = halfViewportWidth, end = halfViewportWidth)
                            .wrapContentWidth(align = Alignment.Start)
                    ) {
                        // 1. Time Ruler (Seconds & Sub-second ticks)
                        TimeRuler(
                            totalDurationMs = effectiveTotalMs,
                            dpPerSecond = dpPerSecond,
                            onSeek = onSeek
                        )

                        Spacer(Modifier.height(4.dp))

                        // 2. Main Video Filmstrip Track
                        Row(
                            modifier = Modifier
                                .height(64.dp)
                                .wrapContentWidth(align = Alignment.Start),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (clips.isEmpty()) {
                                Surface(
                                    modifier = Modifier
                                        .width(220.dp)
                                        .fillMaxHeight()
                                        .clickable { onAddClip?.invoke() },
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFF141422),
                                    border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(0xFF00E5FF).copy(alpha = 0.7f))
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Box(
                                            modifier = Modifier.size(28.dp).clip(CircleShape).background(Color(0xFF00E5FF)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Add, contentDescription = "Add Clip", tint = Color.Black, modifier = Modifier.size(18.dp))
                                        }
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            Text("+ Add Clip", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            Text("Tap to add first video", color = Color(0xFF8888AA), fontSize = 9.sp)
                                        }
                                    }
                                }
                            } else {
                                clips.forEachIndexed { index, clip ->
                                    val isSelected = index == selectedIndex
                                    val clipDurationMs = if (clip.durationMs > 0) clip.durationMs else 4000L
                                    val clipWidthDp = ((clipDurationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(64.dp)
                                    val isDraggingThis = draggedClipIndex == index

                                    Box(
                                        modifier = Modifier
                                            .width(clipWidthDp)
                                            .fillMaxHeight()
                                            .graphicsLayer {
                                                if (isDraggingThis) {
                                                    translationX = dragAccumulatedX
                                                    scaleX = 1.05f
                                                    scaleY = 1.05f
                                                    shadowElevation = 8.dp.toPx()
                                                }
                                            }
                                            .padding(horizontal = 1.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF14141C))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) Color.White else Color(0xFF22222E),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .pointerInput(index, clips.size) {
                                                detectDragGesturesAfterLongPress(
                                                    onDragStart = {
                                                        draggedClipIndex = index
                                                        dragAccumulatedX = 0f
                                                        onSelect(index)
                                                    },
                                                    onDrag = { change, dragAmount ->
                                                        change.consume()
                                                        dragAccumulatedX += dragAmount.x
                                                        val slotThresholdPx = with(density) { 50.dp.toPx() }
                                                        if (dragAccumulatedX > slotThresholdPx && index < clips.lastIndex) {
                                                            onReorder(index, index + 1)
                                                            draggedClipIndex = index + 1
                                                            dragAccumulatedX = 0f
                                                        } else if (dragAccumulatedX < -slotThresholdPx && index > 0) {
                                                            onReorder(index, index - 1)
                                                            draggedClipIndex = index - 1
                                                            dragAccumulatedX = 0f
                                                        }
                                                    },
                                                    onDragEnd = {
                                                        draggedClipIndex = null
                                                        dragAccumulatedX = 0f
                                                    },
                                                    onDragCancel = {
                                                        draggedClipIndex = null
                                                        dragAccumulatedX = 0f
                                                    }
                                                )
                                            }
                                            .pointerInput(index, dpPerSecond) {
                                                detectTapGestures(
                                                    onTap = { offset ->
                                                        val clipStartMs = clips.take(index).sumOf { if (it.durationMs > 0) it.durationMs else 4000L }
                                                        val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                        val tappedOffsetMs = if (pxPerSec > 0) ((offset.x / pxPerSec) * 1000f).toLong() else 0L
                                                        val tappedTimeMs = (clipStartMs + tappedOffsetMs).coerceIn(clipStartMs, clipStartMs + clipDurationMs)
                                                        onSelect(index)
                                                        onSelectWithTime?.invoke(index, tappedTimeMs)
                                                        onSeek(tappedTimeMs)
                                                    }
                                                )
                                            }
                                    ) {
                                        // Filmstrip thumbnail frames
                                        FilmstripRow(
                                            uri = clip.previewUri,
                                            clipDurationMs = clipDurationMs,
                                            widthDp = clipWidthDp
                                        )

                                        // Sprocket gradient overlay
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(
                                                    Brush.verticalGradient(
                                                        listOf(Color.Black.copy(alpha = 0.4f), Color.Transparent, Color.Black.copy(alpha = 0.65f))
                                                    )
                                                )
                                        )

                                        // Clip Title Pill
                                        Row(
                                            modifier = Modifier
                                                .align(Alignment.BottomStart)
                                                .fillMaxWidth()
                                                .padding(horizontal = 6.dp, vertical = 3.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${index + 1}. ${clip.title.take(8)}",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1
                                            )
                                            Text(
                                                text = "${String.format("%.1f", clipDurationMs / 1000f)}s",
                                                color = if (isSelected) Color.White else Color(0xFF00E5FF),
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        // CapCut White Trim Handles on selected clip
                                        if (isSelected && !isDraggingThis) {
                                            // Left White Handle
                                            var leftTrimAccumPx by remember(index, isSelected) { mutableFloatStateOf(0f) }
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.CenterStart)
                                                    .width(16.dp)
                                                    .fillMaxHeight()
                                                    .background(Color.White, RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp))
                                                    .pointerInput(index, clip.startMs, clipDurationMs) {
                                                        detectDragGestures(
                                                            onDragStart = { leftTrimAccumPx = 0f },
                                                            onDrag = { change, dragAmount ->
                                                                change.consume()
                                                                leftTrimAccumPx += dragAmount.x
                                                                val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                                if (pxPerSec > 0) {
                                                                    val deltaMs = ((leftTrimAccumPx / pxPerSec) * 1000f).toLong()
                                                                    val newStart = (clip.startMs + deltaMs).coerceAtLeast(0L)
                                                                    val newEnd = clip.endMs
                                                                    if (newEnd - newStart >= 500L) {
                                                                        onTrimClip(index, newStart, newEnd)
                                                                        leftTrimAccumPx = 0f
                                                                    }
                                                                }
                                                            }
                                                        )
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    Box(Modifier.size(width = 2.dp, height = 8.dp).background(Color.Black))
                                                    Box(Modifier.size(width = 2.dp, height = 8.dp).background(Color.Black))
                                                }
                                            }

                                            // Right White Handle
                                            var rightTrimAccumPx by remember(index, isSelected) { mutableFloatStateOf(0f) }
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.CenterEnd)
                                                    .width(16.dp)
                                                    .fillMaxHeight()
                                                    .background(Color.White, RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp))
                                                    .pointerInput(index, clip.startMs, clip.endMs) {
                                                        detectDragGestures(
                                                            onDragStart = { rightTrimAccumPx = 0f },
                                                            onDrag = { change, dragAmount ->
                                                                change.consume()
                                                                rightTrimAccumPx += dragAmount.x
                                                                val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                                if (pxPerSec > 0) {
                                                                    val deltaMs = ((rightTrimAccumPx / pxPerSec) * 1000f).toLong()
                                                                    val newStart = clip.startMs
                                                                    val newEnd = (clip.endMs + deltaMs).coerceAtLeast(newStart + 500L)
                                                                    onTrimClip(index, newStart, newEnd)
                                                                    rightTrimAccumPx = 0f
                                                                }
                                                            }
                                                        )
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                    Box(Modifier.size(width = 2.dp, height = 8.dp).background(Color.Black))
                                                    Box(Modifier.size(width = 2.dp, height = 8.dp).background(Color.Black))
                                                }
                                            }
                                        }
                                    }

                                    // CapCut Transition Button between clips
                                    if (index < clips.lastIndex) {
                                        val hasTransition = clip.transitionIn != TransitionType.NONE
                                        Box(
                                            modifier = Modifier
                                                .size(22.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(if (hasTransition) Color(0xFF00E5FF) else Color(0xFF222234))
                                                .border(1.dp, if (hasTransition) Color(0xFF00E5FF) else Color(0xFF555570), RoundedCornerShape(6.dp))
                                                .clickable { onOpenTransition?.invoke(index) },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = if (hasTransition) "⧓" else "❘",
                                                color = if (hasTransition) Color.Black else Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }

                                // CapCut '+' Button to add more video clips at end
                                Spacer(Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .width(48.dp)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF141422))
                                        .border(1.dp, Color(0xFF2E2E44), RoundedCornerShape(8.dp))
                                        .clickable { onAddClip?.invoke() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.Add, contentDescription = "Add video", tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.height(2.dp))
                                        Text("+ Add", color = Color(0xFFA0A0BA), fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        // 3. Overlay (PiP) Track(s) - Purple / Magenta Clips
                        if (overlayUri != null) {
                            Spacer(Modifier.height(4.dp))
                            val overlayStartOffsetDp = ((overlayStartMs / 1000f) * dpPerSecond).dp
                            val overlayWidthDp = ((overlayDurationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(70.dp)

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(34.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .offset(x = overlayStartOffsetDp)
                                        .width(overlayWidthDp)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF241032))
                                        .border(
                                            width = if (isOverlaySelected) 2.dp else 1.dp,
                                            color = if (isOverlaySelected) Color.White else Color(0xFFE040FB),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .pointerInput(overlayStartMs, effectiveTotalMs) {
                                            detectDragGestures { change, dragAmount ->
                                                change.consume()
                                                val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                if (pxPerSec > 0) {
                                                    val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                    val maxStart = (effectiveTotalMs - 400L).coerceAtLeast(0L)
                                                    val newStart = (overlayStartMs + deltaMs).coerceIn(0L, maxStart)
                                                    onMoveOverlay?.invoke(newStart)
                                                }
                                            }
                                        }
                                        .pointerInput(overlayStartMs, overlayDurationMs, dpPerSecond) {
                                            detectTapGestures(
                                                onTap = { offset ->
                                                    onSelectOverlay?.invoke()
                                                    val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                    if (pxPerSec > 0) {
                                                        val tappedOffsetMs = ((offset.x / pxPerSec) * 1000f).toLong()
                                                        val tappedTimeMs = (overlayStartMs + tappedOffsetMs).coerceIn(overlayStartMs, overlayStartMs + overlayDurationMs)
                                                        onSeek(tappedTimeMs)
                                                    } else {
                                                        onSeek(overlayStartMs)
                                                    }
                                                }
                                            )
                                        }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)
                                    ) {
                                        Icon(Icons.Default.Layers, contentDescription = null, tint = Color(0xFFE040FB), modifier = Modifier.size(13.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("PiP Overlay", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        Spacer(Modifier.weight(1f))
                                        Text("${String.format("%.1f", overlayDurationMs / 1000f)}s", color = Color(0xFFCE93D8), fontSize = 8.sp)
                                    }

                                    if (isOverlaySelected) {
                                        TrackClipTrimHandles(
                                            startMs = overlayStartMs,
                                            endMs = overlayStartMs + overlayDurationMs,
                                            dpPerSecond = dpPerSecond,
                                            density = density,
                                            onTrim = { newStart, newEnd ->
                                                onTrimOverlay?.invoke(newStart, (newEnd - newStart).coerceAtLeast(500L))
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // 4. Effects Track(s) - Orange Clips
                        val effectLayers = remember(effectClips) {
                            effectClips.groupBy { it.layer }.entries.sortedBy { it.key }
                        }
                        effectLayers.forEach { (_, layerItems) ->
                            Spacer(Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(30.dp)
                            ) {
                                layerItems.forEach { fx ->
                                    val isSelected = fx.id == selectedEffectId
                                    val fxStartOffsetDp = ((fx.startMs / 1000f) * dpPerSecond).dp
                                    val fxWidthDp = ((fx.durationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(60.dp)

                                    Box(
                                        modifier = Modifier
                                            .offset(x = fxStartOffsetDp)
                                            .width(fxWidthDp)
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF331600))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) Color.White else Color(0xFFFF7700),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .pointerInput(fx.id, fx.startMs, fx.layer) {
                                                detectDragGesturesAfterLongPress { change, dragAmount ->
                                                    change.consume()
                                                    val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                    if (pxPerSec > 0) {
                                                        val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                        val newStart = (fx.startMs + deltaMs).coerceIn(0L, (effectiveTotalMs - 400L).coerceAtLeast(0L))
                                                        val newLayer = if (dragAmount.y > 20f) fx.layer + 1 else if (dragAmount.y < -20f) (fx.layer - 1).coerceAtLeast(0) else fx.layer
                                                        onMoveEffectClip?.invoke(fx.id, newStart, newLayer)
                                                    }
                                                }
                                            }
                                            .pointerInput(fx.id, fx.startMs, fx.durationMs, dpPerSecond) {
                                                detectTapGestures(
                                                    onTap = { offset ->
                                                        onSelectEffectClip?.invoke(fx.id)
                                                        val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                        if (pxPerSec > 0) {
                                                            val tappedOffsetMs = ((offset.x / pxPerSec) * 1000f).toLong()
                                                            val tappedTimeMs = (fx.startMs + tappedOffsetMs).coerceIn(fx.startMs, fx.endMs)
                                                            onSeek(tappedTimeMs)
                                                        } else {
                                                            onSeek(fx.startMs)
                                                        }
                                                    }
                                                )
                                            }
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)
                                        ) {
                                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFF7700), modifier = Modifier.size(12.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(fx.title, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        }

                                        if (isSelected) {
                                            TrackClipTrimHandles(
                                                startMs = fx.startMs,
                                                endMs = fx.endMs,
                                                dpPerSecond = dpPerSecond,
                                                density = density,
                                                onTrim = { newStart, newEnd ->
                                                    onTrimEffectClip?.invoke(fx.id, newStart, newEnd)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // 5. Text Overlays Track(s) - Yellow Clips
                        val textLayers = remember(textOverlays) {
                            textOverlays.groupBy { it.layer }.entries.sortedBy { it.key }
                        }
                        textLayers.forEach { (_, layerItems) ->
                            Spacer(Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(32.dp)
                            ) {
                                layerItems.forEach { textOverlay ->
                                    val isSelected = textOverlay.id == selectedTextOverlayId
                                    val startMs = textOverlay.startMs.coerceAtLeast(0L)
                                    val durMs = if (textOverlay.endMs > startMs) (textOverlay.endMs - startMs).coerceAtLeast(400L) else 4000L
                                    val textStartOffsetDp = ((startMs / 1000f) * dpPerSecond).dp
                                    val textWidthDp = ((durMs / 1000f) * dpPerSecond).dp.coerceAtLeast(64.dp)

                                    Box(
                                        modifier = Modifier
                                            .offset(x = textStartOffsetDp)
                                            .width(textWidthDp)
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF2C2400))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) Color.White else Color(0xFFFFD600),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .pointerInput(textOverlay.id, textOverlay.startMs, textOverlay.layer) {
                                                detectDragGesturesAfterLongPress { change, dragAmount ->
                                                    change.consume()
                                                    val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                    if (pxPerSec > 0) {
                                                        val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                        val newStart = (textOverlay.startMs + deltaMs).coerceIn(0L, (effectiveTotalMs - 400L).coerceAtLeast(0L))
                                                        val newLayer = if (dragAmount.y > 20f) textOverlay.layer + 1 else if (dragAmount.y < -20f) (textOverlay.layer - 1).coerceAtLeast(0) else textOverlay.layer
                                                        onMoveTextOverlay?.invoke(textOverlay.id, newStart, newLayer)
                                                    }
                                                }
                                            }
                                            .pointerInput(textOverlay.id, startMs, durMs, dpPerSecond) {
                                                detectTapGestures(
                                                    onTap = { offset ->
                                                        onSelectTextOverlay?.invoke(textOverlay.id)
                                                        val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                        if (pxPerSec > 0) {
                                                            val tappedOffsetMs = ((offset.x / pxPerSec) * 1000f).toLong()
                                                            val tappedTimeMs = (startMs + tappedOffsetMs).coerceIn(startMs, startMs + durMs)
                                                            onSeek(tappedTimeMs)
                                                        } else {
                                                            onSeek(startMs)
                                                        }
                                                    }
                                                )
                                            }
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)
                                        ) {
                                            Icon(Icons.Default.TextFields, contentDescription = null, tint = Color(0xFFFFD600), modifier = Modifier.size(12.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text(textOverlay.text, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        }

                                        if (isSelected) {
                                            TrackClipTrimHandles(
                                                startMs = startMs,
                                                endMs = textOverlay.endMs,
                                                dpPerSecond = dpPerSecond,
                                                density = density,
                                                onTrim = { newStart, newEnd ->
                                                    onTrimTextOverlay?.invoke(textOverlay.id, newStart, newEnd)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // 6. Stickers Track(s) - Purple Clips
                        val stickerLayers = remember(stickerClips) {
                            stickerClips.groupBy { it.layer }.entries.sortedBy { it.key }
                        }
                        stickerLayers.forEach { (_, layerItems) ->
                            Spacer(Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(30.dp)
                            ) {
                                layerItems.forEach { sticker ->
                                    val isSelected = sticker.id == selectedStickerId
                                    val stStartOffsetDp = ((sticker.startMs / 1000f) * dpPerSecond).dp
                                    val stWidthDp = ((sticker.durationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(60.dp)

                                    Box(
                                        modifier = Modifier
                                            .offset(x = stStartOffsetDp)
                                            .width(stWidthDp)
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF240A38))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) Color.White else Color(0xFFB026FF),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .pointerInput(sticker.id, sticker.startMs, sticker.layer) {
                                                detectDragGesturesAfterLongPress { change, dragAmount ->
                                                    change.consume()
                                                    val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                    if (pxPerSec > 0) {
                                                        val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                        val newStart = (sticker.startMs + deltaMs).coerceIn(0L, (effectiveTotalMs - 400L).coerceAtLeast(0L))
                                                        val newLayer = if (dragAmount.y > 20f) sticker.layer + 1 else if (dragAmount.y < -20f) (sticker.layer - 1).coerceAtLeast(0) else sticker.layer
                                                        onMoveStickerClip?.invoke(sticker.id, newStart, newLayer)
                                                    }
                                                }
                                            }
                                            .pointerInput(sticker.id, sticker.startMs, sticker.durationMs, dpPerSecond) {
                                                detectTapGestures(
                                                    onTap = { offset ->
                                                        onSelectStickerClip?.invoke(sticker.id)
                                                        val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                        if (pxPerSec > 0) {
                                                            val tappedOffsetMs = ((offset.x / pxPerSec) * 1000f).toLong()
                                                            val tappedTimeMs = (sticker.startMs + tappedOffsetMs).coerceIn(sticker.startMs, sticker.endMs)
                                                            onSeek(tappedTimeMs)
                                                        } else {
                                                            onSeek(sticker.startMs)
                                                        }
                                                    }
                                                )
                                            }
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)
                                        ) {
                                            Text(sticker.textOrEmoji.take(2), fontSize = 11.sp)
                                            Spacer(Modifier.width(4.dp))
                                            Text(sticker.title, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        }

                                        if (isSelected) {
                                            TrackClipTrimHandles(
                                                startMs = sticker.startMs,
                                                endMs = sticker.endMs,
                                                dpPerSecond = dpPerSecond,
                                                density = density,
                                                onTrim = { newStart, newEnd ->
                                                    onTrimStickerClip?.invoke(sticker.id, newStart, newEnd)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // 7. Audio / Voice Tracks - Green Waveform Clips
                        val allAudioItems = remember(audioClips, musicUri, musicName, musicStartMs) {
                            if (audioClips.isNotEmpty()) {
                                audioClips
                            } else if (musicUri != null) {
                                listOf(TimelineAudioClip(id = "music_single", uri = musicUri, title = musicName ?: "Audio Track", startMs = musicStartMs, durationMs = effectiveTotalMs - musicStartMs))
                            } else {
                                emptyList()
                            }
                        }

                        val audioLayers = remember(allAudioItems) {
                            allAudioItems.groupBy { it.layer }.entries.sortedBy { it.key }
                        }
                        audioLayers.forEach { (_, layerItems) ->
                            Spacer(Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(34.dp)
                            ) {
                                layerItems.forEach { audioItem ->
                                    val isSelected = audioItem.id == selectedAudioId
                                    val audioStartOffsetDp = ((audioItem.startMs.coerceAtLeast(0L) / 1000f) * dpPerSecond).dp
                                    val audioWidthDp = ((audioItem.durationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(80.dp)

                                    Box(
                                        modifier = Modifier
                                            .offset(x = audioStartOffsetDp)
                                            .width(audioWidthDp)
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF092014))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) Color.White else Color(0xFF00FF88),
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .pointerInput(audioItem.id, audioItem.startMs, audioItem.layer) {
                                                detectDragGesturesAfterLongPress { change, dragAmount ->
                                                    change.consume()
                                                    val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                    if (pxPerSec > 0) {
                                                        val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                        val newStart = (audioItem.startMs + deltaMs).coerceIn(0L, (effectiveTotalMs - 400L).coerceAtLeast(0L))
                                                        val newLayer = if (dragAmount.y > 20f) audioItem.layer + 1 else if (dragAmount.y < -20f) (audioItem.layer - 1).coerceAtLeast(0) else audioItem.layer
                                                        onMoveAudioClip?.invoke(audioItem.id, newStart, newLayer)
                                                    }
                                                }
                                            }
                                            .pointerInput(audioItem.id, audioItem.startMs, audioItem.durationMs, dpPerSecond) {
                                                detectTapGestures(
                                                    onTap = { offset ->
                                                        onSelectAudioClip?.invoke(audioItem.id)
                                                        onSelectMusic?.invoke()
                                                        val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                        if (pxPerSec > 0) {
                                                            val tappedOffsetMs = ((offset.x / pxPerSec) * 1000f).toLong()
                                                            val tappedMs = (audioItem.startMs + tappedOffsetMs).coerceIn(0L, effectiveTotalMs)
                                                            onSelectMusicWithTime?.invoke(tappedMs)
                                                            onSeek(tappedMs)
                                                        } else {
                                                            onSeek(audioItem.startMs)
                                                        }
                                                    }
                                                )
                                            }
                                    ) {
                                        // Precalculated cached waveform canvas
                                        val waveformBars = remember(audioItem.uri.toString()) {
                                            ThumbnailExtractor.getWaveformData(audioItem.uri.toString(), 60)
                                        }

                                        Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 3.dp)) {
                                            val barWidth = 2.5f
                                            val gap = 1.5f
                                            val totalBars = (size.width / (barWidth + gap)).toInt().coerceAtLeast(1)
                                            val centerY = size.height / 2f
                                            for (i in 0 until totalBars) {
                                                val wave = waveformBars[i % waveformBars.size]
                                                val barHeight = wave * (size.height * 0.88f)
                                                val x = i * (barWidth + gap)
                                                drawRect(
                                                    color = Color(0xFF00FF88).copy(alpha = 0.55f),
                                                    topLeft = Offset(x, centerY - barHeight / 2f),
                                                    size = Size(barWidth, barHeight)
                                                )
                                            }
                                        }

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp)
                                        ) {
                                            Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color(0xFF00FF88), modifier = Modifier.size(13.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text(
                                                text = audioItem.title,
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        if (isSelected) {
                                            TrackClipTrimHandles(
                                                startMs = audioItem.startMs,
                                                endMs = audioItem.endMs,
                                                dpPerSecond = dpPerSecond,
                                                density = density,
                                                onTrim = { newStart, newEnd ->
                                                    onTrimAudioClip?.invoke(audioItem.id, newStart, newEnd)
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Fixed CapCut Center Playhead Line (glows cyan/green when snapped)
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(if (isSnappedToCut) 2.dp else 1.5.dp)
                        .align(Alignment.Center)
                        .background(if (isSnappedToCut) Color(0xFF00FF88) else Color.White)
                )

                // Sleek Top Cursor for Playhead
                PlayheadCursor(
                    modifier = Modifier.align(Alignment.TopCenter),
                    color = if (isSnappedToCut) Color(0xFF00FF88) else Color.White
                )
            }
        }
    }
}

// CapCut Filmstrip repeating frames inside each clip
@Composable
private fun FilmstripRow(
    uri: Uri,
    clipDurationMs: Long,
    widthDp: androidx.compose.ui.unit.Dp
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val frameWidth = 44.dp
    val frameCount = (widthDp / frameWidth).toInt().coerceAtLeast(1)

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.Start
    ) {
        repeat(frameCount) { index ->
            val timeUs = remember(index, frameCount, clipDurationMs) {
                ((index.toFloat() / frameCount.coerceAtLeast(1)) * clipDurationMs * 1000L).toLong()
            }
            var bitmap by remember(uri, timeUs) {
                mutableStateOf(ThumbnailExtractor.getMemoryCached(uri, timeUs))
            }

            LaunchedEffect(uri, timeUs) {
                if (bitmap == null && uri != Uri.EMPTY) {
                    bitmap = ThumbnailExtractor.getThumbnail(context, uri, timeUs)
                }
            }

            Box(
                modifier = Modifier
                    .width(frameWidth)
                    .fillMaxHeight()
                    .background(Color(0xFF141424))
                    .border(width = 0.5.dp, color = Color(0x33000000)),
                contentAlignment = Alignment.Center
            ) {
                val b = bitmap
                if (b != null) {
                    Image(
                        bitmap = b.asImageBitmap(),
                        contentDescription = "Clip frame",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        Icons.Default.Movie,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF).copy(alpha = 0.35f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

// CapCut Top Ruler with seconds and ticks
@Composable
private fun TimeRuler(
    totalDurationMs: Long,
    dpPerSecond: Float,
    onSeek: ((Long) -> Unit)? = null
) {
    val density = LocalDensity.current
    val totalSeconds = (totalDurationMs / 1000f).toInt().coerceAtLeast(1)
    val totalWidthDp = (totalSeconds * dpPerSecond).dp

    Box(
        modifier = Modifier
            .width(totalWidthDp)
            .height(20.dp)
            .pointerInput(totalDurationMs, dpPerSecond) {
                detectTapGestures { offset ->
                    val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                    if (pxPerSec > 0) {
                        val tappedMs = ((offset.x / pxPerSec) * 1000f).toLong().coerceIn(0L, totalDurationMs)
                        onSeek?.invoke(tappedMs)
                    }
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val pxPerSec = dpPerSecond.dp.toPx()
            for (sec in 0..totalSeconds) {
                val x = sec * pxPerSec
                // Major tick line
                drawLine(
                    color = Color(0xFF6E6E78),
                    start = Offset(x, 10f),
                    end = Offset(x, size.height),
                    strokeWidth = 1.5f
                )
                // Half second minor tick
                if (pxPerSec > 35f && sec < totalSeconds) {
                    val halfX = x + pxPerSec / 2f
                    drawLine(
                        color = Color(0xFF3E3E48),
                        start = Offset(halfX, 16f),
                        end = Offset(halfX, size.height),
                        strokeWidth = 1f
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Start
        ) {
            val step = if (dpPerSecond < 35f) 2 else 1
            for (sec in 0..totalSeconds step step) {
                Box(
                    modifier = Modifier
                        .width((step * dpPerSecond).dp)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.TopStart
                ) {
                    val mins = sec / 60
                    val s = sec % 60
                    Text(
                        text = String.format("%02d:%02d", mins, s),
                        color = Color(0xFF8E8E98),
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.offset(x = 2.dp, y = (-2).dp)
                    )
                }
            }
        }
    }
}

// CapCut Inverted Triangle Playhead Cursor
@Composable
private fun PlayheadCursor(modifier: Modifier = Modifier, color: Color = Color.White) {
    Canvas(modifier = modifier.size(width = 12.dp, height = 8.dp)) {
        val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width / 2f, size.height)
            close()
        }
        drawPath(path = path, color = color)
    }
}

// CapCut White Trim Handles for selected track clips
@Composable
private fun TrackClipTrimHandles(
    startMs: Long,
    endMs: Long,
    minDurationMs: Long = 500L,
    maxDurationMs: Long = 3600000L,
    dpPerSecond: Float,
    density: androidx.compose.ui.unit.Density,
    onTrim: (Long, Long) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left Handle
        Box(
            modifier = Modifier
                .width(13.dp)
                .fillMaxHeight()
                .background(Color.White, RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp))
                .pointerInput(startMs, endMs, dpPerSecond) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                        if (pxPerSec > 0) {
                            val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                            val newStart = (startMs + deltaMs).coerceIn(0L, endMs - minDurationMs)
                            onTrim(newStart, endMs)
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(width = 1.5.dp, height = 10.dp).background(Color.Black))
        }

        // Right Handle
        Box(
            modifier = Modifier
                .width(13.dp)
                .fillMaxHeight()
                .background(Color.White, RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp))
                .pointerInput(startMs, endMs, dpPerSecond) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                        if (pxPerSec > 0) {
                            val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                            val newEnd = (endMs + deltaMs).coerceIn(startMs + minDurationMs, maxDurationMs)
                            onTrim(startMs, newEnd)
                        }
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(width = 1.5.dp, height = 10.dp).background(Color.Black))
        }
    }
}

