package com.ve2050.editor.engine

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.TextureOverlay
import com.google.common.collect.ImmutableList
import androidx.media3.transformer.*
import androidx.media3.common.audio.SonicAudioProcessor
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.TextFontFamily
import com.ve2050.editor.model.TextOverlay
import com.ve2050.editor.model.TextPreset
import com.ve2050.editor.model.VoiceEffect
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream

enum class ExportQuality(val label: String, val resolutionText: String, val height: Int, val description: String) {
    LOW("Low 480p", "854 × 480", 480, "Fast render • Lightweight file"),
    MEDIUM("Medium 720p", "1280 × 720", 720, "Standard HD • Recommended"),
    HIGH("High 1080p", "1920 × 1080", 1080, "Full HD • Crisp clarity")
}

@UnstableApi
object ExportEngine {

    fun export(
        context: Context,
        clips: List<Clip>,
        quality: ExportQuality = ExportQuality.MEDIUM,
        fps: Int = 30,
        textOverlays: List<TextOverlay> = emptyList(),
        musicUri: Uri? = null,
        overlayUri: Uri? = null,
        overlayScale: Float = 0.5f,
        overlayRotation: Float = 0f,
        overlayStartMs: Long = 0L,
        overlayDurationMs: Long = 0L,
        audioPitch: Float = 1.0f,
        audioSpeed: Float = 1.0f,
        voiceEffect: VoiceEffect = VoiceEffect.ORIGINAL,
        onProgress: (Float) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        if (clips.isEmpty()) {
            onDone(false, "No clips to export")
            return
        }

        val outputFile = File(context.cacheDir, "ve2050_${System.currentTimeMillis()}.mp4")

        val audioProcessors = mutableListOf<androidx.media3.common.audio.AudioProcessor>()
        if (audioPitch != 1.0f || audioSpeed != 1.0f) {
            try {
                val sonic = SonicAudioProcessor().apply {
                    setPitch(audioPitch.coerceIn(0.5f, 2.0f))
                    setSpeed(audioSpeed.coerceIn(0.5f, 2.0f))
                }
                audioProcessors.add(sonic)
            } catch (_: Exception) {}
        }

        val videoEffects = mutableListOf<Effect>()

        // 1. Resolution / Quality Presentation Effect
        try {
            videoEffects.add(Presentation.createForHeight(quality.height))
        } catch (_: Exception) {}

        // 2. FPS Frame Drop Effect (30 or 60 FPS)
        try {
            if (fps == 30 || fps == 60) {
                videoEffects.add(FrameDropEffect.createDefaultFrameDropEffect(fps.toFloat()))
            }
        } catch (_: Exception) {}

        // 3. Text Overlays Effect
        if (textOverlays.isNotEmpty()) {
            try {
                val textBitmap = renderTextOverlaysToBitmap(context, 1080, 1920, textOverlays)
                val overlay: TextureOverlay = BitmapOverlay.createStaticBitmapOverlay(textBitmap)
                videoEffects.add(OverlayEffect(ImmutableList.of(overlay)))
            } catch (e: Exception) {
                // Fallback gracefully if overlay effect creation encounters issues
            }
        }

        val editedItems = clips.map { clip ->
            val builder = MediaItem.Builder().setUri(clip.uri)
            if (clip.endMs > clip.startMs) {
                builder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(clip.startMs)
                        .setEndPositionMs(clip.endMs)
                        .build()
                )
            }
            val item = EditedMediaItem.Builder(builder.build())
            if (videoEffects.isNotEmpty() || audioProcessors.isNotEmpty()) {
                item.setEffects(Effects(audioProcessors, videoEffects))
            }
            item.build()
        }

        val videoSequence = EditedMediaItemSequence(editedItems)
        val sequences = mutableListOf(videoSequence)

        if (overlayUri != null && overlayUri != Uri.EMPTY) {
            val overlayBuilder = MediaItem.Builder().setUri(overlayUri)
            if (overlayDurationMs > 0L) {
                overlayBuilder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(overlayStartMs.coerceAtLeast(0L))
                        .setEndPositionMs((overlayStartMs + overlayDurationMs).coerceAtLeast(500L))
                        .build()
                )
            }
            val overlayMediaItem = overlayBuilder.build()
            val scaleEffect = ScaleAndRotateTransformation.Builder()
                .setScale(overlayScale.coerceIn(0.2f, 2.5f), overlayScale.coerceIn(0.2f, 2.5f))
                .setRotationDegrees(overlayRotation)
                .build()
            val overlayEditedItem = EditedMediaItem.Builder(overlayMediaItem)
                .setEffects(Effects(emptyList(), listOf(scaleEffect)))
                .build()
            sequences.add(EditedMediaItemSequence(listOf(overlayEditedItem)))
        }

        if (musicUri != null && musicUri != Uri.EMPTY) {
            val audioMediaItem = MediaItem.Builder().setUri(musicUri).build()
            val audioEditedItem = EditedMediaItem.Builder(audioMediaItem)
                .setEffects(Effects(audioProcessors, emptyList()))
                .build()
            sequences.add(EditedMediaItemSequence(listOf(audioEditedItem)))
        }

        val composition = Composition.Builder(sequences).build()

        var progressJob: Job? = null

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, r: ExportResult) {
                    progressJob?.cancel()
                    CoroutineScope(Dispatchers.Main).launch {
                        onProgress(1f)
                        val uri = withContext(Dispatchers.IO) { saveToGallery(context, outputFile) }
                        outputFile.delete()
                        if (uri != null) {
                            NotificationEngine.showExportSuccess(context, uri)
                            onDone(true, "Video exported and saved to Gallery / Movies folder!")
                        } else {
                            NotificationEngine.showExportError(context, "Could not save to Gallery.")
                            onDone(false, "Export completed but could not be saved to Gallery. Please check storage permission or space.")
                        }
                    }
                }
                override fun onError(c: Composition, r: ExportResult, e: ExportException) {
                    progressJob?.cancel()
                    outputFile.delete()
                    val errorDetail = e.message ?: e.cause?.message ?: "Video rendering failed"
                    NotificationEngine.showExportError(context, errorDetail)
                    CoroutineScope(Dispatchers.Main).launch {
                        onDone(false, "Export failed: $errorDetail")
                    }
                }
            })
            .build()

        progressJob = CoroutineScope(Dispatchers.Main).launch {
            val progressHolder = ProgressHolder()
            var lastNotifTime = 0L
            while (isActive) {
                delay(200)
                val state = transformer.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    val p = progressHolder.progress
                    onProgress(p / 100f)
                    val now = System.currentTimeMillis()
                    if (now - lastNotifTime > 800) {
                        NotificationEngine.showExportProgress(context, p)
                        lastNotifTime = now
                    }
                }
            }
        }

        try {
            NotificationEngine.showExportProgress(context, 0)
            transformer.start(composition, outputFile.absolutePath)
        } catch (e: Exception) {
            progressJob.cancel()
            outputFile.delete()
            val errorDetail = e.message ?: "Failed to start export encoder"
            NotificationEngine.showExportError(context, errorDetail)
            CoroutineScope(Dispatchers.Main).launch {
                onDone(false, "Export failed: $errorDetail")
            }
        }
    }

    fun export(
        context: Context,
        clips: List<Clip>,
        textOverlays: List<TextOverlay>,
        musicUri: Uri?,
        overlayUri: Uri? = null,
        overlayScale: Float = 0.5f,
        overlayRotation: Float = 0f,
        overlayStartMs: Long = 0L,
        overlayDurationMs: Long = 0L,
        onProgress: (Float) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        export(
            context = context,
            clips = clips,
            quality = ExportQuality.MEDIUM,
            fps = 30,
            textOverlays = textOverlays,
            musicUri = musicUri,
            overlayUri = overlayUri,
            overlayScale = overlayScale,
            overlayRotation = overlayRotation,
            overlayStartMs = overlayStartMs,
            overlayDurationMs = overlayDurationMs,
            onProgress = onProgress,
            onDone = onDone
        )
    }

    fun export(
        context: Context,
        clips: List<Clip>,
        onProgress: (Float) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        export(
            context = context,
            clips = clips,
            textOverlays = emptyList(),
            musicUri = null,
            overlayUri = null,
            overlayScale = 0.5f,
            onProgress = onProgress,
            onDone = onDone
        )
    }

    private fun saveToGallery(context: Context, file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VE2050_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoEditor2050")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val uri = resolver.insert(collection, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(file).use { it.copyTo(out) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.update(uri, ContentValues().apply {
                    put(MediaStore.Video.Media.IS_PENDING, 0)
                }, null, null)
            }
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    private fun renderTextOverlaysToBitmap(
        context: Context,
        width: Int,
        height: Int,
        overlays: List<TextOverlay>
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        for (overlay in overlays) {
            canvas.save()

            // Calculate center position
            val cx = (width / 2f) + (overlay.x * (width / 360f))
            val cy = (height / 2f) + (overlay.y * (height / 640f))

            canvas.translate(cx, cy)
            canvas.rotate(overlay.rotation)
            canvas.scale(overlay.scale, overlay.scale)

            // Setup Typeface using TextDesignHelper
            val typeface = com.ve2050.editor.ui.text.TextDesignHelper.getTypeface(
                context = context,
                fontFamily = overlay.fontFamily,
                isBold = overlay.isBold,
                isItalic = overlay.isItalic
            )

            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.typeface = typeface
                this.textSize = overlay.sizeSp * (width / 360f) * 0.9f
                this.textAlign = Paint.Align.CENTER
                this.color = overlay.color
                this.alpha = (overlay.opacity * 255).toInt().coerceIn(0, 255)
            }

            // Apply preset or custom styling
            when (overlay.preset) {
                TextPreset.URDU_NASTALIQ -> {
                    paint.setShadowLayer(18f, 0f, 4f, 0xCC000000.toInt())
                    paint.color = 0xFFFFFFFF.toInt()
                }
                TextPreset.CYBER_NEON -> {
                    paint.setShadowLayer(25f, 0f, 0f, 0xFFFF007F.toInt())
                    paint.color = 0xFF00E5FF.toInt()
                }
                TextPreset.QUANTUM_GLITCH -> {
                    val glitchPaint = Paint(paint).apply { clearShadowLayer() }
                    glitchPaint.color = 0xFFFF0055.toInt()
                    canvas.drawText(overlay.text, -6f, -3f, glitchPaint)
                    glitchPaint.color = 0xFF00FFFF.toInt()
                    canvas.drawText(overlay.text, 6f, 3f, glitchPaint)
                }
                TextPreset.GOLDEN_METALLIC -> {
                    paint.setShadowLayer(15f, 4f, 4f, 0xFF4A3500.toInt())
                    paint.color = 0xFFFFD700.toInt()
                }
                TextPreset.RETRO_SYNTHWAVE -> {
                    paint.setShadowLayer(20f, 0f, 0f, 0xFF7928CA.toInt())
                    paint.color = 0xFFFF007F.toInt()
                }
                TextPreset.HOLO_OUTLINE -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 4f
                    paint.color = 0xFF00E5FF.toInt()
                    paint.setShadowLayer(15f, 0f, 0f, 0xFF00E5FF.toInt())
                }
                TextPreset.DEEP_SHADOW -> {
                    paint.setShadowLayer(20f, 8f, 8f, 0xFF000000.toInt())
                    paint.color = 0xFFFFFFFF.toInt()
                }
                TextPreset.EMERALD_MATRIX -> {
                    paint.setShadowLayer(18f, 0f, 0f, 0xFF00FF66.toInt())
                    paint.color = 0xFF00FF88.toInt()
                }
                TextPreset.FIRE_BLAZE -> {
                    paint.setShadowLayer(22f, 0f, 0f, 0xFFFF4500.toInt())
                    paint.color = 0xFFFF8C00.toInt()
                }
                TextPreset.CHROME_FROST -> {
                    paint.setShadowLayer(16f, 2f, 2f, 0xFF002233.toInt())
                    paint.color = 0xFFE0F7FA.toInt()
                }
                TextPreset.MINIMAL_CAPTION -> {
                    paint.color = 0xFFFFFFFF.toInt()
                }
                TextPreset.NEWS_BANNER -> {
                    paint.color = 0xFFFFEB3B.toInt()
                    paint.setShadowLayer(8f, 0f, 2f, 0x99000000.toInt())
                }
                TextPreset.NONE -> {
                    if (overlay.hasShadow) {
                        paint.setShadowLayer(overlay.shadowRadius, 2f, 4f, overlay.shadowColor)
                    }
                }
            }

            // Draw Background Pill if enabled or preset
            if (overlay.hasBackground || overlay.preset == TextPreset.MINIMAL_CAPTION || overlay.preset == TextPreset.NEWS_BANNER) {
                val bounds = android.graphics.Rect()
                paint.getTextBounds(overlay.text, 0, overlay.text.length, bounds)
                val bgColor = when (overlay.preset) {
                    TextPreset.NEWS_BANNER -> 0xEECC0000.toInt()
                    TextPreset.MINIMAL_CAPTION -> 0xCC111118.toInt()
                    else -> overlay.backgroundColor
                }
                val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = bgColor
                }
                val padX = 36f
                val padY = 20f
                canvas.drawRoundRect(
                    bounds.left.toFloat() - padX,
                    bounds.top.toFloat() - padY,
                    bounds.right.toFloat() + padX,
                    bounds.bottom.toFloat() + padY,
                    20f, 20f,
                    bgPaint
                )
            }

            // Draw stroke outline if specified
            if (overlay.strokeWidth > 0f) {
                val strokePaint = Paint(paint).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = overlay.strokeWidth * (width / 360f)
                    color = overlay.strokeColor
                    clearShadowLayer()
                }
                canvas.drawText(overlay.text, 0f, 0f, strokePaint)
            }

            canvas.drawText(overlay.text, 0f, 0f, paint)
            canvas.restore()
        }

        return bitmap
    }
}
