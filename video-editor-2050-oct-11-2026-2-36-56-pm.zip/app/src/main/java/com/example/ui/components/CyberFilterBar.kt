package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class VideoFilterPreset(
    val displayName: String,
    val sampleColor: Color,
    val overlayColor: Color? = null,
    val gradientColors: List<Color>? = null,
    val isMonochrome: Boolean = false,
    val category: String = "All"
) {
    // Standard / Basic
    NONE("None", Color(0xFF455A64), category = "Standard"),
    AUTO_FIX("Auto Fix", Color(0xFF81D4FA), overlayColor = Color(0x1F00E5FF), category = "Standard"),
    VIVID("Vivid Pro", Color(0xFFFF5252), overlayColor = Color(0x26FF5252), category = "Standard"),
    HIGH_CONTRAST("High Dynamic", Color(0xFF212121), overlayColor = Color(0x33000000), category = "Standard"),

    // Cyberpunk 2050
    CYBER_CYAN("Cyber Cyan", Color(0xFF00E5FF), overlayColor = Color(0x4000E5FF), category = "Cyberpunk"),
    NEON_PINK("Neon Pink", Color(0xFFFF007F), overlayColor = Color(0x40FF007F), category = "Cyberpunk"),
    MATRIX_GREEN("Matrix Green", Color(0xFF00FF66), overlayColor = Color(0x4000FF66), category = "Cyberpunk"),
    VAPORWAVE("Vaporwave", Color(0xFFE040FB), gradientColors = listOf(Color(0x4DFF007F), Color(0x4D00E5FF)), category = "Cyberpunk"),
    NEO_TOKYO("Neo Tokyo", Color(0xFFFF3366), gradientColors = listOf(Color(0x44FF0055), Color(0x4400BFFF)), category = "Cyberpunk"),
    CYBER_GLOW("Cyber Glow", Color(0xFF18FFFF), overlayColor = Color(0x3518FFFF), category = "Cyberpunk"),
    LASER_VIOLET("Laser Violet", Color(0xFF8A2BE2), overlayColor = Color(0x448A2BE2), category = "Cyberpunk"),
    NEON_BLUE("Neon Blue", Color(0xFF00B0FF), overlayColor = Color(0x4400B0FF), category = "Cyberpunk"),
    CHROME_GOLD("Chrome Gold", Color(0xFFFFD700), overlayColor = Color(0x38FFD700), category = "Cyberpunk"),
    HOLOGRAM_TINT("Hologram", Color(0xFF00FFEA), gradientColors = listOf(Color(0x3500FFEA), Color(0x357B2CBF)), category = "Cyberpunk"),
    DARK_SYNTH("Dark Synth", Color(0xFF4A148C), overlayColor = Color(0x55311B92), category = "Cyberpunk"),
    CYBER_AMBER("Cyber Amber", Color(0xFFFF9100), overlayColor = Color(0x3DFF9100), category = "Cyberpunk"),
    NEON_LIME("Neon Lime", Color(0xFF76FF03), overlayColor = Color(0x3876FF03), category = "Cyberpunk"),
    QUANTUM_CORE("Quantum Core", Color(0xFF00E676), gradientColors = listOf(Color(0x4000E676), Color(0x4000B0FF)), category = "Cyberpunk"),

    // Cinematic
    CINEMATIC("Cinematic", Color(0xFF00B0FF), gradientColors = listOf(Color(0x3800E5FF), Color(0x38FF9800)), category = "Cinematic"),
    GOLDEN_HOUR("Golden Hour", Color(0xFFFF9800), overlayColor = Color(0x38FF9800), category = "Cinematic"),
    BLADE_RUNNER("Blade Runner", Color(0xFFFF5722), gradientColors = listOf(Color(0x44FF5722), Color(0x44009688)), category = "Cinematic"),
    HOLLYWOOD_WARM("Hollywood Warm", Color(0xFFFFB74D), overlayColor = Color(0x30FFB74D), category = "Cinematic"),
    GOTHAM_NOIR("Gotham Noir", Color(0xFF37474F), isMonochrome = true, overlayColor = Color(0x55102027), category = "Cinematic"),
    DYSTOPIA("Dystopia", Color(0xFF78909C), overlayColor = Color(0x38455A64), category = "Cinematic"),
    TECHNICOLOR("Technicolor", Color(0xFFFF1744), gradientColors = listOf(Color(0x28FF1744), Color(0x2800E676)), category = "Cinematic"),
    BLOCKBUSTER("Blockbuster", Color(0xFF00ACC1), gradientColors = listOf(Color(0x3800ACC1), Color(0x38FF6D00)), category = "Cinematic"),
    FILM_GRAIN("Film Stock", Color(0xFFD7CCC8), overlayColor = Color(0x28D7CCC8), category = "Cinematic"),
    INDIE_MOOD("Indie Mood", Color(0xFF8D6E63), overlayColor = Color(0x336D4C41), category = "Cinematic"),

    // Retro & VHS
    RETRO("Retro 80s", Color(0xFFFFB300), overlayColor = Color(0x38FFB300), category = "Retro VHS"),
    VHS_TAPE("VHS 1984", Color(0xFFAB47BC), gradientColors = listOf(Color(0x38AB47BC), Color(0x3826A69A)), category = "Retro VHS"),
    VINTAGE("Vintage 70s", Color(0xFFD7CCC8), overlayColor = Color(0x38BCAAA4), category = "Retro VHS"),
    NOIR("Classic Noir", Color(0xFFCCCCCC), isMonochrome = true, overlayColor = Color(0x66000000), category = "Retro VHS"),
    SEPIA("Sepia Dust", Color(0xFF8D6E63), overlayColor = Color(0x448D6E63), category = "Retro VHS"),
    CAMCORDER("Camcorder Hi8", Color(0xFF80CBC4), overlayColor = Color(0x3080CBC4), category = "Retro VHS"),
    KODACHROME("Kodachrome", Color(0xFFFF7043), overlayColor = Color(0x33FF7043), category = "Retro VHS"),
    POLAROID("Polaroid Dream", Color(0xFFFFF9C4), overlayColor = Color(0x2BFFF9C4), category = "Retro VHS"),
    CASSETTE("Cassette Lo-Fi", Color(0xFFB0BEC5), overlayColor = Color(0x3078909C), category = "Retro VHS"),
    SUPER_8("Super 8mm", Color(0xFFFFCC80), overlayColor = Color(0x38FFE082), category = "Retro VHS"),

    // Glitch & FX
    RGB_SPLIT("RGB Split", Color(0xFFFF0055), gradientColors = listOf(Color(0x40FF0000), Color(0x400000FF)), category = "Glitch FX"),
    HEATMAP("Heatmap Thermal", Color(0xFFFF3D00), gradientColors = listOf(Color(0x4DFF3D00), Color(0x4DFFEA00)), category = "Glitch FX"),
    NIGHT_VISION("Night Vision", Color(0xFF00E676), overlayColor = Color(0x5500E676), category = "Glitch FX"),
    INVERT_FX("Invert X-Ray", Color(0xFF80DEEA), overlayColor = Color(0x60E0F7FA), category = "Glitch FX"),
    UV_BLACKLIGHT("UV Blacklight", Color(0xFFD500F9), overlayColor = Color(0x50AA00FF), category = "Glitch FX"),
    RADIOACTIVE("Radioactive", Color(0xFFAEEA00), overlayColor = Color(0x4464DD17), category = "Glitch FX"),
    CYBER_SCAN("Scanline Grid", Color(0xFF00E5FF), overlayColor = Color(0x2800E5FF), category = "Glitch FX"),
    SOLAR_STORM("Solar Storm", Color(0xFFFF6D00), overlayColor = Color(0x44FF6D00), category = "Glitch FX"),

    // Moods
    COLD_BLUE("Cold Frost", Color(0xFF2979FF), overlayColor = Color(0x400091EA), category = "Moods"),
    CRIMSON_BLOOD("Crimson Neon", Color(0xFFD50000), overlayColor = Color(0x44D50000), category = "Moods"),
    EMERALD_CITY("Deep Emerald", Color(0xFF00BFA5), overlayColor = Color(0x3D00BFA5), category = "Moods"),
    SUNSET_MAGENTA("Sunset Magenta", Color(0xFFFF4081), gradientColors = listOf(Color(0x40FF4081), Color(0x40FF9100)), category = "Moods"),
    LAVENDER_HAZE("Lavender Haze", Color(0xFFB388FF), overlayColor = Color(0x35B388FF), category = "Moods"),
    MIDNIGHT_SHADOW("Midnight Shadow", Color(0xFF1A237E), overlayColor = Color(0x501A237E), category = "Moods"),
    CYBER_DUSK("Cyber Dusk", Color(0xFF651FFF), gradientColors = listOf(Color(0x40651FFF), Color(0x40FF1744)), category = "Moods"),
    PASTEL_CYBER("Pastel Synth", Color(0xFFF8BBD0), gradientColors = listOf(Color(0x35F8BBD0), Color(0x35B2EBF2)), category = "Moods")
}

val filterCategories = listOf("All", "Cyberpunk", "Cinematic", "Retro VHS", "Glitch FX", "Moods", "Standard")

@Composable
fun CyberFilterBar(
    selectedFilter: VideoFilterPreset,
    onFilterSelected: (VideoFilterPreset) -> Unit,
    modifier: Modifier = Modifier
) {
    val barShape = RoundedCornerShape(24.dp)
    val haptic = LocalHapticFeedback.current
    var activeCategory by remember { mutableStateOf("All") }
    var filterIntensity by remember { mutableFloatStateOf(1.0f) }
    var showIntensitySlider by remember { mutableStateOf(false) }

    val filteredPresets = remember(activeCategory) {
        if (activeCategory == "All") {
            VideoFilterPreset.values().toList()
        } else {
            VideoFilterPreset.values().filter { it.category == activeCategory }
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(barShape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x2800E5FF),
                        Color(0x1A09141F),
                        Color(0x33000000)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.5f),
                        Color.White.copy(alpha = 0.15f),
                        NeonCyan.copy(alpha = 0.4f)
                    )
                ),
                shape = barShape
            )
            .padding(vertical = 10.dp, horizontal = 12.dp)
            .testTag("cyber_filter_bar")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 4.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Filters",
                        tint = NeonCyan,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "50+ PRO SHADER FILTERS",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Intensity Toggle
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (showIntensitySlider) Color(0x3300E5FF) else Color(0x1400E5FF))
                            .border(0.8.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .clickable { showIntensitySlider = !showIntensitySlider }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Intensity",
                                tint = NeonCyanBright,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${(filterIntensity * 100).toInt()}%",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 9.5.sp,
                                    color = NeonCyanBright
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Selected Filter Tag
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0x2800E5FF))
                            .border(0.8.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = selectedFilter.displayName.uppercase(),
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.5.sp,
                                color = NeonCyanBright
                            )
                        )
                    }
                }
            }

            // Intensity slider if toggled
            AnimatedVisibility(visible = showIntensitySlider) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "FILTER OPACITY / INTENSITY",
                            style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = TextMuted)
                        )
                        Text(
                            text = "${(filterIntensity * 100).toInt()}%",
                            style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = NeonCyan)
                        )
                    }
                    Slider(
                        value = filterIntensity,
                        onValueChange = { filterIntensity = it },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = NeonCyanBright,
                            activeTrackColor = NeonCyan,
                            inactiveTrackColor = Color(0x3300E5FF)
                        ),
                        modifier = Modifier.height(28.dp)
                    )
                }
            }

            // Category Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                filterCategories.forEach { cat ->
                    val isCatActive = cat == activeCategory
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isCatActive) Color(0x3300E5FF) else Color(0x0F00E5FF))
                            .border(
                                width = if (isCatActive) 1.dp else 0.6.dp,
                                color = if (isCatActive) NeonCyanBright else Color(0x2200E5FF),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                activeCategory = cat
                            }
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = cat,
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = if (isCatActive) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 10.sp,
                                color = if (isCatActive) NeonCyanBright else TextSecondary
                            )
                        )
                    }
                }
            }

            // Presets Horizontal Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                filteredPresets.forEach { preset ->
                    val isSelected = preset == selectedFilter
                    FilterPresetThumbnail(
                        preset = preset,
                        isSelected = isSelected,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onFilterSelected(preset)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterPresetThumbnail(
    preset: VideoFilterPreset,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = NeonCyan),
                onClick = onClick
            )
            .padding(vertical = 2.dp)
            .testTag("filter_preset_${preset.name.lowercase()}")
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .then(
                    if (preset.gradientColors != null) {
                        Modifier.background(
                            Brush.linearGradient(preset.gradientColors)
                        )
                    } else {
                        Modifier.background(preset.sampleColor)
                    }
                )
                .border(
                    width = if (isSelected) 2.2.dp else 1.dp,
                    color = if (isSelected) NeonCyanBright else Color(0x40FFFFFF),
                    shape = CircleShape
                )
                .then(
                    if (isSelected) {
                        Modifier.shadow(
                            elevation = 10.dp,
                            shape = CircleShape,
                            ambientColor = NeonCyan,
                            spotColor = NeonCyan
                        )
                    } else Modifier
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(Color(0xCC000000)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Selected",
                        tint = NeonCyanBright,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(5.dp))

        Text(
            text = preset.displayName,
            style = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 9.5.sp,
                color = if (isSelected) NeonCyanBright else TextSecondary
            ),
            maxLines = 1
        )
    }
}
