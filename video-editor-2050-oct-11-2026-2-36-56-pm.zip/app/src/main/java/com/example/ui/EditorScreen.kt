package com.example.ui

import android.content.ContentResolver
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.ui.components.AnimatedTextOverlayWrapper
import com.example.ui.components.ChromaKeyState
import com.example.ui.components.CosmicCyberBackground
import com.example.ui.components.CyberAddTextDialog
import com.example.ui.components.CyberAiOptionsCard
import com.example.ui.components.CyberAutoCaptionsDialog
import com.example.ui.components.CyberChromaKeyControl
import com.example.ui.components.CyberExportDialog
import com.example.ui.components.CyberFilterBar
import com.example.ui.components.CyberMusicCard
import com.example.ui.components.CyberPipAndSplitControl
import com.example.ui.components.CyberSfxType
import com.example.ui.components.CyberSoundEffectsBar
import com.example.ui.components.CyberSoundSynthesizer
import com.example.ui.components.CyberSpeedControl
import com.example.ui.components.CyberSpeedCurveControl
import com.example.ui.components.CyberStickerPickerDialog
import com.example.ui.components.CyberTextToSpeechDialog
import com.example.ui.components.CyberTransitionPreset
import com.example.ui.components.CyberTransitionsBar
import com.example.ui.components.CyberTrimTimeline
import com.example.ui.components.CyberUnifiedAiDialog
import com.example.ui.components.CyberVoiceChangerControl
import com.example.ui.components.DraggableStickerOverlayView
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.MultiClipTimelineStrip
import com.example.ui.components.PipState
import com.example.ui.components.PlacedStickerItem
import com.example.ui.components.SpeedCurvePreset
import com.example.ui.components.SplitScreenMode
import com.example.ui.components.StickerDefinition
import com.example.ui.components.TextAnimationStyle
import com.example.ui.components.TextOverlayItem
import com.example.ui.components.VideoClipItem
import com.example.ui.components.VideoFilterPreset
import com.example.ui.components.VoiceChangerMode
import com.example.ui.components.formatTimeMs
import com.example.ui.export.CyberExportManager
import com.example.ui.export.ExportResolution
import com.example.ui.theme.DarkCosmic
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

// Expanded CapCut-pro tools in bottom toolbar
enum class EditorTool(val title: String, val icon: ImageVector) {
    VIDEO("Clip", Icons.Default.Videocam),
    TRANSITIONS("Transition", Icons.AutoMirrored.Filled.CompareArrows),
    EFFECTS("Filters", Icons.Default.AutoFixHigh),
    TEXT("Text", Icons.Default.TextFields),
    STICKERS("Stickers", Icons.Default.LocalOffer),
    MUSIC("Audio", Icons.Default.MusicNote),
    PRO_FX("Pro VFX", Icons.Default.VpnKey),
    AI("AI", Icons.Default.AutoAwesome),
    EXPORT("Export", Icons.Default.FileUpload)
}

@Composable
fun EditorScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Intercept back navigation
    BackHandler { onBack() }

    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val scrollState = rememberScrollState()

    var selectedTool by remember { mutableStateOf(EditorTool.VIDEO) }

    // Multi-Clip Timeline state
    var videoClips by remember { mutableStateOf(listOf<VideoClipItem>()) }
    var selectedClipId by remember { mutableStateOf<String?>(null) }

    // Active Clip playback state
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var videoThumbnail by remember { mutableStateOf<ImageBitmap?>(null) }
    var isLoadingThumbnail by remember { mutableStateOf(false) }
    var videoName by remember { mutableStateOf<String?>(null) }
    var totalDurationMs by remember { mutableLongStateOf(0L) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var trimStartMs by remember { mutableLongStateOf(0L) }
    var trimEndMs by remember { mutableLongStateOf(0L) }

    // Speed Control state (TASK 2)
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    // Pro Features state (Transitions, Stickers, Beat Sync, Reverse, Speed Curves, Green Screen, PIP, Split Screen, Voice Changer, TTS, Auto-Captions)
    var selectedTransition by remember { mutableStateOf(CyberTransitionPreset.DISSOLVE) }
    var transitionDurationSec by remember { mutableFloatStateOf(0.5f) }
    var selectedSpeedCurve by remember { mutableStateOf(SpeedCurvePreset.STANDARD) }
    var isReversed by remember { mutableStateOf(false) }
    var chromaKeyState by remember { mutableStateOf(ChromaKeyState()) }
    var pipState by remember { mutableStateOf(PipState()) }
    var splitScreenMode by remember { mutableStateOf(SplitScreenMode.NONE) }
    var voiceChangerMode by remember { mutableStateOf(VoiceChangerMode.ORIGINAL) }
    var isBeatSyncActive by remember { mutableStateOf(false) }
    var placedStickers by remember { mutableStateOf(listOf<PlacedStickerItem>()) }
    var showStickerPickerDialog by remember { mutableStateOf(false) }
    var showTtsDialog by remember { mutableStateOf(false) }
    var showAutoCaptionsDialog by remember { mutableStateOf(false) }

    // Filter VFX state
    var selectedFilter by remember { mutableStateOf(VideoFilterPreset.NONE) }

    // Text Overlays state
    var textOverlays by remember { mutableStateOf(listOf<TextOverlayItem>()) }
    var showAddTextDialog by remember { mutableStateOf(false) }

    // AI Features state - Unified AI Dialog
    var showAiUnifiedDialog by remember { mutableStateOf(false) }

    // Undo / Redo Stacks for Pro-Level editing history
    var undoStack by remember { mutableStateOf(listOf<List<TextOverlayItem>>()) }
    var redoStack by remember { mutableStateOf(listOf<List<TextOverlayItem>>()) }

    fun pushHistory(newOverlays: List<TextOverlayItem>) {
        undoStack = undoStack + listOf(textOverlays)
        redoStack = emptyList() // clear redo on new action
        textOverlays = newOverlays
    }

    // Export State (Media3 Transformer: Video + Text Overlays + Music -> MP4)
    var showExportDialog by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableIntStateOf(0) }
    var isExportSuccess by remember { mutableStateOf(false) }
    var exportedVideoPath by remember { mutableStateOf("") }
    var exportErrorMessage by remember { mutableStateOf<String?>(null) }
    val exportManager = remember { CyberExportManager(context, scope) }

    // Music / Audio state
    var selectedAudioUri by remember { mutableStateOf<Uri?>(null) }
    var audioFileName by remember { mutableStateOf<String?>(null) }
    var audioDurationStr by remember { mutableStateOf<String?>(null) }
    var audioVolumePercent by remember { mutableFloatStateOf(80f) }
    var audioMediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    // Playback state
    var isPlaying by remember { mutableStateOf(false) }
    var videoViewInstance by remember { mutableStateOf<VideoView?>(null) }
    var mediaPlayerInstance by remember { mutableStateOf<MediaPlayer?>(null) }

    // Helper to add multiple video URIs with metadata extraction
    fun addVideoUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        isLoadingThumbnail = true
        scope.launch(Dispatchers.IO) {
            val newClips = uris.map { uri ->
                var dur = 8000L
                var name = uri.lastPathSegment ?: "cyber_clip.mp4"
                var thumbnailBitmap: ImageBitmap? = null

                try {
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(context, uri)
                    dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 8000L
                    val frame = retriever.frameAtTime ?: retriever.getFrameAtTime(500_000)
                    if (frame != null) {
                        thumbnailBitmap = frame.asImageBitmap()
                    }
                    retriever.release()
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                if (uri.scheme == ContentResolver.SCHEME_ANDROID_RESOURCE) {
                    name = uri.lastPathSegment?.let { "$it.mp4" } ?: "sample_cyber_clip.mp4"
                } else {
                    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (cursor.moveToFirst() && nameIdx >= 0) {
                            name = cursor.getString(nameIdx)
                        }
                    }
                }

                VideoClipItem(
                    uri = uri,
                    name = name,
                    durationMs = dur,
                    thumbnail = thumbnailBitmap
                )
            }

            withContext(Dispatchers.Main) {
                val updated = videoClips + newClips
                videoClips = updated
                isLoadingThumbnail = false

                if (selectedClipId == null || videoClips.none { it.id == selectedClipId }) {
                    val first = newClips.firstOrNull()
                    if (first != null) {
                        selectedClipId = first.id
                        selectedVideoUri = first.uri
                        videoName = first.name
                        totalDurationMs = first.durationMs
                        trimStartMs = 0L
                        trimEndMs = first.durationMs
                        videoThumbnail = first.thumbnail
                        isPlaying = false
                    }
                }
                snackbarHostState.showSnackbar("${newClips.size} clip(s) loaded into timeline")
            }
        }
    }

    // Multi-video picker launcher
    val multipleVideoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            addVideoUris(uris)
        }
    }

    // Audio file picker
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedAudioUri = uri
            scope.launch {
                snackbarHostState.showSnackbar("Cyber audio stem attached")
            }
        }
    }

    // Helper to load sample cyber clips
    fun loadSampleCyberClips() {
        val sample1 = Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.sample_cyber_clip}")
        val sample2 = Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.sample_cyber_clip_2}")
        addVideoUris(listOf(sample1, sample2))
    }

    // Helper to load sample cyber audio
    fun loadSampleAudio() {
        val sampleUri = Uri.parse("${ContentResolver.SCHEME_ANDROID_RESOURCE}://${context.packageName}/${R.raw.cyber_synth_loop}")
        selectedAudioUri = sampleUri
        scope.launch {
            snackbarHostState.showSnackbar("Sample Cyber Synth Audio loaded")
        }
    }

    // Update active video state when selected clip changes
    LaunchedEffect(selectedClipId) {
        val clip = videoClips.find { it.id == selectedClipId }
        if (clip != null) {
            selectedVideoUri = clip.uri
            videoName = clip.name
            totalDurationMs = clip.durationMs
            trimStartMs = 0L
            trimEndMs = clip.durationMs
            currentPositionMs = 0L
            videoThumbnail = clip.thumbnail
            isPlaying = false
        }
    }

    // Synchronize video playback speed with MediaPlayer instance (TASK 2)
    LaunchedEffect(playbackSpeed, mediaPlayerInstance) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                mediaPlayerInstance?.let { mp ->
                    mp.playbackParams = mp.playbackParams.setSpeed(playbackSpeed)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Manage Audio MediaPlayer lifecycle, looping, and volume
    DisposableEffect(selectedAudioUri) {
        val uri = selectedAudioUri
        if (uri != null) {
            try {
                val mp = MediaPlayer().apply {
                    setDataSource(context, uri)
                    isLooping = true
                    val vol = (audioVolumePercent / 100f).coerceIn(0f, 1f)
                    setVolume(vol, vol)
                    prepare()
                    if (isPlaying) {
                        start()
                    }
                }
                audioMediaPlayer = mp

                try {
                    val retriever = MediaMetadataRetriever()
                    retriever.setDataSource(context, uri)
                    val dur = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 12000L
                    audioDurationStr = formatTimeMs(dur)
                    retriever.release()
                } catch (e: Exception) {
                    audioDurationStr = "00:12.0"
                }

                if (uri.scheme == ContentResolver.SCHEME_ANDROID_RESOURCE) {
                    audioFileName = "cyber_synth_loop.mp3"
                } else {
                    context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (cursor.moveToFirst() && nameIdx >= 0) {
                            audioFileName = cursor.getString(nameIdx)
                        }
                    }
                    if (audioFileName == null) {
                        audioFileName = uri.lastPathSegment ?: "cyber_audio.mp3"
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        onDispose {
            try {
                exportManager.cancelExport()
                audioMediaPlayer?.run {
                    if (isPlaying) stop()
                    release()
                }
            } catch (e: Exception) {
                // Ignore
            }
            audioMediaPlayer = null
        }
    }

    // Synchronize audio volume changes
    LaunchedEffect(audioVolumePercent) {
        val vol = (audioVolumePercent / 100f).coerceIn(0f, 1f)
        try {
            audioMediaPlayer?.setVolume(vol, vol)
        } catch (e: Exception) {
            // Ignore
        }
    }

    // Synchronize audio Play/Pause with Video Play/Pause
    LaunchedEffect(isPlaying) {
        try {
            audioMediaPlayer?.let { mp ->
                if (isPlaying) {
                    if (!mp.isPlaying) mp.start()
                } else {
                    if (mp.isPlaying) mp.pause()
                }
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    // Video playback progress ticker loop
    LaunchedEffect(isPlaying, trimStartMs, trimEndMs) {
        while (isActive && isPlaying) {
            videoViewInstance?.let { vv ->
                val pos = vv.currentPosition.toLong()
                currentPositionMs = pos

                // Respect trim boundaries
                if (pos >= trimEndMs && trimEndMs > trimStartMs) {
                    vv.seekTo(trimStartMs.toInt())
                    currentPositionMs = trimStartMs
                }
            }
            delay(50)
        }
    }

    // Add Text Dialog
    if (showAddTextDialog) {
        CyberAddTextDialog(
            onDismiss = { showAddTextDialog = false },
            onAddText = { text, color, fontSize, animStyle ->
                pushHistory(textOverlays + TextOverlayItem(
                    text = text,
                    color = color,
                    fontSizeSp = fontSize,
                    animationStyle = animStyle,
                    offsetX = 0f,
                    offsetY = 0f
                ))
                scope.launch {
                    snackbarHostState.showSnackbar("Text overlay added. Drag to reposition.")
                }
            }
        )
    }

    // 15+ Sticker Packs Picker Dialog
    if (showStickerPickerDialog) {
        CyberStickerPickerDialog(
            onDismiss = { showStickerPickerDialog = false },
            onStickerPicked = { stickerDef ->
                placedStickers = placedStickers + PlacedStickerItem(
                    sticker = stickerDef,
                    offsetX = 0f,
                    offsetY = 0f
                )
                scope.launch {
                    snackbarHostState.showSnackbar("Sticker added: ${stickerDef.label}. Drag to reposition.")
                }
            }
        )
    }

    // Text-To-Speech (TTS) Dialog
    if (showTtsDialog) {
        CyberTextToSpeechDialog(
            onDismiss = { showTtsDialog = false },
            onSpeechGenerated = { speechScript ->
                pushHistory(textOverlays + TextOverlayItem(
                    text = speechScript,
                    color = NeonCyanBright,
                    fontSizeSp = 22f,
                    animationStyle = TextAnimationStyle.TYPEWRITER
                ))
                scope.launch {
                    snackbarHostState.showSnackbar("TTS Voiceover & subtitle generated")
                }
            }
        )
    }

    // Auto-Captions Dialog
    if (showAutoCaptionsDialog) {
        CyberAutoCaptionsDialog(
            onDismiss = { showAutoCaptionsDialog = false },
            onCaptionsGenerated = { generatedCaptions ->
                val newItems = generatedCaptions.mapIndexed { idx, cap ->
                    TextOverlayItem(
                        text = cap,
                        color = if (idx == 0) NeonCyanBright else Color.White,
                        fontSizeSp = 20f,
                        animationStyle = TextAnimationStyle.KARAOKE_FILL,
                        offsetX = 0f,
                        offsetY = (idx * 50).toFloat()
                    )
                }
                pushHistory(textOverlays + newItems)
                scope.launch {
                    snackbarHostState.showSnackbar("Generated ${generatedCaptions.size} AI auto-captions")
                }
            }
        )
    }

    // Unified AI Dialog (PART 1: Gemini 1.5 Flash + Rotating Ring + 3 Chips + Auto Caption + Smart Filter)
    if (showAiUnifiedDialog) {
        CyberUnifiedAiDialog(
            onDismiss = { showAiUnifiedDialog = false },
            onSelectSuggestion = { suggestionText ->
                textOverlays = textOverlays + TextOverlayItem(
                    text = suggestionText,
                    color = NeonCyan,
                    fontSizeSp = 24f,
                    animationStyle = TextAnimationStyle.GLITCH_FLICKER,
                    offsetX = 0f,
                    offsetY = 0f
                )
                scope.launch {
                    snackbarHostState.showSnackbar("AI Text added: $suggestionText")
                }
            },
            onAutoCaptionClick = {
                showAiUnifiedDialog = false
                showAutoCaptionsDialog = true
            },
            onSmartFilterClick = {
                val candidateFilters = listOf(
                    VideoFilterPreset.CYBER_CYAN,
                    VideoFilterPreset.NEON_PINK,
                    VideoFilterPreset.MATRIX_GREEN,
                    VideoFilterPreset.VAPORWAVE,
                    VideoFilterPreset.CINEMATIC,
                    VideoFilterPreset.COLD_BLUE
                )
                val suggested = candidateFilters.filter { it != selectedFilter }.randomOrNull() ?: VideoFilterPreset.CYBER_CYAN
                selectedFilter = suggested
                Toast.makeText(context, "AI Vision: Applied ${suggested.displayName}", Toast.LENGTH_SHORT).show()
                scope.launch {
                    snackbarHostState.showSnackbar("AI Analysis: Applied ${suggested.displayName} filter")
                }
                showAiUnifiedDialog = false
            }
        )
    }

    // Export Dialog (Media3 Transformer: 720p/1080p, Progress Bar, Movies/VideoEditor2050, Toast)
    if (showExportDialog) {
        CyberExportDialog(
            isExporting = isExporting,
            exportProgress = exportProgress,
            isSuccess = isExportSuccess,
            exportedPath = exportedVideoPath,
            errorMessage = exportErrorMessage,
            hasVideo = (selectedVideoUri != null || videoClips.isNotEmpty()),
            hasAudio = selectedAudioUri != null,
            textOverlayCount = textOverlays.size,
            onDismiss = {
                if (!isExporting) {
                    showExportDialog = false
                    exportErrorMessage = null
                    isExportSuccess = false
                }
            },
            onStartExport = { resolution ->
                isExporting = true
                exportProgress = 1
                exportErrorMessage = null
                isExportSuccess = false

                exportManager.startExport(
                    videoClips = videoClips,
                    selectedVideoUri = selectedVideoUri,
                    audioUri = selectedAudioUri,
                    textOverlays = textOverlays,
                    resolution = resolution,
                    onProgress = { progress ->
                        exportProgress = progress
                    },
                    onSuccess = { uri, path ->
                        isExporting = false
                        exportProgress = 100
                        isExportSuccess = true
                        exportedVideoPath = path
                        scope.launch {
                            snackbarHostState.showSnackbar("Exported to $path")
                        }
                    },
                    onError = { err ->
                        isExporting = false
                        exportErrorMessage = err
                        scope.launch {
                            snackbarHostState.showSnackbar("Export failed: $err")
                        }
                    }
                )
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkCosmic)
            .testTag("editor_screen_root")
    ) {
        // Deep cosmic background (#050505) with soft ambient halo and film grain
        CosmicCyberBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // TOP SECTION: Back arrow + "EDITOR 2050" title with soft ambient glow
            EditorTopBar(
                onBack = {
                    videoViewInstance?.stopPlayback()
                    try {
                        audioMediaPlayer?.run {
                            if (isPlaying) stop()
                            release()
                        }
                    } catch (e: Exception) {}
                    onBack()
                },
                onExportClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    exportErrorMessage = null
                    isExportSuccess = false
                    exportProgress = 0
                    showExportDialog = true
                },
                canUndo = undoStack.isNotEmpty(),
                canRedo = redoStack.isNotEmpty(),
                onUndoClick = {
                    if (undoStack.isNotEmpty()) {
                        val previous = undoStack.last()
                        redoStack = redoStack + listOf(textOverlays)
                        undoStack = undoStack.dropLast(1)
                        textOverlays = previous
                        scope.launch {
                            snackbarHostState.showSnackbar("Undo: Reverted overlay action")
                        }
                    }
                },
                onRedoClick = {
                    if (redoStack.isNotEmpty()) {
                        val next = redoStack.last()
                        undoStack = undoStack + listOf(textOverlays)
                        redoStack = redoStack.dropLast(1)
                        textOverlays = next
                        scope.launch {
                            snackbarHostState.showSnackbar("Redo: Restored overlay action")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )

            // MIDDLE SCROLLABLE SECTION: Preview + Controls + Tools
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Video Preview Area with Filter Shader, Speed Badge, and Text Overlays
                VideoPlaybackPreviewArea(
                    videoUri = selectedVideoUri,
                    videoThumbnail = videoThumbnail,
                    activeFilter = selectedFilter,
                    playbackSpeed = playbackSpeed,
                    isLoading = isLoadingThumbnail,
                    isPlaying = isPlaying,
                    videoName = videoName,
                    currentPositionMs = currentPositionMs,
                    totalDurationMs = totalDurationMs,
                    textOverlays = textOverlays,
                    placedStickers = placedStickers,
                    onUpdateTextOverlayOffset = { id, dx, dy ->
                        textOverlays = textOverlays.map { item ->
                            if (item.id == id) {
                                item.copy(
                                    offsetX = item.offsetX + dx,
                                    offsetY = item.offsetY + dy
                                )
                            } else item
                        }
                    },
                    onDeleteTextOverlay = { id ->
                        pushHistory(textOverlays.filter { it.id != id })
                        scope.launch {
                            snackbarHostState.showSnackbar("Text overlay removed")
                        }
                    },
                    onUpdateStickerOffset = { id, dx, dy ->
                        placedStickers = placedStickers.map { item ->
                            if (item.id == id) {
                                item.copy(
                                    offsetX = item.offsetX + dx,
                                    offsetY = item.offsetY + dy
                                )
                            } else item
                        }
                    },
                    onDeleteSticker = { id ->
                        placedStickers = placedStickers.filter { it.id != id }
                        scope.launch {
                            snackbarHostState.showSnackbar("Sticker removed")
                        }
                    },
                    isReversed = isReversed,
                    chromaKeyState = chromaKeyState,
                    pipState = pipState,
                    splitScreenMode = splitScreenMode,
                    voiceChangerMode = voiceChangerMode,
                    isBeatSyncActive = isBeatSyncActive,
                    onVideoViewReady = { vv -> videoViewInstance = vv },
                    onMediaPlayerReady = { mp ->
                        mediaPlayerInstance = mp
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                mp.playbackParams = mp.playbackParams.setSpeed(playbackSpeed)
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    },
                    onPlayPauseToggle = {
                        val vv = videoViewInstance
                        if (vv != null && selectedVideoUri != null) {
                            if (isPlaying) {
                                vv.pause()
                                isPlaying = false
                            } else {
                                if (currentPositionMs !in trimStartMs..trimEndMs) {
                                    vv.seekTo(trimStartMs.toInt())
                                    currentPositionMs = trimStartMs
                                }
                                vv.start()
                                isPlaying = true
                            }
                        } else {
                            multipleVideoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        }
                    },
                    onSelectVideo = {
                        multipleVideoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    onLoadSample = { loadSampleCyberClips() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 520.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // MUSIC / AUDIO CARD & SFX LIBRARY (Shows when Audio tool is active or music is loaded)
                AnimatedVisibility(
                    visible = (selectedTool == EditorTool.MUSIC || (selectedAudioUri != null && audioFileName != null)),
                    enter = fadeIn(tween(250, easing = FastOutSlowInEasing)) + slideInVertically(
                        initialOffsetY = { it / 3 },
                        animationSpec = tween(250, easing = FastOutSlowInEasing)
                    ),
                    exit = fadeOut(tween(200, easing = FastOutSlowInEasing)) + slideOutVertically(
                        targetOffsetY = { it / 3 },
                        animationSpec = tween(200, easing = FastOutSlowInEasing)
                    )
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (selectedAudioUri != null && audioFileName != null) {
                            CyberMusicCard(
                                fileName = audioFileName ?: "cyber_track.mp3",
                                durationStr = audioDurationStr ?: "00:12.0",
                                volumePercent = audioVolumePercent,
                                isPlaying = isPlaying,
                                onVolumeChange = { audioVolumePercent = it },
                                onDelete = {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    try {
                                        audioMediaPlayer?.run {
                                            if (isPlaying) stop()
                                            release()
                                        }
                                    } catch (e: Exception) {}
                                    audioMediaPlayer = null
                                    selectedAudioUri = null
                                    audioFileName = null
                                    audioDurationStr = null
                                    scope.launch {
                                        snackbarHostState.showSnackbar("Audio track removed")
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .widthIn(max = 520.dp)
                            )
                        }

                        // 10+ Cyber Sound Effects Library
                        CyberSoundEffectsBar(
                            onSfxAttached = { sfx ->
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                scope.launch {
                                    snackbarHostState.showSnackbar("Attached SFX: ${sfx.title} to playhead")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 520.dp)
                        )

                        Spacer(modifier = Modifier.height(2.dp))
                    }
                }

                // AI OPTIONS CARD (When AI tool is active with smooth slide-up)
                AnimatedVisibility(
                    visible = (selectedTool == EditorTool.AI),
                    enter = fadeIn(tween(250, easing = FastOutSlowInEasing)) + slideInVertically(
                        initialOffsetY = { it / 3 },
                        animationSpec = tween(250, easing = FastOutSlowInEasing)
                    ),
                    exit = fadeOut(tween(200, easing = FastOutSlowInEasing)) + slideOutVertically(
                        targetOffsetY = { it / 3 },
                        animationSpec = tween(200, easing = FastOutSlowInEasing)
                    )
                ) {
                    Column {
                        CyberAiOptionsCard(
                            onAutoCaptionsClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                showAutoCaptionsDialog = true
                            },
                            onSuggestTextClick = {
                                showAiUnifiedDialog = true
                            },
                            onFilterSuggestionClick = {
                                val candidateFilters = listOf(
                                    VideoFilterPreset.CYBER_CYAN,
                                    VideoFilterPreset.NEON_PINK,
                                    VideoFilterPreset.MATRIX_GREEN,
                                    VideoFilterPreset.VAPORWAVE,
                                    VideoFilterPreset.CINEMATIC,
                                    VideoFilterPreset.COLD_BLUE
                                )
                                val suggested = candidateFilters.filter { it != selectedFilter }.randomOrNull() ?: VideoFilterPreset.CYBER_CYAN
                                selectedFilter = suggested
                                Toast.makeText(context, "AI Vision: Applied ${suggested.displayName}", Toast.LENGTH_SHORT).show()
                                scope.launch {
                                    snackbarHostState.showSnackbar("AI Analysis: Applied ${suggested.displayName} filter")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 520.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }

                // TRIM & PLAY/PAUSE CONTROLS (Active when Video tool is selected and clip is loaded)
                AnimatedVisibility(
                    visible = (selectedVideoUri != null && totalDurationMs > 0 && selectedTool == EditorTool.VIDEO),
                    enter = fadeIn(tween(250, easing = FastOutSlowInEasing)) + slideInVertically(
                        initialOffsetY = { it / 3 },
                        animationSpec = tween(250, easing = FastOutSlowInEasing)
                    ),
                    exit = fadeOut(tween(200, easing = FastOutSlowInEasing)) + slideOutVertically(
                        targetOffsetY = { it / 3 },
                        animationSpec = tween(200, easing = FastOutSlowInEasing)
                    )
                ) {
                    Column {
                        CyberTrimTimeline(
                            currentPositionMs = currentPositionMs,
                            totalDurationMs = totalDurationMs,
                            trimStartMs = trimStartMs,
                            trimEndMs = trimEndMs,
                            isPlaying = isPlaying,
                            onPlayPauseToggle = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                val vv = videoViewInstance
                                if (vv != null) {
                                    if (isPlaying) {
                                        vv.pause()
                                        isPlaying = false
                                    } else {
                                        if (currentPositionMs !in trimStartMs..trimEndMs) {
                                            vv.seekTo(trimStartMs.toInt())
                                            currentPositionMs = trimStartMs
                                        }
                                        vv.start()
                                        isPlaying = true
                                    }
                                }
                            },
                            onSeekTo = { seekMs ->
                                currentPositionMs = seekMs
                                videoViewInstance?.seekTo(seekMs.toInt())
                            },
                            onTrimChange = { startMs, endMs ->
                                trimStartMs = startMs
                                trimEndMs = endMs
                                val vv = videoViewInstance
                                if (vv != null) {
                                    if (currentPositionMs < startMs) {
                                        vv.seekTo(startMs.toInt())
                                        currentPositionMs = startMs
                                    } else if (currentPositionMs > endMs) {
                                        vv.seekTo(endMs.toInt())
                                        currentPositionMs = endMs
                                    }
                                }
                            },
                            onResetTrim = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                trimStartMs = 0L
                                trimEndMs = totalDurationMs
                                videoViewInstance?.seekTo(0)
                                currentPositionMs = 0L
                                scope.launch {
                                    snackbarHostState.showSnackbar("Trim reset to full clip length")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 520.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // SPEED CONTROL (Displayed below timeline when Video tool is active)
                        CyberSpeedControl(
                            currentSpeed = playbackSpeed,
                            onSpeedSelected = { newSpeed ->
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                playbackSpeed = newSpeed
                                scope.launch {
                                    snackbarHostState.showSnackbar("Playback speed set to ${newSpeed}x")
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .widthIn(max = 520.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }

                // Active Tool Context Info Card
                ActiveToolInfoCard(
                    tool = selectedTool,
                    hasVideo = selectedVideoUri != null,
                    hasAudio = selectedAudioUri != null,
                    activeFilterName = selectedFilter.displayName,
                    playbackSpeed = playbackSpeed,
                    clipCount = videoClips.size,
                    textOverlayCount = textOverlays.size,
                    onAddClipClick = {
                        multipleVideoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    onAddTextClick = { showAddTextDialog = true },
                    onPickAudioClick = { audioPickerLauncher.launch("audio/*") },
                    onLoadSampleAudioClick = { loadSampleAudio() },
                    onOpenStickerClick = { showStickerPickerDialog = true },
                    onOpenTtsClick = { showTtsDialog = true },
                    onOpenAutoCaptionsClick = { showAutoCaptionsDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 520.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))
            }

            // FILTER PRESETS BAR (Shown above timeline when "Effects" tool is active with slide-up)
            AnimatedVisibility(
                visible = selectedTool == EditorTool.EFFECTS,
                enter = fadeIn(tween(250, easing = FastOutSlowInEasing)) + slideInVertically(
                    initialOffsetY = { it / 2 },
                    animationSpec = tween(250, easing = FastOutSlowInEasing)
                ),
                exit = fadeOut(tween(200, easing = FastOutSlowInEasing)) + slideOutVertically(
                    targetOffsetY = { it / 2 },
                    animationSpec = tween(200, easing = FastOutSlowInEasing)
                )
            ) {
                CyberFilterBar(
                    selectedFilter = selectedFilter,
                    onFilterSelected = { filter ->
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        selectedFilter = filter
                        scope.launch {
                            snackbarHostState.showSnackbar("Applied ${filter.displayName} filter")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            // 30+ TRANSITIONS BAR (Shown above timeline when "Transitions" tool is active)
            AnimatedVisibility(
                visible = selectedTool == EditorTool.TRANSITIONS,
                enter = fadeIn(tween(250, easing = FastOutSlowInEasing)) + slideInVertically(
                    initialOffsetY = { it / 2 },
                    animationSpec = tween(250, easing = FastOutSlowInEasing)
                ),
                exit = fadeOut(tween(200, easing = FastOutSlowInEasing)) + slideOutVertically(
                    targetOffsetY = { it / 2 },
                    animationSpec = tween(200, easing = FastOutSlowInEasing)
                )
            ) {
                CyberTransitionsBar(
                    selectedTransition = selectedTransition,
                    transitionDurationSec = transitionDurationSec,
                    onTransitionSelected = { transition ->
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        selectedTransition = transition
                        scope.launch {
                            snackbarHostState.showSnackbar("Set transition to ${transition.displayName}")
                        }
                    },
                    onDurationChanged = { newDur ->
                        transitionDurationSec = newDur
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            // PRO VFX SUITE (Speed curves, Reverse, Green screen, PIP, Split screen, Voice changer)
            AnimatedVisibility(
                visible = selectedTool == EditorTool.PRO_FX,
                enter = fadeIn(tween(250, easing = FastOutSlowInEasing)) + slideInVertically(
                    initialOffsetY = { it / 2 },
                    animationSpec = tween(250, easing = FastOutSlowInEasing)
                ),
                exit = fadeOut(tween(200, easing = FastOutSlowInEasing)) + slideOutVertically(
                    targetOffsetY = { it / 2 },
                    animationSpec = tween(200, easing = FastOutSlowInEasing)
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Quick Action Toggles: Reverse & Beat Sync
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isReversed) Color(0x3DFF007F) else Color(0x1800E5FF))
                                .border(
                                    width = 1.2.dp,
                                    color = if (isReversed) Color(0xFFFF007F) else NeonCyan.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    isReversed = !isReversed
                                    scope.launch {
                                        snackbarHostState.showSnackbar(if (isReversed) "Reverse Video Enabled ◀◀" else "Reverse Video Disabled")
                                    }
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isReversed) "REVERSE: ACTIVE ◀◀" else "REVERSE VIDEO ◀◀",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (isReversed) Color(0xFFFF007F) else NeonCyanBright
                                )
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isBeatSyncActive) Color(0x3D00E5FF) else Color(0x1800E5FF))
                                .border(
                                    width = 1.2.dp,
                                    color = if (isBeatSyncActive) NeonCyanBright else NeonCyan.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    isBeatSyncActive = !isBeatSyncActive
                                    scope.launch {
                                        snackbarHostState.showSnackbar(if (isBeatSyncActive) "Beat Sync Active: Cuts quantized to music tempo" else "Beat Sync Disabled")
                                    }
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isBeatSyncActive) "BEAT SYNC: ON ⚡" else "BEAT SYNC ⚡",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = if (isBeatSyncActive) NeonCyanBright else TextSecondary
                                )
                            )
                        }
                    }

                    // Speed Curve Presets & Graph
                    CyberSpeedCurveControl(
                        selectedCurve = selectedSpeedCurve,
                        onCurveSelected = { curve ->
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            selectedSpeedCurve = curve
                            val avgMultiplier = if (curve.points.isNotEmpty()) curve.points.average().toFloat() else 1.0f
                            playbackSpeed = avgMultiplier
                            scope.launch {
                                snackbarHostState.showSnackbar("Speed curve applied: ${curve.title}")
                            }
                        }
                    )

                    // Chroma Key (Green Screen)
                    CyberChromaKeyControl(
                        state = chromaKeyState,
                        onStateChange = { chromaKeyState = it }
                    )

                    // PIP & Split Screen
                    CyberPipAndSplitControl(
                        pipState = pipState,
                        onPipChange = { pipState = it },
                        splitMode = splitScreenMode,
                        onSplitChange = { splitScreenMode = it }
                    )

                    // Voice Changer (5 Modes)
                    CyberVoiceChangerControl(
                        selectedMode = voiceChangerMode,
                        onModeSelected = { mode ->
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            voiceChangerMode = mode
                            scope.launch {
                                snackbarHostState.showSnackbar("Voice preset: ${mode.title}")
                            }
                        }
                    )
                }
            }

            // MULTI-CLIP HORIZONTAL TIMELINE STRIP (Positioned at bottom of Editor Screen above toolbar)
            AnimatedVisibility(
                visible = videoClips.isNotEmpty(),
                enter = fadeIn(tween(250, easing = FastOutSlowInEasing)) + slideInVertically(
                    initialOffsetY = { it / 2 },
                    animationSpec = tween(250, easing = FastOutSlowInEasing)
                ),
                exit = fadeOut(tween(200, easing = FastOutSlowInEasing)) + slideOutVertically(
                    targetOffsetY = { it / 2 },
                    animationSpec = tween(200, easing = FastOutSlowInEasing)
                )
            ) {
                MultiClipTimelineStrip(
                    clips = videoClips,
                    selectedClipId = selectedClipId,
                    onSelectClip = { clip ->
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        selectedClipId = clip.id
                    },
                    onRemoveClip = { idToRemove ->
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        val remaining = videoClips.filter { it.id != idToRemove }
                        videoClips = remaining
                        if (selectedClipId == idToRemove) {
                            val next = remaining.firstOrNull()
                            selectedClipId = next?.id
                            if (next == null) {
                                selectedVideoUri = null
                                videoThumbnail = null
                                totalDurationMs = 0L
                                isPlaying = false
                            }
                        }
                        scope.launch {
                            snackbarHostState.showSnackbar("Clip removed from timeline")
                        }
                    },
                    onAddClip = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        multipleVideoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }

            // BOTTOM TOOLBAR: 6 icons in a row with 24dp rounded corners and soft cyan glow
            EditorBottomToolbar(
                selectedTool = selectedTool,
                onToolSelected = { tool ->
                    selectedTool = tool
                    when (tool) {
                        EditorTool.TEXT -> {
                            showAddTextDialog = true
                        }
                        EditorTool.STICKERS -> {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            showStickerPickerDialog = true
                        }
                        EditorTool.MUSIC -> {
                            if (selectedAudioUri == null) {
                                audioPickerLauncher.launch("audio/*")
                            }
                        }
                        EditorTool.AI -> {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            showAiUnifiedDialog = true
                            scope.launch {
                                scrollState.animateScrollTo(scrollState.maxValue)
                            }
                        }
                        EditorTool.EXPORT -> {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            exportErrorMessage = null
                            isExportSuccess = false
                            exportProgress = 0
                            showExportDialog = true
                        }
                        EditorTool.EFFECTS -> {
                            // Filter bar displays above timeline
                        }
                        EditorTool.TRANSITIONS -> {
                            // Transitions bar displays above timeline
                        }
                        EditorTool.PRO_FX -> {
                            // Pro VFX suite displays above timeline
                        }
                        EditorTool.VIDEO -> {
                            scope.launch {
                                snackbarHostState.showSnackbar("Video Timeline, Trim & Speed active")
                            }
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 76.dp)
        )
    }
}

/**
 * Top App Bar: Back arrow + "EDITOR 2050" title with soft ambient glow
 */
@Composable
private fun EditorTopBar(
    onBack: () -> Unit,
    onExportClick: () -> Unit,
    canUndo: Boolean = false,
    canRedo: Boolean = false,
    onUndoClick: () -> Unit = {},
    onRedoClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Color(0x1F00E5FF))
                .border(1.dp, NeonCyan.copy(alpha = 0.35f), CircleShape)
                .testTag("editor_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back to Home",
                tint = NeonCyan,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // "EDITOR 2050" Title - Clean minimalist style
        Box(contentAlignment = Alignment.CenterStart) {
            Text(
                text = "EDITOR 2050",
                style = TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    letterSpacing = 1.4.sp,
                    color = Color(0xFFE8E8E8)
                )
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        // UNDO BUTTON
        IconButton(
            onClick = {
                if (canUndo) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onUndoClick()
                }
            },
            enabled = canUndo,
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(if (canUndo) Color(0x2200E5FF) else Color(0x0C00E5FF))
                .border(1.dp, if (canUndo) NeonCyan.copy(alpha = 0.5f) else Color(0x1500E5FF), CircleShape)
                .testTag("editor_undo_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Undo,
                contentDescription = "Undo Action",
                tint = if (canUndo) NeonCyanBright else Color(0x4000E5FF),
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // REDO BUTTON
        IconButton(
            onClick = {
                if (canRedo) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onRedoClick()
                }
            },
            enabled = canRedo,
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(if (canRedo) Color(0x2200E5FF) else Color(0x0C00E5FF))
                .border(1.dp, if (canRedo) NeonCyan.copy(alpha = 0.5f) else Color(0x1500E5FF), CircleShape)
                .testTag("editor_redo_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Redo,
                contentDescription = "Redo Action",
                tint = if (canRedo) NeonCyanBright else Color(0x4000E5FF),
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Holographic resolution badge with 24dp style and Quick Export trigger
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x2200E5FF))
                .border(1.dp, NeonCyan.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = NeonCyan)
                ) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onExportClick()
                }
                .padding(horizontal = 11.dp, vertical = 6.dp)
                .testTag("top_bar_export_button"),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.FileUpload,
                    contentDescription = "Export Video",
                    tint = NeonCyanBright,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "EXPORT",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = NeonCyanBright
                    )
                )
            }
        }
    }
}

/**
 * Video Preview & Interactive Playback Area with 24dp rounded corners,
 * current speed badge, filter shader, and draggable text overlays.
 */
@Composable
private fun VideoPlaybackPreviewArea(
    videoUri: Uri?,
    videoThumbnail: ImageBitmap?,
    activeFilter: VideoFilterPreset,
    playbackSpeed: Float,
    isLoading: Boolean,
    isPlaying: Boolean,
    videoName: String?,
    currentPositionMs: Long,
    totalDurationMs: Long,
    textOverlays: List<TextOverlayItem>,
    placedStickers: List<PlacedStickerItem> = emptyList(),
    onUpdateTextOverlayOffset: (id: String, dx: Float, dy: Float) -> Unit,
    onDeleteTextOverlay: (id: String) -> Unit,
    onUpdateStickerOffset: (id: String, dx: Float, dy: Float) -> Unit = { _, _, _ -> },
    onDeleteSticker: (id: String) -> Unit = {},
    isReversed: Boolean = false,
    chromaKeyState: ChromaKeyState = ChromaKeyState(),
    pipState: PipState = PipState(),
    splitScreenMode: SplitScreenMode = SplitScreenMode.NONE,
    voiceChangerMode: VoiceChangerMode = VoiceChangerMode.ORIGINAL,
    isBeatSyncActive: Boolean = false,
    onVideoViewReady: (VideoView) -> Unit,
    onMediaPlayerReady: (MediaPlayer) -> Unit,
    onPlayPauseToggle: () -> Unit,
    onSelectVideo: () -> Unit,
    onLoadSample: () -> Unit,
    modifier: Modifier = Modifier
) {
    val previewShape = RoundedCornerShape(24.dp)

    // Smooth subtle zoom-in (1.0 -> 1.02) when video plays, zoom-out when paused
    val previewZoomScale by animateFloatAsState(
        targetValue = if (isPlaying) 1.02f else 1.0f,
        animationSpec = tween(350, easing = FastOutSlowInEasing),
        label = "preview_zoom_scale"
    )

    Box(
        modifier = modifier
            .aspectRatio(16f / 9f)
            .graphicsLayer {
                scaleX = previewZoomScale
                scaleY = previewZoomScale
            }
            .shadow(
                elevation = 14.dp,
                shape = previewShape,
                ambientColor = NeonCyan.copy(alpha = 0.4f),
                spotColor = NeonCyan.copy(alpha = 0.4f)
            )
            .clip(previewShape)
            .background(Color(0xFF000000))
            .border(
                width = 1.5.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        NeonCyanBright.copy(alpha = 0.8f),
                        NeonCyan.copy(alpha = 0.5f),
                        Color(0xFF009CB0),
                        NeonCyanBright.copy(alpha = 0.8f)
                    )
                ),
                shape = previewShape
            )
            .testTag("video_preview_box"),
        contentAlignment = Alignment.Center
    ) {
        if (isLoading) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(
                    color = NeonCyan,
                    modifier = Modifier.size(34.dp),
                    strokeWidth = 2.5.dp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "INITIALIZING STREAM...",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = NeonCyanBright,
                        letterSpacing = 1.sp
                    )
                )
            }
        } else if (videoUri != null) {
            // Live VideoView with Video playback & MediaPlayer speed hook
            AndroidView(
                factory = { ctx ->
                    VideoView(ctx).apply {
                        setVideoURI(videoUri)
                        setOnPreparedListener { mp ->
                            mp.isLooping = true
                            onMediaPlayerReady(mp)
                            onVideoViewReady(this)
                        }
                    }
                },
                update = { vv ->
                    onVideoViewReady(vv)
                },
                modifier = Modifier.fillMaxSize()
            )

            // Filter VFX Shader Overlay Layer on Video
            if (activeFilter != VideoFilterPreset.NONE) {
                if (activeFilter.gradientColors != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Brush.linearGradient(activeFilter.gradientColors))
                    )
                } else if (activeFilter.overlayColor != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(activeFilter.overlayColor)
                    )
                }

                if (activeFilter.isMonochrome) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0x38000000))
                    )
                }
            }

            // Click overlay to toggle Play/Pause when tapping video background
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = NeonCyan),
                        onClick = onPlayPauseToggle
                    )
            )

            // Soft Ambient Play/Pause Center Indicator
            AnimatedVisibility(
                visible = !isPlaying,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(Color(0x99041018))
                        .border(1.5.dp, NeonCyan.copy(alpha = 0.7f), CircleShape)
                        .clickable(onClick = onPlayPauseToggle),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = NeonCyanBright,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            // Top Header overlay with Video Title, Filter Badge & Speed Badge (TASK 2)
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xB3000000), Color.Transparent)
                        )
                    )
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (videoName != null) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xB3051420))
                                .border(0.8.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = videoName,
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 10.sp,
                                    color = TextPrimary
                                ),
                                maxLines = 1
                            )
                        }
                    }

                    if (isReversed) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x80FF007F))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "REVERSE ◀◀",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                    }

                    if (chromaKeyState.enabled) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x8000FF00))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "CHROMA ON",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            )
                        }
                    }

                    if (voiceChangerMode != VoiceChangerMode.ORIGINAL) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x807B2CBF))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = voiceChangerMode.title.uppercase().take(10),
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                        }
                    }

                    if (isBeatSyncActive) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x8000E5FF))
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "BEAT SYNC",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF041219)
                                )
                            )
                        }
                    }
                }

                // Current Speed Badge + Add Clips Pill
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x3300E5FF))
                            .border(1.dp, NeonCyan.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                            .testTag("preview_speed_badge")
                    ) {
                        val speedStr = when (playbackSpeed) {
                            1.0f -> "1x"
                            0.5f -> "0.5x"
                            0.75f -> "0.75x"
                            1.25f -> "1.25x"
                            1.5f -> "1.5x"
                            2.0f -> "2x"
                            3.0f -> "3x"
                            else -> "${playbackSpeed}x"
                        }
                        Text(
                            text = speedStr,
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = NeonCyanBright
                            )
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x2800E5FF))
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .clickable(onClick = onSelectVideo)
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "+ CLIPS",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = NeonCyanBright
                            )
                        )
                    }
                }
            }

            // Bottom overlay with Time Counter and Status
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color(0xB3000000))
                        )
                    )
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${formatTimeMs(currentPositionMs)} / ${formatTimeMs(totalDurationMs)}",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = NeonCyan
                    )
                )

                Text(
                    text = if (isPlaying) "PLAYING" else "PAUSED",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isPlaying) NeonCyanBright else TextMuted
                    )
                )
            }
        } else {
            // Unselected state: "TAP TO SELECT VIDEO" text with plus icon
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Color(0x2000E5FF))
                        .border(1.2.dp, NeonCyan, CircleShape)
                        .clickable(onClick = onSelectVideo),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Select Videos Icon",
                        tint = NeonCyanBright,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "TAP TO SELECT VIDEOS",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        letterSpacing = 1.6.sp,
                        color = TextPrimary,
                        shadow = Shadow(
                            color = NeonCyan.copy(alpha = 0.5f),
                            blurRadius = 14f,
                            offset = Offset.Zero
                        )
                    ),
                    modifier = Modifier.clickable(onClick = onSelectVideo),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "PICK MULTIPLE CLIPS FOR TIMELINE",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x1800E5FF))
                        .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                        .clickable(onClick = onLoadSample)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "OR LOAD MULTI-SAMPLE CYBER CLIPS",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                        )
                    }
                }
            }
        }

        // Split Screen Grid Divider
        if (splitScreenMode == SplitScreenMode.DUAL_VERTICAL) {
            Box(
                modifier = Modifier
                    .width(2.dp)
                    .fillMaxSize()
                    .background(NeonCyan.copy(alpha = 0.65f))
            )
        } else if (splitScreenMode == SplitScreenMode.DUAL_HORIZONTAL) {
            Box(
                modifier = Modifier
                    .height(2.dp)
                    .fillMaxSize()
                    .background(NeonCyan.copy(alpha = 0.65f))
            )
        } else if (splitScreenMode == SplitScreenMode.QUAD_MATRIX) {
            Box(
                modifier = Modifier
                    .width(1.5.dp)
                    .fillMaxSize()
                    .background(NeonCyan.copy(alpha = 0.5f))
            )
            Box(
                modifier = Modifier
                    .height(1.5.dp)
                    .fillMaxSize()
                    .background(NeonCyan.copy(alpha = 0.5f))
            )
        }

        // Picture-in-Picture (PIP) Window Overlay
        if (pipState.enabled) {
            Box(
                modifier = Modifier
                    .padding(12.dp)
                    .size(96.dp, 56.dp)
                    .align(Alignment.BottomEnd)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xE605101A))
                    .border(1.2.dp, NeonCyan, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "PIP TRACK",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        color = NeonCyanBright,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        // DRAGGABLE TEXT OVERLAYS LAYER (Rendered on top of video preview)
        textOverlays.forEach { overlay ->
            DraggableTextOverlayView(
                item = overlay,
                onDrag = { dx, dy -> onUpdateTextOverlayOffset(overlay.id, dx, dy) },
                onDelete = { onDeleteTextOverlay(overlay.id) }
            )
        }

        // DRAGGABLE STICKERS OVERLAY LAYER
        placedStickers.forEach { sticker ->
            DraggableStickerOverlayView(
                item = sticker,
                onDrag = { dx, dy -> onUpdateStickerOffset(sticker.id, dx, dy) },
                onDelete = { onDeleteSticker(sticker.id) }
            )
        }
    }
}

/**
 * Draggable Text Overlay Component with Soft Ambient Glow and 'X' Delete Button
 */
@Composable
private fun DraggableTextOverlayView(
    item: TextOverlayItem,
    onDrag: (dx: Float, dy: Float) -> Unit,
    onDelete: () -> Unit
) {
    Box(
        modifier = Modifier
            .offset { IntOffset(item.offsetX.roundToInt(), item.offsetY.roundToInt()) }
            .pointerInput(item.id) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            }
            .padding(4.dp)
            .testTag("text_overlay_${item.id}"),
        contentAlignment = Alignment.TopEnd
    ) {
        // Glowing Text Body with Animation Wrapper
        Box(
            modifier = Modifier
                .padding(top = 8.dp, end = 8.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x8C000000))
                .border(1.dp, Color(0x3800E5FF), RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            AnimatedTextOverlayWrapper(animationStyle = item.animationStyle) {
                Text(
                    text = item.text,
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Black,
                        fontSize = item.fontSizeSp.sp,
                        color = item.color,
                        letterSpacing = 1.sp,
                        shadow = Shadow(
                            color = NeonCyan.copy(alpha = 0.55f),
                            blurRadius = 14f,
                            offset = Offset.Zero
                        ),
                        textAlign = TextAlign.Center
                    )
                )
            }
        }

        // Small "X" delete button on top-right corner
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(Color(0xFFDD1144))
                .border(1.dp, Color.White, CircleShape)
                .clickable(onClick = onDelete)
                .testTag("delete_text_${item.id}"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Delete Text",
                tint = Color.White,
                modifier = Modifier.size(13.dp)
            )
        }
    }
}

/**
 * Bottom Toolbar with 6 icons in a row: Video, Text, Music, Effects, AI, Export
 * 24dp rounded corners.
 */
@Composable
private fun EditorBottomToolbar(
    selectedTool: EditorTool,
    onToolSelected: (EditorTool) -> Unit,
    modifier: Modifier = Modifier
) {
    val barShape = RoundedCornerShape(24.dp)

    Box(
        modifier = modifier
            .clip(barShape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x2200E5FF),
                        Color(0x12080E16),
                        Color(0x2E000000)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.45f),
                        Color.White.copy(alpha = 0.12f),
                        NeonCyan.copy(alpha = 0.35f)
                    )
                ),
                shape = barShape
            )
            .padding(vertical = 8.dp, horizontal = 6.dp)
    ) {
        val toolbarScrollState = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(toolbarScrollState),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            EditorTool.values().forEach { tool ->
                val isSelected = tool == selectedTool
                ToolbarItem(
                    tool = tool,
                    isSelected = isSelected,
                    onClick = { onToolSelected(tool) }
                )
            }
        }
    }
}

@Composable
private fun ToolbarItem(
    tool: EditorTool,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val itemShape = RoundedCornerShape(16.dp)
    val interactionSource = remember { MutableInteractionSource() }
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()
    var isPressedState by remember { mutableStateOf(false) }

    // Toolbar icon taps: scale 0.95 bounce back (spring animation)
    val bounceScale by animateFloatAsState(
        targetValue = if (isPressedState) 0.95f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "tool_scale_bounce"
    )

    Box(
        modifier = Modifier
            .graphicsLayer {
                scaleX = bounceScale
                scaleY = bounceScale
            }
            .clip(itemShape)
            .then(
                if (isSelected) {
                    Modifier
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0x3500E5FF),
                                    Color(0x1800E5FF)
                                )
                            )
                        )
                        .border(
                            width = 1.2.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    NeonCyanBright,
                                    Color.White.copy(alpha = 0.6f),
                                    NeonCyan
                                )
                            ),
                            shape = itemShape
                        )
                        .shadow(
                            elevation = 8.dp,
                            shape = itemShape,
                            ambientColor = NeonCyan.copy(alpha = 0.5f),
                            spotColor = NeonCyan.copy(alpha = 0.5f)
                        )
                } else {
                    Modifier.background(Color.Transparent)
                }
            )
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = NeonCyan),
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    coroutineScope.launch {
                        isPressedState = true
                        delay(90)
                        isPressedState = false
                    }
                    onClick()
                }
            )
            .padding(horizontal = 9.dp, vertical = 6.dp)
            .testTag("tool_${tool.name.lowercase()}"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = tool.icon,
                contentDescription = tool.title,
                tint = if (isSelected) NeonCyanBright else NeonCyan.copy(alpha = 0.55f),
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = tool.title,
                style = TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 10.sp,
                    letterSpacing = 0.4.sp,
                    color = if (isSelected) NeonCyanBright else TextSecondary,
                    shadow = if (isSelected) {
                        Shadow(
                            color = NeonCyan.copy(alpha = 0.45f),
                            blurRadius = 10f,
                            offset = Offset.Zero
                        )
                    } else null
                )
            )
        }
    }
}

@Composable
private fun ActiveToolInfoCard(
    tool: EditorTool,
    hasVideo: Boolean,
    hasAudio: Boolean,
    activeFilterName: String = "None",
    playbackSpeed: Float = 1.0f,
    clipCount: Int = 0,
    textOverlayCount: Int = 0,
    onAddClipClick: () -> Unit = {},
    onAddTextClick: () -> Unit = {},
    onPickAudioClick: () -> Unit = {},
    onLoadSampleAudioClick: () -> Unit = {},
    onOpenStickerClick: () -> Unit = {},
    onOpenTtsClick: () -> Unit = {},
    onOpenAutoCaptionsClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val speedLabel = if (playbackSpeed == 1.0f) "1x" else "${playbackSpeed}x"
    val description = when (tool) {
        EditorTool.VIDEO -> if (hasVideo) "Timeline active ($clipCount clips • Speed: $speedLabel). Trim or change speed below." else "Pick multiple video clips to assemble quantum timeline."
        EditorTool.TRANSITIONS -> "30+ Cinematic Transitions: Dissolve, Slides, Zooms, Glitch, and 3D Flips between clips."
        EditorTool.TEXT -> if (textOverlayCount > 0) "$textOverlayCount active overlay(s). Drag overlay to position. Tap + to add more." else "Create holographic cyber titles, subtitles & 20+ kinetic animations."
        EditorTool.STICKERS -> "15+ Cyberpunk Sticker Packs: HUD overlays, neon badges, kanji, emojis & decals."
        EditorTool.MUSIC -> if (hasAudio) "Audio track active. Adjust volume slider above or browse SFX library." else "Add background audio from device, load cyber synth, or tap SFX library."
        EditorTool.EFFECTS -> "VFX Color Grade: $activeFilterName. 50+ real-time shader presets across 6 categories."
        EditorTool.PRO_FX -> "CapCut-Pro VFX Suite: Speed curves, reverse, green screen, PIP, split screen & voice changer."
        EditorTool.AI -> "Google Gemini Neural Engine: AI Text Suggestions, Auto Captions & Smart Filter."
        EditorTool.EXPORT -> "Quantum Render Pipeline: Ready for 8K / 4K ProRes & MP4."
    }

    GlassmorphicCard(
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x2200E5FF)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = tool.icon,
                        contentDescription = null,
                        tint = NeonCyanBright,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "TOOL // ${tool.name}",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp,
                            color = NeonCyan
                        )
                    )
                    Text(
                        text = description,
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Normal,
                            fontSize = 11.sp,
                            color = TextSecondary
                        ),
                        maxLines = 2
                    )
                }
            }

            // Quick contextual action buttons for tools
            if (tool == EditorTool.VIDEO && clipCount > 0) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x2800E5FF))
                        .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .clickable(onClick = onAddClipClick)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("add_more_clips_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Clips",
                            tint = NeonCyanBright,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "CLIP",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = NeonCyanBright
                            )
                        )
                    }
                }
            } else if (tool == EditorTool.TEXT) {
                Spacer(modifier = Modifier.width(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x2800E5FF))
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .clickable(onClick = onAddTextClick)
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("add_more_text_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Text",
                                tint = NeonCyanBright,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "TEXT",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = NeonCyanBright
                                )
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x1800E5FF))
                            .border(1.dp, Color(0x4D00E5FF), RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenTtsClick)
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("open_tts_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "TTS",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = NeonCyan
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x1800E5FF))
                            .border(1.dp, Color(0x4D00E5FF), RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenAutoCaptionsClick)
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("open_captions_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "CAPTIONS",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = NeonCyan
                            )
                        )
                    }
                }
            } else if (tool == EditorTool.STICKERS) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x2800E5FF))
                        .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .clickable(onClick = onOpenStickerClick)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("open_stickers_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add Sticker",
                            tint = NeonCyanBright,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "PACKS",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = NeonCyanBright
                            )
                        )
                    }
                }
            } else if (tool == EditorTool.MUSIC) {
                Spacer(modifier = Modifier.width(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x2800E5FF))
                            .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .clickable(onClick = onPickAudioClick)
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("pick_audio_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (hasAudio) "CHANGE" else "PICK",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                color = NeonCyanBright
                            )
                        )
                    }

                    if (!hasAudio) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x1800E5FF))
                                .border(1.dp, Color(0x4D00E5FF), RoundedCornerShape(10.dp))
                            .clickable(onClick = onLoadSampleAudioClick)
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                            .testTag("load_sample_audio_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "SAMPLE",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    color = NeonCyan
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
