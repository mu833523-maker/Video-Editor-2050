package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberPink
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class CyberTransitionPreset(
    val displayName: String,
    val category: String,
    val iconSymbol: String = "⇄"
) {
    // Basic & Fades (5)
    DISSOLVE("Dissolve", "Basic", "◫"),
    FADE_BLACK("Fade Black", "Basic", "◼"),
    FADE_WHITE("Fade White", "Basic", "◻"),
    CROSS_DISSOLVE("Cross Fade", "Basic", "⋈"),
    DIP_CYAN("Dip to Cyan", "Basic", "◆"),

    // Slides & Pushes (9)
    SLIDE_LEFT("Slide Left", "Slides", "←"),
    SLIDE_RIGHT("Slide Right", "Slides", "→"),
    SLIDE_UP("Slide Up", "Slides", "↑"),
    SLIDE_DOWN("Slide Down", "Slides", "↓"),
    PUSH_LEFT("Push Left", "Slides", "⇤"),
    PUSH_RIGHT("Push Right", "Slides", "⇥"),
    COVER_IN("Cover In", "Slides", "▶"),
    REVEAL_OUT("Reveal Out", "Slides", "◀"),
    SPLIT_PUSH("Split Push", "Slides", "╫"),

    // Zooms & Warps (8)
    ZOOM_IN("Zoom In", "Zooms", "⊕"),
    ZOOM_OUT("Zoom Out", "Zooms", "⊖"),
    SPIN_ZOOM("Spin Zoom", "Zooms", "↻"),
    OPTICAL_ZOOM("Optical Warp", "Zooms", "◎"),
    WARP_IN("Warp In", "Zooms", "⟁"),
    VORTEX_TWIST("Vortex Twist", "Zooms", "🌀"),
    SWIRL_360("Swirl 360", "Zooms", "💫"),
    KINETIC_BOUNCE("Kinetic Pop", "Zooms", "⚡"),

    // Glitch & Cyber (7)
    RGB_GLITCH("RGB Split", "Glitch", "⚡"),
    VHS_TEAR("VHS Tear", "Glitch", "📼"),
    HOLOGRAM_FLASH("Holo Flash", "Glitch", "✨"),
    DIGITAL_NOISE("Digital Noise", "Glitch", "░"),
    CYBER_PULSE("Cyber Pulse", "Glitch", "♒"),
    PIXELATE("Pixelate", "Glitch", "▦"),
    DATA_BEND("Data Bend", "Glitch", "§"),

    // 3D & Flips (6)
    CUBE_LEFT("3D Cube L", "3D Flips", "▣"),
    CUBE_RIGHT("3D Cube R", "3D Flips", "▤"),
    FLIP_HORIZONTAL("3D Flip H", "3D Flips", "◨"),
    FLIP_VERTICAL("3D Flip V", "3D Flips", "◪"),
    DOORWAY_3D("Doorway 3D", "3D Flips", "🚪"),
    PAGE_CURL("Page Curl", "3D Flips", "📄")
}

val transitionCategories = listOf("All", "Basic", "Slides", "Zooms", "Glitch", "3D Flips")

@Composable
fun CyberTransitionsBar(
    selectedTransition: CyberTransitionPreset,
    transitionDurationSec: Float,
    onTransitionSelected: (CyberTransitionPreset) -> Unit,
    onDurationChanged: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val barShape = RoundedCornerShape(24.dp)
    val haptic = LocalHapticFeedback.current
    var activeCategory by remember { mutableStateOf("All") }

    val filteredTransitions = remember(activeCategory) {
        if (activeCategory == "All") {
            CyberTransitionPreset.values().toList()
        } else {
            CyberTransitionPreset.values().filter { it.category == activeCategory }
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(barShape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x2800E5FF),
                        Color(0x1A09141F),
                        Color(0x33000000)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.5f),
                        Color.White.copy(alpha = 0.15f),
                        NeonCyan.copy(alpha = 0.4f)
                    )
                ),
                shape = barShape
            )
            .padding(vertical = 10.dp, horizontal = 12.dp)
            .testTag("cyber_transitions_bar")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 4.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.CompareArrows,
                        contentDescription = "Transitions",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "35+ CINEMATIC TRANSITIONS",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                // Selected Transition Chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x2800E5FF))
                        .border(0.8.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = selectedTransition.displayName.uppercase(),
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.5.sp,
                            color = NeonCyanBright
                        )
                    )
                }
            }

            // Duration Slider Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.HourglassTop,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "DURATION: ${String.format("%.1f", transitionDurationSec)}s",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.5.sp,
                        color = NeonCyan
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Slider(
                    value = transitionDurationSec,
                    onValueChange = onDurationChanged,
                    valueRange = 0.2f..2.0f,
                    steps = 8,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyanBright,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = Color(0x3300E5FF)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(24.dp)
                )
            }

            // Category Chips Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                transitionCategories.forEach { cat ->
                    val isCatActive = cat == activeCategory
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isCatActive) Color(0x3300E5FF) else Color(0x0F00E5FF))
                            .border(
                                width = if (isCatActive) 1.dp else 0.6.dp,
                                color = if (isCatActive) NeonCyanBright else Color(0x2200E5FF),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                activeCategory = cat
                            }
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = cat,
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = if (isCatActive) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 10.sp,
                                color = if (isCatActive) NeonCyanBright else TextSecondary
                            )
                        )
                    }
                }
            }

            // Transitions Horizontal List
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                filteredTransitions.forEach { preset ->
                    val isSelected = preset == selectedTransition
                    TransitionItemCard(
                        preset = preset,
                        isSelected = isSelected,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onTransitionSelected(preset)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun TransitionItemCard(
    preset: CyberTransitionPreset,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val animVal = remember { Animatable(0f) }

    LaunchedEffect(isSelected) {
        if (isSelected) {
            animVal.animateTo(
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )
        } else {
            animVal.snapTo(0f)
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(color = NeonCyan),
                onClick = onClick
            )
            .padding(vertical = 2.dp)
            .testTag("transition_${preset.name.lowercase()}")
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                    if (isSelected) {
                        Brush.verticalGradient(
                            listOf(Color(0x4D00E5FF), Color(0x2200E5FF))
                        )
                    } else {
                        Brush.verticalGradient(
                            listOf(Color(0x1800E5FF), Color(0x0A00E5FF))
                        )
                    }
                )
                .border(
                    width = if (isSelected) 1.5.dp else 0.8.dp,
                    color = if (isSelected) NeonCyanBright else Color(0x3300E5FF),
                    shape = RoundedCornerShape(12.dp)
                )
                .graphicsLayer {
                    if (isSelected && (preset.category == "3D Flips" || preset.category == "Zooms")) {
                        rotationZ = animVal.value * 15f
                        scaleX = 1f + animVal.value * 0.08f
                        scaleY = 1f + animVal.value * 0.08f
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = preset.iconSymbol,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = if (isSelected) NeonCyanBright else TextSecondary
                )
            )

            if (isSelected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp)
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(NeonCyanBright),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(9.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = preset.displayName,
            style = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 9.sp,
                color = if (isSelected) NeonCyanBright else TextSecondary
            ),
            maxLines = 1
        )
    }
}
