package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPink
import com.example.ui.theme.DarkCosmic
import com.example.ui.theme.DarkCosmicElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.UUID

data class TextOverlayItem(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val color: Color,
    val fontSizeSp: Float,
    val animationStyle: TextAnimationStyle = TextAnimationStyle.STATIC,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f
)

// Preset Cyberpunk Colors: Cyan, Pink, Yellow, White, Green
val CyberTextColors = listOf(
    Color(0xFF00E5FF) to "Cyan",
    Color(0xFFFF007F) to "Pink",
    Color(0xFFFFE600) to "Yellow",
    Color(0xFFFFFFFF) to "White",
    Color(0xFF00FF9D) to "Green"
)

@Composable
fun CyberAddTextDialog(
    onDismiss: () -> Unit,
    onAddText: (text: String, color: Color, fontSize: Float, animationStyle: TextAnimationStyle) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    var textInput by remember { mutableStateOf("") }
    var selectedColor by remember { mutableStateOf(CyberTextColors[0].first) }
    var fontSizeSp by remember { mutableFloatStateOf(24f) }
    var selectedAnimation by remember { mutableStateOf(TextAnimationStyle.STATIC) }

    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { isVisible = true }

    val animScale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0.9f,
        animationSpec = tween(250, easing = FastOutSlowInEasing),
        label = "add_text_scale"
    )
    val animAlpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(250, easing = FastOutSlowInEasing),
        label = "add_text_alpha"
    )

    val dialogShape = RoundedCornerShape(24.dp)

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = animScale
                scaleY = animScale
                alpha = animAlpha
            }
            .clip(dialogShape)
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    listOf(NeonCyanBright, NeonCyan, Color(0xFF009CB0), NeonCyanBright)
                ),
                shape = dialogShape
            )
            .testTag("cyber_add_text_dialog"),
        containerColor = DarkCosmic,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x3300E5FF)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.TextFields,
                        contentDescription = null,
                        tint = NeonCyanBright,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "ADD TEXT OVERLAY",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            letterSpacing = 1.sp,
                            color = Color(0xFFE8E8E8)
                        )
                    )
                    Text(
                        text = "CYBERNETIC TITLE GENERATOR",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.5.sp,
                            color = NeonCyan
                        )
                    )
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Text Field Input
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = {
                        Text(
                            text = "Enter text overlay...",
                            color = TextMuted,
                            style = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("text_overlay_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = Color(0x6600E5FF),
                        focusedContainerColor = DarkCosmicElevated,
                        unfocusedContainerColor = DarkCosmicElevated,
                        cursorColor = NeonCyan
                    ),
                    singleLine = true,
                    textStyle = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Color Picker Row: Cyan, Pink, Yellow, White, Green
                Text(
                    text = "TEXT COLOR",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp,
                        color = NeonCyan
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CyberTextColors.forEach { (color, name) ->
                        val isSelected = color == selectedColor
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) Color.White else Color(0x66000000),
                                    shape = CircleShape
                                )
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    selectedColor = color
                                }
                                .testTag("color_picker_${name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = name,
                                    tint = if (color == Color.White || color == Color(0xFFFFE600)) Color.Black else Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Font Size Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "FONT SIZE",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp,
                            color = NeonCyan
                        )
                    )
                    Text(
                        text = "${fontSizeSp.toInt()} SP",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = NeonCyanBright
                        )
                    )
                }

                Slider(
                    value = fontSizeSp,
                    onValueChange = { fontSizeSp = it },
                    valueRange = 14f..44f,
                    steps = 15,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyanBright,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = Color(0x3300E5FF)
                    ),
                    modifier = Modifier.testTag("font_size_slider")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Text Animation Style Selector
                TextAnimationStyleSelectorBar(
                    selectedStyle = selectedAnimation,
                    onStyleSelected = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        selectedAnimation = it
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Live Preview Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF03070A))
                        .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedTextOverlayWrapper(animationStyle = selectedAnimation) {
                        Text(
                            text = if (textInput.isBlank()) "PREVIEW TEXT" else textInput,
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Black,
                                fontSize = (fontSizeSp * 0.75f).sp,
                                color = selectedColor,
                                shadow = Shadow(
                                    color = selectedColor,
                                    blurRadius = 14f,
                                    offset = Offset.Zero
                                ),
                                textAlign = TextAlign.Center
                            ),
                            maxLines = 1
                        )
                    }
                }
            }
        },
        confirmButton = {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            listOf(NeonCyanBright, NeonCyan, Color(0xFF009CB0))
                        )
                    )
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        val text = if (textInput.isBlank()) "CYBER 2050" else textInput
                        onAddText(text, selectedColor, fontSizeSp, selectedAnimation)
                        onDismiss()
                    }
                    .padding(horizontal = 20.dp, vertical = 10.dp)
                    .testTag("add_text_confirm_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "ADD",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp,
                        letterSpacing = 1.2.sp,
                        color = Color(0xFF041219)
                    )
                )
            }
        },
        dismissButton = {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x1F00E5FF))
                    .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(12.dp))
                    .clickable {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onDismiss()
                    }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("add_text_cancel_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "CANCEL",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                )
            }
        }
    )
}
