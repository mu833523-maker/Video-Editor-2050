package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

val SpeedOptions = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f)
val SpeedLabels = listOf("0.5x", "0.75x", "1x", "1.25x", "1.5x", "2x", "3x")

/**
 * Cyberpunk 2050 Speed Control Component
 * Shows speed options: 0.5x, 0.75x, 1x, 1.25x, 1.5x, 2x, 3x
 * Highlighted with neon cyan, 24dp rounded corners, and slider/pill selector.
 */
@Composable
fun CyberSpeedControl(
    currentSpeed: Float,
    onSpeedSelected: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val containerShape = RoundedCornerShape(24.dp)
    val scrollState = rememberScrollState()
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(containerShape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x2000E5FF),
                        Color(0x10081018),
                        Color(0x28000000)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.45f),
                        Color.White.copy(alpha = 0.10f),
                        NeonCyan.copy(alpha = 0.35f)
                    )
                ),
                shape = containerShape
            )
            .padding(16.dp)
            .testTag("cyber_speed_control")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row: Title & Active Speed Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x2600E5FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = "Speed Control",
                            tint = NeonCyanBright,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PLAYBACK SPEED",
                        style = TextStyle(
                            fontFamily = FontFamily.SansSerif,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                }

                // Current speed badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x3300E5FF))
                        .border(1.dp, NeonCyan, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 3.dp)
                ) {
                    val label = when (currentSpeed) {
                        0.5f -> "0.5x"
                        0.75f -> "0.75x"
                        1.0f -> "1x"
                        1.25f -> "1.25x"
                        1.5f -> "1.5x"
                        2.0f -> "2x"
                        3.0f -> "3x"
                        else -> "${currentSpeed}x"
                    }
                    Text(
                        text = label,
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = NeonCyanBright
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Speed Options Horizontal Segmented Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SpeedOptions.forEachIndexed { index, speed ->
                    val isSelected = kotlin.math.abs(speed - currentSpeed) < 0.05f
                    val pillShape = RoundedCornerShape(12.dp)
                    Box(
                        modifier = Modifier
                            .clip(pillShape)
                            .then(
                                if (isSelected) {
                                    Modifier
                                        .background(
                                            brush = Brush.horizontalGradient(
                                                listOf(NeonCyanBright, NeonCyan)
                                            )
                                        )
                                        .shadow(
                                            elevation = 8.dp,
                                            shape = pillShape,
                                            ambientColor = NeonCyan,
                                            spotColor = NeonCyan
                                        )
                                } else {
                                    Modifier
                                        .background(Color(0x1800E5FF))
                                        .border(1.dp, Color(0x3300E5FF), pillShape)
                                }
                            )
                            .clickable(
                                interactionSource = androidx.compose.runtime.remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                                indication = androidx.compose.material3.ripple(color = NeonCyan)
                            ) {
                                haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                onSpeedSelected(speed)
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                            .testTag("speed_option_${SpeedLabels[index]}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = SpeedLabels[index],
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                fontSize = 12.sp,
                                color = if (isSelected) Color(0xFF041219) else TextSecondary
                            )
                        )
                    }
                }
            }
        }
    }
}
