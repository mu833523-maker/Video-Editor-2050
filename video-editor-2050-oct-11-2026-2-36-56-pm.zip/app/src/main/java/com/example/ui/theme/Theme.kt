package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val CyberpunkDarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = Color(0xFF041017),
    primaryContainer = NeonCyanDark,
    onPrimaryContainer = NeonCyanBright,
    secondary = CyberViolet,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF261044),
    onSecondaryContainer = Color(0xFFE1BEE7),
    tertiary = CyberPink,
    onTertiary = Color.White,
    background = DarkCosmic,
    onBackground = TextPrimary,
    surface = DarkCosmicElevated,
    onSurface = TextPrimary,
    surfaceVariant = DarkCosmicSurface,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder
)

@Composable
fun VideoEditorTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = DarkCosmic.toArgb()
                window.navigationBarColor = DarkCosmic.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = CyberpunkDarkColorScheme,
        typography = Typography,
        content = content
    )
}
