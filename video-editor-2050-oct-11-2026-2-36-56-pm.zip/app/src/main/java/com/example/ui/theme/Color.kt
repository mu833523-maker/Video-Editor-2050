package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deeper, elegant Cyberpunk 2050 Palette (Deet cosmic #050505)
val DarkCosmic = Color(0xFF050505)
val DarkCosmicElevated = Color(0xFF0B0D12)
val DarkCosmicSurface = Color(0xFF10131A)
val DarkCosmicCard = Color(0xFF0E1218)

// Neon Accents - Refined & Soft Ambient
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanBright = Color(0xFF4EE8FF)
val NeonCyanDark = Color(0xFF008394)
val NeonCyanGlow = Color(0x3300E5FF)
val NeonCyanSubtle = Color(0x1400E5FF)

val CyberViolet = Color(0xFF7B2CBF)
val CyberPink = Color(0xFFF72585)
val CyberGreen = Color(0xFF06D6A0)

// Glassmorphism tokens
val GlassBackground = Color(0x1400E5FF)
val GlassBackgroundCard = Color(0x0F15222E)
val GlassBorder = Color(0x4000E5FF)
val GlassBorderSubtle = Color(0x1F00E5FF)

// Text tokens - Soft white #E8E8E8 everywhere per premium polish
val TextPrimary = Color(0xFFE8E8E8)
val TextSecondary = Color(0xFF88C9D4)
val TextMuted = Color(0xFF5A7280)
