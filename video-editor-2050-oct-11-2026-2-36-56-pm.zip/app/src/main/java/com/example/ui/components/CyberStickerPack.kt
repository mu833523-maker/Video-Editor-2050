package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberPink
import com.example.ui.theme.CyberViolet
import com.example.ui.theme.DarkCosmicCard
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.UUID
import kotlin.math.roundToInt

data class StickerDefinition(
    val id: String,
    val packName: String,
    val displayIcon: String,
    val label: String,
    val color: Color
)

data class PlacedStickerItem(
    val id: String = UUID.randomUUID().toString(),
    val sticker: StickerDefinition,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scale: Float = 1.0f
)

val stickerPacksList = listOf(
    // 1. Cyber HUD
    "Cyber HUD" to listOf(
        StickerDefinition("hud_1", "Cyber HUD", "⊕", "TARGET LOCK", NeonCyanBright),
        StickerDefinition("hud_2", "Cyber HUD", "◎", "RADAR SCOPE", NeonCyan),
        StickerDefinition("hud_3", "Cyber HUD", "⌖", "CROSSHAIR", CyberPink),
        StickerDefinition("hud_4", "Cyber HUD", "◫", "TELEMETRY", NeonCyanBright),
        StickerDefinition("hud_5", "Cyber HUD", "◬", "SECTOR SCAN", CyberGreen)
    ),
    // 2. Neon Shapes
    "Neon Shapes" to listOf(
        StickerDefinition("neon_1", "Neon Shapes", "♥", "NEON HEART", CyberPink),
        StickerDefinition("neon_2", "Neon Shapes", "★", "CYBER STAR", Color(0xFFFFD700)),
        StickerDefinition("neon_3", "Neon Shapes", "⚡", "LIGHTNING", NeonCyanBright),
        StickerDefinition("neon_4", "Neon Shapes", "👑", "NEON CROWN", Color(0xFFFFC107)),
        StickerDefinition("neon_5", "Neon Shapes", "💎", "DIAMOND", NeonCyan)
    ),
    // 3. Hologram Emojis
    "Hologram Emojis" to listOf(
        StickerDefinition("holo_1", "Hologram Emojis", "💀", "CYBER SKULL", NeonCyan),
        StickerDefinition("holo_2", "Hologram Emojis", "🔥", "FLAME SURGE", Color(0xFFFF5722)),
        StickerDefinition("holo_3", "Hologram Emojis", "🕶", "CYBER SHADES", NeonCyanBright),
        StickerDefinition("holo_4", "Hologram Emojis", "🤖", "CYBORG BOT", Color(0xFF00E676)),
        StickerDefinition("holo_5", "Hologram Emojis", "👽", "NEON ALIEN", Color(0xFF76FF03))
    ),
    // 4. Tech & Circuit
    "Tech & Circuit" to listOf(
        StickerDefinition("tech_1", "Tech & Circuit", "☊", "QUANTUM CHIP", NeonCyan),
        StickerDefinition("tech_2", "Tech & Circuit", "║▌", "BARCODE", Color.White),
        StickerDefinition("tech_3", "Tech & Circuit", "📶", "QUANTUM NET", NeonCyanBright),
        StickerDefinition("tech_4", "Tech & Circuit", "🔋", "99% NEURAL", CyberGreen),
        StickerDefinition("tech_5", "Tech & Circuit", "⌬", "NANITE CORE", CyberViolet)
    ),
    // 5. Cyber Kanji
    "Cyber Kanji" to listOf(
        StickerDefinition("kanji_1", "Cyber Kanji", "未来", "FUTURE", NeonCyanBright),
        StickerDefinition("kanji_2", "Cyber Kanji", "電脳", "CYBERNETIC", CyberPink),
        StickerDefinition("kanji_3", "Cyber Kanji", "速度", "VELOCITY", Color(0xFFFFD700)),
        StickerDefinition("kanji_4", "Cyber Kanji", "覚醒", "AWAKEN", CyberGreen),
        StickerDefinition("kanji_5", "Cyber Kanji", "伝説", "LEGEND", NeonCyan)
    ),
    // 6. Glitch Decals
    "Glitch Decals" to listOf(
        StickerDefinition("glitch_1", "Glitch Decals", "⚠", "ERROR 404", Color(0xFFFF1744)),
        StickerDefinition("glitch_2", "Glitch Decals", "⛔", "OVERRIDE", Color(0xFFFF5252)),
        StickerDefinition("glitch_3", "Glitch Decals", "✔", "ACCESS GRANTED", CyberGreen),
        StickerDefinition("glitch_4", "Glitch Decals", "⟳", "REBOOTING", NeonCyan),
        StickerDefinition("glitch_5", "Glitch Decals", "☣", "BIO HAZARD", Color(0xFFFFEA00))
    ),
    // 7. Retrowave 80s
    "Retrowave 80s" to listOf(
        StickerDefinition("retro_1", "Retrowave 80s", "☀", "SYNTH SUN", Color(0xFFFF4081)),
        StickerDefinition("retro_2", "Retrowave 80s", "🌴", "PALM SILHOUETTE", CyberPink),
        StickerDefinition("retro_3", "Retrowave 80s", "📼", "VHS 1984", Color(0xFF00E5FF)),
        StickerDefinition("retro_4", "Retrowave 80s", "▲", "OUTRUN TRI", Color(0xFFE040FB)),
        StickerDefinition("retro_5", "Retrowave 80s", "🌅", "GRID HORIZON", Color(0xFFFF9100))
    ),
    // 8. Creator Badges
    "Creator Badges" to listOf(
        StickerDefinition("badge_1", "Creator Badges", "4K", "4K ULTRA HDR", Color(0xFFFFD700)),
        StickerDefinition("badge_2", "Creator Badges", "60", "60 FPS PRO", NeonCyanBright),
        StickerDefinition("badge_3", "Creator Badges", "🔴", "REC LIVE", Color(0xFFFF1744)),
        StickerDefinition("badge_4", "Creator Badges", "SUB", "SUBSCRIBE", Color(0xFFFF0055)),
        StickerDefinition("badge_5", "Creator Badges", "HDR", "QUANTUM HDR", CyberGreen)
    ),
    // 9. Cyber Pointers
    "Cyber Pointers" to listOf(
        StickerDefinition("point_1", "Cyber Pointers", "➤", "LASER CHEVRON", NeonCyan),
        StickerDefinition("point_2", "Cyber Pointers", "➔", "NEON ARROW", CyberPink),
        StickerDefinition("point_3", "Cyber Pointers", "▲", "INDICATOR", CyberGreen),
        StickerDefinition("point_4", "Cyber Pointers", "»", "FAST TRACK", NeonCyanBright),
        StickerDefinition("point_5", "Cyber Pointers", "↯", "ENERGY DIRECT", Color(0xFFFFD700))
    ),
    // 10. Esports Gaming
    "Esports Gaming" to listOf(
        StickerDefinition("game_1", "Esports Gaming", "👑", "VICTORY", Color(0xFFFFD700)),
        StickerDefinition("game_2", "Esports Gaming", "💥", "CRITICAL HIT", Color(0xFFFF3D00)),
        StickerDefinition("game_3", "Esports Gaming", "GG", "GG WELL PLAYED", NeonCyanBright),
        StickerDefinition("game_4", "Esports Gaming", "▲", "LEVEL UP", CyberGreen),
        StickerDefinition("game_5", "Esports Gaming", "⚔", "BOSS FIGHT", CyberPink)
    ),
    // 11. Audio Waveforms
    "Audio Waveforms" to listOf(
        StickerDefinition("wave_1", "Audio Waveforms", "ılılı", "BASS SPECTRUM", NeonCyan),
        StickerDefinition("wave_2", "Audio Waveforms", "♫", "NEON SYNTH", CyberPink),
        StickerDefinition("wave_3", "Audio Waveforms", "🔊", "MAX GAIN", Color(0xFFFF9100)),
        StickerDefinition("wave_4", "Audio Waveforms", "128", "128 BPM", CyberGreen),
        StickerDefinition("wave_5", "Audio Waveforms", "〰", "SUB-BASS", NeonCyanBright)
    ),
    // 12. Framing Brackets
    "Framing Brackets" to listOf(
        StickerDefinition("frame_1", "Framing Brackets", "⌜ ⌝", "CYBER CORNERS", NeonCyan),
        StickerDefinition("frame_2", "Framing Brackets", "⌞ ⌟", "LOWER CORNERS", NeonCyanBright),
        StickerDefinition("frame_3", "Framing Brackets", "〔 〕", "NEURAL BRACKET", CyberPink),
        StickerDefinition("frame_4", "Framing Brackets", "⟨ ⟩", "HOLO BRACKET", CyberGreen),
        StickerDefinition("frame_5", "Framing Brackets", "⟦ ⟧", "QUANTUM FRAME", Color(0xFFFFD700))
    ),
    // 13. Speed & Nitro
    "Speed & Nitro" to listOf(
        StickerDefinition("speed_1", "Speed & Nitro", "🚀", "WARP BOOST", Color(0xFFFF5252)),
        StickerDefinition("speed_2", "Speed & Nitro", "💨", "NITRO BURN", NeonCyanBright),
        StickerDefinition("speed_3", "Speed & Nitro", "MACH", "MACH 3 PRO", Color(0xFFFFD700)),
        StickerDefinition("speed_4", "Speed & Nitro", "100%", "FULL BOOST", CyberGreen),
        StickerDefinition("speed_5", "Speed & Nitro", "⚡", "OVERCLOCK", CyberPink)
    ),
    // 14. Cyber Beasts
    "Cyber Beasts" to listOf(
        StickerDefinition("beast_1", "Cyber Beasts", "🐺", "CYBER WOLF", NeonCyan),
        StickerDefinition("beast_2", "Cyber Beasts", "🐉", "NEON DRAGON", CyberGreen),
        StickerDefinition("beast_3", "Cyber Beasts", "🐱", "PIXEL NEKO", CyberPink),
        StickerDefinition("beast_4", "Cyber Beasts", "🦅", "ROBOT FALCON", Color(0xFFFFD700)),
        StickerDefinition("beast_5", "Cyber Beasts", "🦊", "CYBER FOX", Color(0xFFFF6D00))
    ),
    // 15. Energy & Particles
    "Energy & Particles" to listOf(
        StickerDefinition("eng_1", "Energy & Particles", "⚛", "QUANTUM ATOM", NeonCyanBright),
        StickerDefinition("eng_2", "Energy & Particles", "✦", "PLASMA SPARK", Color(0xFFFF4081)),
        StickerDefinition("eng_3", "Energy & Particles", "✹", "SOLAR BURST", Color(0xFFFFAB00)),
        StickerDefinition("eng_4", "Energy & Particles", "🌀", "VORTEX BEAM", CyberViolet),
        StickerDefinition("eng_5", "Energy & Particles", "❄", "CRYOCELL", Color(0xFF00E5FF))
    )
)

@Composable
fun CyberStickerPickerDialog(
    onDismiss: () -> Unit,
    onStickerPicked: (StickerDefinition) -> Unit
) {
    var selectedPackName by remember { mutableStateOf(stickerPacksList.first().first) }
    val currentPackItems = remember(selectedPackName) {
        stickerPacksList.firstOrNull { it.first == selectedPackName }?.second ?: emptyList()
    }
    val haptic = LocalHapticFeedback.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(24.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF0D131B), Color(0xFF05070A))
                    )
                )
                .border(1.2.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .padding(18.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocalOffer,
                            contentDescription = null,
                            tint = NeonCyanBright,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "15+ CYBER STICKER PACKS",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                letterSpacing = 1.sp,
                                color = TextPrimary
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0x2200E5FF))
                            .clickable(onClick = onDismiss),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Pack Tabs Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    stickerPacksList.forEach { (packName, _) ->
                        val isSelected = packName == selectedPackName
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0x3300E5FF) else Color(0x0F00E5FF))
                                .border(
                                    width = if (isSelected) 1.dp else 0.6.dp,
                                    color = if (isSelected) NeonCyanBright else Color(0x2200E5FF),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    selectedPackName = packName
                                }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = packName,
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 11.sp,
                                    color = if (isSelected) NeonCyanBright else TextSecondary
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Stickers Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(currentPackItems) { sticker ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x1800E5FF))
                                .border(1.dp, sticker.color.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onStickerPicked(sticker)
                                    onDismiss()
                                }
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = sticker.displayIcon,
                                    style = TextStyle(
                                        fontSize = 28.sp,
                                        color = sticker.color,
                                        shadow = Shadow(
                                            color = sticker.color.copy(alpha = 0.6f),
                                            blurRadius = 14f,
                                            offset = Offset.Zero
                                        )
                                    )
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = sticker.label,
                                    style = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp,
                                        color = TextPrimary
                                    ),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DraggableStickerOverlayView(
    item: PlacedStickerItem,
    onDrag: (dx: Float, dy: Float) -> Unit,
    onDelete: () -> Unit
) {
    Box(
        modifier = Modifier
            .offset { IntOffset(item.offsetX.roundToInt(), item.offsetY.roundToInt()) }
            .pointerInput(item.id) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            }
            .padding(4.dp)
            .testTag("sticker_overlay_${item.id}"),
        contentAlignment = Alignment.TopEnd
    ) {
        Box(
            modifier = Modifier
                .padding(top = 8.dp, end = 8.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0x99000000))
                .border(1.dp, item.sticker.color.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = item.sticker.displayIcon,
                    style = TextStyle(
                        fontSize = 32.sp,
                        color = item.sticker.color,
                        shadow = Shadow(
                            color = item.sticker.color.copy(alpha = 0.7f),
                            blurRadius = 16f,
                            offset = Offset.Zero
                        )
                    )
                )
                Text(
                    text = item.sticker.label,
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                )
            }
        }

        // Delete 'X' Badge
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(Color(0xFFDD1144))
                .border(1.dp, Color.White, CircleShape)
                .clickable(onClick = onDelete),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Delete",
                tint = Color.White,
                modifier = Modifier.size(13.dp)
            )
        }
    }
}
