package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.FilterDrama
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.BuildConfig
import com.example.ui.theme.DarkCosmic
import com.example.ui.theme.DarkCosmicElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// Free API key from aistudio.google.com
private const val GEMINI_API_KEY = "YOUR_KEY_HERE"

/**
 * Call Google Gemini REST API (model: gemini-1.5-flash) using OkHttp to generate 3 cyberpunk text suggestions.
 */
suspend fun generateCyberpunkTextSuggestions(topic: String): List<String> = withContext(Dispatchers.IO) {
    val configuredKey = try {
        BuildConfig.GEMINI_API_KEY
    } catch (e: Exception) {
        ""
    }
    val effectiveKey = if (configuredKey.isNotEmpty() && configuredKey != "MY_GEMINI_API_KEY") {
        configuredKey
    } else {
        GEMINI_API_KEY
    }

    if (effectiveKey == "YOUR_KEY_HERE" || effectiveKey.isBlank() || effectiveKey == "MY_GEMINI_API_KEY") {
        return@withContext getFallbackCyberSuggestions(topic)
    }

    val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    val prompt = "Generate exactly 3 short, punchy cyberpunk-style video titles or captions about '${topic.trim()}'. " +
            "Each must be 2 to 5 words, uppercase, futuristic, sleek. " +
            "Return only the 3 lines, with no numbering, bullets, or extra text."

    val jsonBody = JSONObject().apply {
        put("contents", JSONArray().apply {
            put(JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply {
                        put("text", prompt)
                    })
                })
            })
        })
    }

    val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
    val candidateModels = listOf("gemini-1.5-flash", "gemini-2.5-flash")

    for (modelName in candidateModels) {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$effectiveKey"
        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val responseString = response.body?.string() ?: ""
                    val root = JSONObject(responseString)
                    val text = root.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")

                    val lines = text.lines()
                        .map { it.trim().removePrefix("-").removePrefix("*").trim() }
                        .filter { it.isNotBlank() }
                        .take(3)

                    if (lines.isNotEmpty()) {
                        return@withContext lines
                    }
                }
            }
        } catch (e: Exception) {
            // Try next model if available
        }
    }

    return@withContext getFallbackCyberSuggestions(topic)
}

private fun getFallbackCyberSuggestions(topic: String): List<String> {
    val clean = if (topic.isBlank()) "CYBERPUNK" else topic.trim().uppercase()
    return listOf(
        "$clean // MATRIX OVERDRIVE",
        "NEURAL STREAM: $clean 2050",
        "QUANTUM PROTOCOL // $clean"
    )
}

/**
 * Loading Spinner: Rotating Neon Cyan Ring (Buttery smooth 60fps)
 */
@Composable
fun CyberRotatingRingSpinner(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ring_spin")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_angle"
    )

    Canvas(modifier = modifier.size(36.dp)) {
        val strokePx = 3.dp.toPx()
        // Base subtle background track
        drawCircle(
            color = Color(0x2200E5FF),
            style = Stroke(width = strokePx)
        )
        // Rotating sweep gradient arc
        drawArc(
            brush = Brush.sweepGradient(
                listOf(
                    Color.Transparent,
                    NeonCyan.copy(alpha = 0.35f),
                    NeonCyanBright
                )
            ),
            startAngle = angle,
            sweepAngle = 260f,
            useCenter = false,
            style = Stroke(width = strokePx, cap = StrokeCap.Round)
        )
    }
}

/**
 * Unified AI Dialog (PART 1 & PART 2)
 * Features:
 * - TextField "Enter topic"
 * - Button "Generate 3 Suggestions"
 * - Rotating neon cyan ring spinner
 * - 3 Clickable chips (tap chip -> adds as text overlay)
 * - Also includes "AI Auto Caption (Coming Soon)" and "AI Smart Filter" buttons in same dialog
 * - Smooth scale from 0.9 to 1.0 with 250ms easeInOut fade
 * - Haptic feedback on all interactions
 */
@Composable
fun CyberUnifiedAiDialog(
    onDismiss: () -> Unit,
    onSelectSuggestion: (String) -> Unit,
    onAutoCaptionClick: () -> Unit,
    onSmartFilterClick: () -> Unit
) {
    val dialogShape = RoundedCornerShape(24.dp)
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current

    var topicInput by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var suggestions by remember { mutableStateOf<List<String>>(emptyList()) }

    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { isVisible = true }

    val animScale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0.9f,
        animationSpec = tween(250, easing = FastOutSlowInEasing),
        label = "dialog_scale"
    )
    val animAlpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(250, easing = FastOutSlowInEasing),
        label = "dialog_alpha"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = animScale
                scaleY = animScale
                alpha = animAlpha
            }
            .clip(dialogShape)
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    listOf(
                        NeonCyan.copy(alpha = 0.7f),
                        Color.White.copy(alpha = 0.2f),
                        NeonCyan.copy(alpha = 0.5f)
                    )
                ),
                shape = dialogShape
            )
            .testTag("ai_unified_dialog"),
        containerColor = DarkCosmic,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x3300E5FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Features",
                            tint = NeonCyanBright,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "AI FEATURES",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                letterSpacing = 1.sp,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "GOOGLE GEMINI 1.5 FLASH",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.5.sp,
                                color = NeonCyan
                            )
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x2200E5FF))
                        .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "ONLINE",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 8.5.sp,
                            color = NeonCyanBright
                        )
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Secondary AI Buttons Row: "AI Auto Caption (Coming Soon)" & "AI Smart Filter"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // AI Auto Caption (Coming Soon)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x1800E5FF))
                            .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(color = NeonCyan)
                            ) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onAutoCaptionClick()
                            }
                            .padding(vertical = 9.dp, horizontal = 6.dp)
                            .testTag("ai_auto_caption_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.ClosedCaption,
                                contentDescription = null,
                                tint = NeonCyanBright,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "AUTO CAPTIONS",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.5.sp,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Coming Soon",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = TextMuted
                                )
                            )
                        }
                    }

                    // AI Smart Filter
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0x1800E5FF))
                            .border(1.dp, NeonCyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(color = NeonCyan)
                            ) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onSmartFilterClick()
                            }
                            .padding(vertical = 9.dp, horizontal = 6.dp)
                            .testTag("ai_smart_filter_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.FilterDrama,
                                contentDescription = null,
                                tint = NeonCyanBright,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "SMART FILTER",
                                style = TextStyle(
                                    fontFamily = FontFamily.SansSerif,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.5.sp,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Auto Grade Video",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 8.sp,
                                    color = NeonCyan.copy(alpha = 0.8f)
                                )
                            )
                        }
                    }
                }

                // Divider line
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color(0x2200E5FF))
                )

                Text(
                    text = "AI SUGGEST TEXT OVERLAY",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 1.sp,
                        color = NeonCyan
                    )
                )

                // TextField "Enter topic"
                OutlinedTextField(
                    value = topicInput,
                    onValueChange = { topicInput = it },
                    placeholder = {
                        Text(
                            text = "Enter topic (e.g. Cyber City, Tokyo Drift)...",
                            color = TextMuted,
                            style = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 13.sp)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("ai_topic_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = Color(0x5500E5FF),
                        focusedContainerColor = DarkCosmicElevated,
                        unfocusedContainerColor = DarkCosmicElevated,
                        cursorColor = NeonCyan
                    ),
                    singleLine = true,
                    textStyle = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.5.sp
                    )
                )

                // Button "Generate 3 Suggestions"
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            brush = Brush.horizontalGradient(
                                listOf(NeonCyanBright, NeonCyan, Color(0xFF009CB0))
                            )
                        )
                        .clickable(
                            enabled = !isLoading,
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(color = Color.Black)
                        ) {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            isLoading = true
                            scope.launch {
                                suggestions = generateCyberpunkTextSuggestions(
                                    if (topicInput.isBlank()) "CYBER 2050" else topicInput
                                )
                                isLoading = false
                            }
                        }
                        .testTag("ai_generate_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = Color(0xFF041219),
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isLoading) "ANALYZING..." else "GENERATE 3 SUGGESTIONS",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                letterSpacing = 0.8.sp,
                                color = Color(0xFF041219)
                            )
                        )
                    }
                }

                // Loading Spinner: Rotating Neon Cyan Ring
                if (isLoading) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CyberRotatingRingSpinner()
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "CALLING GEMINI NEURAL NET...",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.5.sp,
                                color = NeonCyanBright,
                                letterSpacing = 0.8.sp
                            )
                        )
                    }
                }

                // 3 Clickable Suggestion Chips (Tap chip -> adds as text overlay)
                AnimatedVisibility(
                    visible = !isLoading && suggestions.isNotEmpty(),
                    enter = fadeIn(tween(250, easing = FastOutSlowInEasing)),
                    exit = fadeOut(tween(200, easing = FastOutSlowInEasing))
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "TAP CHIP TO ADD AS OVERLAY:",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.5.sp,
                                letterSpacing = 0.8.sp,
                                color = NeonCyan
                            )
                        )

                        suggestions.forEachIndexed { index, suggestionText ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x1F00E5FF))
                                    .border(1.dp, NeonCyan.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = ripple(color = NeonCyan)
                                    ) {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        onSelectSuggestion(suggestionText)
                                        onDismiss()
                                    }
                                    .padding(horizontal = 12.dp, vertical = 9.dp)
                                    .testTag("ai_suggestion_chip_$index")
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = suggestionText,
                                        style = TextStyle(
                                            fontFamily = FontFamily.SansSerif,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.5.sp,
                                            color = TextPrimary
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )

                                    Spacer(modifier = Modifier.width(6.dp))

                                    Text(
                                        text = "+ ADD",
                                        style = TextStyle(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp,
                                            color = NeonCyanBright
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x1A00E5FF))
                    .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(12.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = NeonCyan)
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onDismiss()
                    }
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .testTag("ai_dialog_close_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "CLOSE",
                    style = TextStyle(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                )
            }
        }
    )
}

/**
 * AI Options Card for the editor scrollable workspace.
 */
@Composable
fun CyberAiOptionsCard(
    onAutoCaptionsClick: () -> Unit,
    onSuggestTextClick: () -> Unit,
    onFilterSuggestionClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cardShape = RoundedCornerShape(24.dp)
    val haptic = LocalHapticFeedback.current

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(cardShape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x2200E5FF),
                        Color(0x12081018),
                        Color(0x28000000)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        NeonCyan.copy(alpha = 0.5f),
                        Color.White.copy(alpha = 0.12f),
                        NeonCyan.copy(alpha = 0.35f)
                    )
                ),
                shape = cardShape
            )
            .padding(16.dp)
            .testTag("cyber_ai_options_card")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x3300E5FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Gemini AI",
                            tint = NeonCyanBright,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "GEMINI AI ENGINE",
                            style = TextStyle(
                                fontFamily = FontFamily.SansSerif,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                letterSpacing = 1.sp,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "NEURAL ASSISTANT // 2050",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.5.sp,
                                color = NeonCyan
                            )
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x2600FF9D))
                        .border(1.dp, Color(0x6600FF9D), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = "ONLINE",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp,
                            color = Color(0xFF00FF9D)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AiActionButton(
                    icon = Icons.Default.TextFields,
                    label = "SUGGEST TEXT",
                    subtext = "Gemini Generator",
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onSuggestTextClick()
                    },
                    modifier = Modifier.weight(1f),
                    testTag = "ai_suggest_text_button"
                )

                AiActionButton(
                    icon = Icons.Default.FilterDrama,
                    label = "AI FILTER",
                    subtext = "Smart Auto-Grade",
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onFilterSuggestionClick()
                    },
                    modifier = Modifier.weight(1f),
                    testTag = "ai_filter_suggestion_button"
                )
            }
        }
    }
}

@Composable
private fun AiActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    subtext: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x1800E5FF))
            .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(14.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(color = NeonCyan),
                onClick = onClick
            )
            .padding(vertical = 10.dp, horizontal = 6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = NeonCyanBright,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = label,
                style = TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = TextPrimary
                ),
                maxLines = 1
            )
            Text(
                text = subtext,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 8.5.sp,
                    color = NeonCyan.copy(alpha = 0.8f)
                ),
                maxLines = 1
            )
        }
    }
}
