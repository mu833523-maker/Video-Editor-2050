package com.example

import com.example.ui.export.ExportResolution
import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 */
class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun exportResolution_dimensionsAreCorrect() {
    assertEquals(1280, ExportResolution.RES_720P.width)
    assertEquals(720, ExportResolution.RES_720P.height)
    assertEquals("720p HD", ExportResolution.RES_720P.label)

    assertEquals(1920, ExportResolution.RES_1080P.width)
    assertEquals(1080, ExportResolution.RES_1080P.height)
    assertEquals("1080p Full HD", ExportResolution.RES_1080P.label)
  }
}
