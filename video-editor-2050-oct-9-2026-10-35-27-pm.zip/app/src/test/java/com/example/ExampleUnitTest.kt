package com.example

import com.ve2050.editor.model.OverlayMask
import com.ve2050.editor.model.TrackType
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun overlayTrackType_isAvailable() {
    val trackType = TrackType.OVERLAY
    assertEquals("Holo Overlay", trackType.label)
    assertEquals("🌌", trackType.icon)
  }

  @Test
  fun overlayMasks_areDefined() {
    val masks = OverlayMask.values()
    assertTrue(masks.contains(OverlayMask.NONE))
    assertTrue(masks.contains(OverlayMask.RECTANGLE))
    assertTrue(masks.contains(OverlayMask.CIRCLE))
    assertTrue(masks.contains(OverlayMask.HEART))
  }
}

