package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.OverlayClip
import com.ve2050.editor.model.OverlayMask
import com.ve2050.editor.model.TrackType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Video Editor 2050", appName)
  }

  @Test
  fun `clip default values are valid in android environment`() {
    val clip = Clip(title = "Main Clip")
    assertEquals("Main Clip", clip.title)
    assertEquals(TrackType.VIDEO, clip.trackType)
    assertEquals(1.0f, clip.speed, 0.001f)
  }

  @Test
  fun `overlay clip default values and properties in android environment`() {
    val overlay = OverlayClip(
      startMs = 1500L,
      durationMs = 4500L,
      scale = 1.25f,
      rotation = 45f,
      opacity = 0.8f,
      mask = OverlayMask.HEART,
      isChromaKeyEnabled = true,
      chromaKeyIntensity = 0.7f
    )
    assertEquals(1500L, overlay.startMs)
    assertEquals(4500L, overlay.durationMs)
    assertEquals(1.25f, overlay.scale, 0.001f)
    assertEquals(45f, overlay.rotation, 0.001f)
    assertEquals(0.8f, overlay.opacity, 0.001f)
    assertEquals(OverlayMask.HEART, overlay.mask)
    assertTrue(overlay.isChromaKeyEnabled)
    assertEquals(0.7f, overlay.chromaKeyIntensity, 0.001f)
  }

  @Test
  fun `split clip produces two valid continuous clips`() {
    val original = Clip(startMs = 0L, endMs = 6000L, durationMs = 6000L, title = "Original")
    val splitPoint = 2500L
    val first = original.copy(
      id = java.util.UUID.randomUUID().toString(),
      endMs = original.startMs + splitPoint,
      durationMs = splitPoint
    )
    val second = original.copy(
      id = java.util.UUID.randomUUID().toString(),
      startMs = original.startMs + splitPoint,
      durationMs = original.durationMs - splitPoint,
      endMs = original.startMs + original.durationMs
    )

    assertEquals(2500L, first.durationMs)
    assertEquals(2500L, first.endMs)
    assertEquals(2500L, second.startMs)
    assertEquals(3500L, second.durationMs)
    assertEquals(6000L, second.endMs)
    assertTrue(first.id != second.id)
  }

  @Test
  fun `trim clip updates start and duration correctly`() {
    val clip = Clip(startMs = 0L, endMs = 8000L, durationMs = 8000L)
    val newStart = 1000L
    val newEnd = 6000L
    val dur = (newEnd - newStart).coerceAtLeast(800L)
    val trimmed = clip.copy(startMs = newStart, endMs = newStart + dur, durationMs = dur)

    assertEquals(1000L, trimmed.startMs)
    assertEquals(6000L, trimmed.endMs)
    assertEquals(5000L, trimmed.durationMs)
  }

  @Test
  fun `duplicate clip creates clone with unique identifier`() {
    val clip = Clip(startMs = 500L, endMs = 4500L, durationMs = 4000L, title = "CyberIntro")
    val duplicate = clip.copy(id = java.util.UUID.randomUUID().toString())

    assertEquals(clip.durationMs, duplicate.durationMs)
    assertEquals(clip.startMs, duplicate.startMs)
    assertEquals(clip.endMs, duplicate.endMs)
    assertEquals("CyberIntro", duplicate.title)
    assertTrue(clip.id != duplicate.id)
  }

  @Test
  fun `delete clip removes correct index and updates size`() {
    val clips = mutableListOf(
      Clip(title = "C1"),
      Clip(title = "C2"),
      Clip(title = "C3")
    )
    val toDeleteIndex = 1
    clips.removeAt(toDeleteIndex)
    assertEquals(2, clips.size)
    assertEquals("C1", clips[0].title)
    assertEquals("C3", clips[1].title)
  }
}

