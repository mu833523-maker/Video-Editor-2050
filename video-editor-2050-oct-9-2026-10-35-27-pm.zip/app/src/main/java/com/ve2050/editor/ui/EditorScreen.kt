package com.ve2050.editor.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.ve2050.editor.engine.ExportEngine
import com.ve2050.editor.engine.ExportQuality
import com.ve2050.editor.engine.ThumbnailExtractor
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.OverlayMask
import com.ve2050.editor.model.TextAnimation
import com.ve2050.editor.model.TextFontFamily
import com.ve2050.editor.model.TextOverlay
import com.ve2050.editor.model.TextPreset
import com.ve2050.editor.model.TransitionType
import com.ve2050.editor.model.VideoFilter
import com.ve2050.editor.model.isRtlText
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.roundToInt

val HeartShape = object : Shape {
    override fun createOutline(
        size: androidx.compose.ui.geometry.Size,
        layoutDirection: androidx.compose.ui.unit.LayoutDirection,
        density: androidx.compose.ui.unit.Density
    ): Outline {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.5f, h * 0.88f)
            cubicTo(w * 0.08f, h * 0.60f, 0f, h * 0.22f, w * 0.25f, h * 0.08f)
            cubicTo(w * 0.42f, 0f, w * 0.5f, h * 0.18f, w * 0.5f, h * 0.24f)
            cubicTo(w * 0.5f, h * 0.18f, w * 0.58f, 0f, w * 0.75f, h * 0.08f)
            cubicTo(w, h * 0.22f, w * 0.92f, h * 0.60f, w * 0.5f, h * 0.88f)
            close()
        }
        return Outline.Generic(path)
    }
}

data class EditorHistoryState(
    val clips: List<Clip>,
    val selectedIndex: Int,
    val textOverlays: List<TextOverlay>,
    val overlayUri: Uri?,
    val overlayStartMs: Long,
    val overlayDurationMs: Long,
    val musicUri: Uri?,
    val musicName: String
)

@OptIn(UnstableApi::class)
@Composable
fun EditorScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    var clips by remember { mutableStateOf(listOf<Clip>()) }
    var textOverlays by remember { mutableStateOf(listOf<TextOverlay>()) }
    var selectedTextId by remember { mutableStateOf<String?>(null) }
    var showTextDialog by remember { mutableStateOf(false) }
    var showFilterDialog by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showTransitionDialog by remember { mutableStateOf(false) }
    var editingTextOverlayId by remember { mutableStateOf<String?>(null) }
    var textInput by remember { mutableStateOf("") }
    var selectedTextPreset by remember { mutableStateOf(TextPreset.CYBER_NEON) }
    var selectedTextFont by remember { mutableStateOf(TextFontFamily.SANS_SERIF) }
    var selectedTextColor by remember { mutableIntStateOf(0xFFFFFFFF.toInt()) }
    var selectedTextSize by remember { mutableFloatStateOf(28f) }
    var isTextBold by remember { mutableStateOf(true) }
    var isTextItalic by remember { mutableStateOf(false) }
    var isTextRtl by remember { mutableStateOf(false) }
    var selectedAnimIn by remember { mutableStateOf(TextAnimation.POP) }
    var selectedAnimOut by remember { mutableStateOf(TextAnimation.FADE) }
    var selectedAnimDurationMs by remember { mutableLongStateOf(600L) }
    var selectedIndex by remember { mutableIntStateOf(0) }
    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableFloatStateOf(0f) }
    var showExportDialog by remember { mutableStateOf(false) }
    var selectedExportQuality by remember { mutableStateOf(ExportQuality.MEDIUM) }
    var selectedExportFps by remember { mutableIntStateOf(30) }
    var exportErrorDialogMessage by remember { mutableStateOf<String?>(null) }
    var exportSuccessDialogMessage by remember { mutableStateOf<String?>(null) }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var totalDurationMs by remember { mutableLongStateOf(0L) }
    var musicUri by remember { mutableStateOf<Uri?>(null) }
    var musicPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var musicName by remember { mutableStateOf("No music selected") }
    var overlayUri by remember { mutableStateOf<Uri?>(null) }
    var overlayPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var overlayOffsetX by remember { mutableFloatStateOf(0f) }
    var overlayOffsetY by remember { mutableFloatStateOf(0f) }
    var overlayScale by remember { mutableFloatStateOf(1f) }
    var overlayRotation by remember { mutableFloatStateOf(0f) }
    var overlayOpacity by remember { mutableFloatStateOf(1f) }
    var overlayMask by remember { mutableStateOf(OverlayMask.NONE) }
    var isChromaKeyEnabled by remember { mutableStateOf(false) }
    var chromaKeyIntensity by remember { mutableFloatStateOf(0.6f) }
    var overlayStartMs by remember { mutableLongStateOf(0L) }
    var overlayDurationMs by remember { mutableLongStateOf(6000L) }
    var isOverlaySelected by remember { mutableStateOf(true) }
    var showOverlaySettingsDialog by remember { mutableStateOf(false) }
    var showAiDialog by remember { mutableStateOf(false) }
    var aiPlanText by remember { mutableStateOf<String?>(null) }
    var selectedAspectRatio by remember { mutableStateOf("9:16") }
    var notificationMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val undoStack = remember { mutableStateListOf<EditorHistoryState>() }
    val redoStack = remember { mutableStateListOf<EditorHistoryState>() }

    fun showNotice(msg: String) {
        notificationMessage = msg
        scope.launch {
            delay(2400)
            if (notificationMessage == msg) {
                notificationMessage = null
            }
        }
    }

    fun saveSnapshotForUndo() {
        undoStack.add(
            EditorHistoryState(
                clips = clips,
                selectedIndex = selectedIndex,
                textOverlays = textOverlays,
                overlayUri = overlayUri,
                overlayStartMs = overlayStartMs,
                overlayDurationMs = overlayDurationMs,
                musicUri = musicUri,
                musicName = musicName
            )
        )
        if (undoStack.size > 20) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val last = undoStack.removeAt(undoStack.lastIndex)
            redoStack.add(
                EditorHistoryState(
                    clips = clips,
                    selectedIndex = selectedIndex,
                    textOverlays = textOverlays,
                    overlayUri = overlayUri,
                    overlayStartMs = overlayStartMs,
                    overlayDurationMs = overlayDurationMs,
                    musicUri = musicUri,
                    musicName = musicName
                )
            )
            clips = last.clips
            selectedIndex = last.selectedIndex.coerceIn(0, (last.clips.size - 1).coerceAtLeast(0))
            textOverlays = last.textOverlays
            overlayUri = last.overlayUri
            overlayStartMs = last.overlayStartMs
            overlayDurationMs = last.overlayDurationMs
            musicUri = last.musicUri
            musicName = last.musicName
            showNotice("Undo")
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeAt(redoStack.lastIndex)
            undoStack.add(
                EditorHistoryState(
                    clips = clips,
                    selectedIndex = selectedIndex,
                    textOverlays = textOverlays,
                    overlayUri = overlayUri,
                    overlayStartMs = overlayStartMs,
                    overlayDurationMs = overlayDurationMs,
                    musicUri = musicUri,
                    musicName = musicName
                )
            )
            clips = next.clips
            selectedIndex = next.selectedIndex.coerceIn(0, (next.clips.size - 1).coerceAtLeast(0))
            textOverlays = next.textOverlays
            overlayUri = next.overlayUri
            overlayStartMs = next.overlayStartMs
            overlayDurationMs = next.overlayDurationMs
            musicUri = next.musicUri
            musicName = next.musicName
            showNotice("Redo")
        }
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(10)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            saveSnapshotForUndo()
            scope.launch {
                val newClips = uris.map { uri ->
                    val duration = ThumbnailExtractor.extractDurationMs(context, uri)
                    Clip(
                        uri = uri,
                        startMs = 0L,
                        endMs = duration,
                        durationMs = duration
                    )
                }
                clips = clips + newClips
                showNotice("Added ${uris.size} clip(s) to timeline")
            }
        }
    }

    val musicPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            saveSnapshotForUndo()
            musicUri = uri
            musicName = "Audio Track Active ✔"
            musicPlayer?.release()
            musicPlayer = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
            }
            showNotice("Background music loaded & synchronized")
        }
    }

    val overlayPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            saveSnapshotForUndo()
            overlayUri = uri
            overlayOffsetX = 0f
            overlayOffsetY = 0f
            overlayScale = 1f
            overlayRotation = 0f
            overlayOpacity = 1f
            overlayMask = OverlayMask.NONE
            isChromaKeyEnabled = false
            overlayStartMs = currentPositionMs
            overlayDurationMs = if (totalDurationMs > 0) minOf(totalDurationMs - currentPositionMs, 8000L).coerceAtLeast(3000L) else 8000L
            isOverlaySelected = true
            overlayPlayer?.release()
            overlayPlayer = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                repeatMode = Player.REPEAT_MODE_ALL
                prepare()
                if (isPlaying) play()
            }
            showNotice("Overlay video added! Drag, pinch-resize & rotate active")
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            musicPlayer?.release()
            overlayPlayer?.release()
        }
    }

    // Stable ExoPlayer lifecycle
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
        }
    }

    DisposableEffect(exoPlayer) {
        player = exoPlayer
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val index = exoPlayer.currentMediaItemIndex
                if (index in clips.indices) {
                    selectedIndex = index
                    exoPlayer.setPlaybackSpeed(clips[index].speed)
                }
            }
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                if (playing) {
                    musicPlayer?.play()
                    overlayPlayer?.play()
                } else {
                    musicPlayer?.pause()
                    overlayPlayer?.pause()
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            musicPlayer?.release()
            overlayPlayer?.release()
        }
    }

    // Synchronize media items when clips list changes
    LaunchedEffect(clips) {
        val validClips = clips.filter { it.uri != Uri.EMPTY }
        if (validClips.isNotEmpty()) {
            val mediaItems = validClips.map { MediaItem.fromUri(it.uri) }
            val currentIdx = exoPlayer.currentMediaItemIndex
            val currentPos = exoPlayer.currentPosition
            exoPlayer.setMediaItems(mediaItems)
            if (selectedIndex in validClips.indices) {
                exoPlayer.seekTo(selectedIndex, currentPos.coerceAtLeast(0L))
                exoPlayer.setPlaybackSpeed(validClips[selectedIndex].speed)
            }
            exoPlayer.prepare()
        } else {
            exoPlayer.clearMediaItems()
        }
    }

    // Playhead progress ticker & total duration
    LaunchedEffect(exoPlayer, isPlaying, clips) {
        while (isActive) {
            val dur = clips.sumOf { if (it.durationMs > 0) it.durationMs else 4000L }
            totalDurationMs = dur
            if (clips.isNotEmpty()) {
                val curItemIndex = exoPlayer.currentMediaItemIndex
                val posInItem = exoPlayer.currentPosition.coerceAtLeast(0L)
                var accumulated = 0L
                for (i in 0 until minOf(curItemIndex, clips.size)) {
                    accumulated += if (clips[i].durationMs > 0) clips[i].durationMs else 4000L
                }
                currentPositionMs = (accumulated + posInItem).coerceIn(0L, dur)
            } else {
                currentPositionMs = 0L
            }
            delay(80)
        }
    }

    LaunchedEffect(selectedIndex) {
        if (selectedIndex in clips.indices) {
            if (exoPlayer.currentMediaItemIndex != selectedIndex) {
                exoPlayer.seekToDefaultPosition(selectedIndex)
            }
            exoPlayer.setPlaybackSpeed(clips[selectedIndex].speed)
        }
    }

    // Synchronize overlay playback position and state with timeline
    LaunchedEffect(currentPositionMs, overlayStartMs, overlayDurationMs, overlayPlayer, isPlaying) {
        val oPlayer = overlayPlayer ?: return@LaunchedEffect
        if (overlayUri != null) {
            val relTime = currentPositionMs - overlayStartMs
            if (relTime in 0L..overlayDurationMs) {
                if (kotlin.math.abs(oPlayer.currentPosition - relTime) > 350L) {
                    oPlayer.seekTo(relTime)
                }
                if (isPlaying && !oPlayer.isPlaying) {
                    oPlayer.play()
                }
            } else {
                if (oPlayer.isPlaying) {
                    oPlayer.pause()
                }
            }
        }
    }

    // Equalizer animation
    val infiniteTransition = rememberInfiniteTransition(label = "eq")
    val eqWave1 by infiniteTransition.animateFloat(
        initialValue = 4f, targetValue = 18f,
        animationSpec = infiniteRepeatable(tween(400, easing = FastOutLinearInEasing), RepeatMode.Reverse), label = "eq1"
    )
    val eqWave2 by infiniteTransition.animateFloat(
        initialValue = 16f, targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(350, easing = LinearOutSlowInEasing), RepeatMode.Reverse), label = "eq2"
    )
    val eqWave3 by infiniteTransition.animateFloat(
        initialValue = 8f, targetValue = 22f,
        animationSpec = infiniteRepeatable(tween(450, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "eq3"
    )

    fun formatTime(ms: Long): String {
        val totalSecs = (ms / 1000).coerceAtLeast(0L)
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        return String.format("%02d:%02d", mins, secs)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0C10))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Pro Header Bar (CapCut style)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Back button with min 48dp touch target
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onBack),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF161622))
                                .border(1.dp, Color(0xFF242434), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(Modifier.width(4.dp))

                    // Aspect Ratio Selector Pill with min 48dp touch height
                    Surface(
                        onClick = {
                            selectedAspectRatio = when (selectedAspectRatio) {
                                "9:16" -> "16:9"
                                "16:9" -> "1:1"
                                else -> "9:16"
                            }
                            showNotice("Aspect Ratio set to $selectedAspectRatio")
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF161622),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF28283C)),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.AspectRatio,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = selectedAspectRatio,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(Modifier.width(4.dp))

                    // Undo Button with min 48dp touch target
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable(enabled = undoStack.isNotEmpty(), onClick = { undo() }),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (undoStack.isNotEmpty()) Color(0xFF161622) else Color(0xFF101018))
                                .border(1.dp, if (undoStack.isNotEmpty()) Color(0xFF242434) else Color(0xFF181822), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Undo,
                                contentDescription = "Undo",
                                tint = if (undoStack.isNotEmpty()) Color(0xFF00E5FF) else Color(0xFF444455),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Redo Button with min 48dp touch target
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable(enabled = redoStack.isNotEmpty(), onClick = { redo() }),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (redoStack.isNotEmpty()) Color(0xFF161622) else Color(0xFF101018))
                                .border(1.dp, if (redoStack.isNotEmpty()) Color(0xFF242434) else Color(0xFF181822), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Redo,
                                contentDescription = "Redo",
                                tint = if (redoStack.isNotEmpty()) Color(0xFF00E5FF) else Color(0xFF444455),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Export Action Button (Solid Cyan accent, min 48dp height touch target, single line text)
                Button(
                    onClick = {
                        if (clips.isNotEmpty()) {
                            showExportDialog = true
                        } else {
                            showNotice("Add at least 1 video clip to export")
                        }
                    },
                    enabled = clips.isNotEmpty() && !isExporting,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        disabledContainerColor = Color(0xFF1E1E28),
                        contentColor = Color.Black,
                        disabledContentColor = Color(0xFF555566)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .defaultMinSize(minWidth = 104.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        if (isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.Black
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "${(exportProgress * 100).toInt()}%",
                                color = Color.Black,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        } else {
                            Icon(
                                Icons.Default.FileUpload,
                                contentDescription = null,
                                tint = if (clips.isNotEmpty()) Color.Black else Color(0xFF666677),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "EXPORT",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp,
                                color = if (clips.isNotEmpty()) Color.Black else Color(0xFF666677),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }

            // 2. Video Preview Monitor (Framed with Aspect Ratio - ~40% screen)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.40f)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF050508))
                    .border(1.dp, Color(0xFF1E1E28), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                val p = player
                if (p == null) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(68.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF14141E)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Movie,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(34.dp)
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "Import clips to start editing",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Tap '+ Add Clip' below to build your timeline",
                            color = Color(0xFF777788),
                            fontSize = 11.sp
                        )
                    }
                } else {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                useController = false
                                this.player = p
                            }
                        },
                        update = { it.player = p },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Real-time Video Filter Shader Overlay
                val currentClip = clips.getOrNull(selectedIndex)
                if (currentClip != null) {
                    when (currentClip.filter) {
                        VideoFilter.CYBER_NEON -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.radialGradient(
                                            listOf(Color(0x3300E5FF), Color(0x44FF007F))
                                        )
                                    )
                            )
                        }
                        VideoFilter.MATRIX_HUD -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(0x3000FF66))
                            )
                        }
                        VideoFilter.SYNTHWAVE_GLOW -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color(0x33FFB300), Color(0x448E24AA))
                                        )
                                    )
                            )
                        }
                        VideoFilter.THERMAL_VISION -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(Color(0x350022FF), Color(0x3500FF44), Color(0x35FF1100))
                                        )
                                    )
                            )
                        }
                        VideoFilter.HOLO_SCANLINES -> {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val step = 8.dp.toPx()
                                for (y in 0..size.height.toInt() step step.toInt()) {
                                    drawLine(
                                        color = Color(0x4400E5FF),
                                        start = Offset(0f, y.toFloat()),
                                        end = Offset(size.width, y.toFloat()),
                                        strokeWidth = 1.5f
                                    )
                                }
                            }
                        }
                        VideoFilter.QUANTUM_GLITCH -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(0x33FF00AA))
                            )
                        }
                        VideoFilter.VINTAGE_2020 -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color(0x33D7CCC8))
                            )
                        }
                        VideoFilter.NONE -> {}
                    }
                }

                // Floating Tap-To-Play/Pause Overlay
                if (player != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                if (isPlaying) player?.pause() else player?.play()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (!isPlaying) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.65f))
                                    .border(1.5.dp, Color(0xFF00E5FF), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(38.dp)
                                )
                            }
                        }
                    }

                    // Floating Timecode Badge
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.75f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF28283C)),
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "${formatTime(currentPositionMs)} / ${formatTime(totalDurationMs)}",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Picture-in-Picture (Overlay) Window with Drag, 2-Finger Resize & Rotate, Masks, Opacity & Chroma Key
                if (overlayUri != null && overlayPlayer != null) {
                    val isOverlayActive = !isPlaying || (currentPositionMs in overlayStartMs..(overlayStartMs + overlayDurationMs))

                    if (isOverlayActive) {
                        val currentMaskShape: Shape = when (overlayMask) {
                            OverlayMask.NONE -> RoundedCornerShape(10.dp)
                            OverlayMask.RECTANGLE -> RoundedCornerShape(26.dp)
                            OverlayMask.CIRCLE -> CircleShape
                            OverlayMask.HEART -> HeartShape
                        }
                        val overlayBoxWidth = if (overlayMask == OverlayMask.CIRCLE || overlayMask == OverlayMask.HEART) 125.dp else 145.dp
                        val overlayBoxHeight = if (overlayMask == OverlayMask.CIRCLE || overlayMask == OverlayMask.HEART) 125.dp else 95.dp

                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .offset { IntOffset(overlayOffsetX.roundToInt(), overlayOffsetY.roundToInt()) }
                                .graphicsLayer(
                                    scaleX = overlayScale,
                                    scaleY = overlayScale,
                                    rotationZ = overlayRotation,
                                    alpha = overlayOpacity
                                )
                                .size(width = overlayBoxWidth, height = overlayBoxHeight)
                                .clip(currentMaskShape)
                                .background(Color.Black)
                                .border(
                                    width = if (isOverlaySelected) 2.dp else 1.2.dp,
                                    color = if (isChromaKeyEnabled) Color(0xFF00FF66) else if (isOverlaySelected) Color(0xFF00E5FF) else Color(0xFF263238),
                                    shape = currentMaskShape
                                )
                                .pointerInput(Unit) {
                                    detectTransformGestures { _, pan, zoom, rotation ->
                                        overlayScale = (overlayScale * zoom).coerceIn(0.25f, 3.5f)
                                        overlayRotation = (overlayRotation + rotation) % 360f
                                        overlayOffsetX += pan.x
                                        overlayOffsetY += pan.y
                                        isOverlaySelected = true
                                    }
                                }
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    PlayerView(ctx).apply {
                                        useController = false
                                        this.player = overlayPlayer
                                    }
                                },
                                update = { it.player = overlayPlayer },
                                modifier = Modifier.fillMaxSize()
                            )

                            // Chroma Key Green-Screen Removal Visual Effect Layer
                            if (isChromaKeyEnabled) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.radialGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    Color(0xFF00FF66).copy(alpha = 0.12f * chromaKeyIntensity)
                                                )
                                            )
                                        )
                                )
                            }

                            // PIP & Rotation/Scale Telemetry Badge
                            Surface(
                                color = if (isChromaKeyEnabled) Color(0xFF005522).copy(alpha = 0.85f) else Color(0xFF00E5FF).copy(alpha = 0.9f),
                                shape = RoundedCornerShape(bottomEnd = 6.dp),
                                modifier = Modifier.align(Alignment.TopStart)
                            ) {
                                Text(
                                    text = if (isChromaKeyEnabled) "KEY" else "PIP",
                                    color = if (isChromaKeyEnabled) Color.White else Color.Black,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }

                            // Quick Overlay Settings Action Gear
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(2.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.75f))
                                    .clickable { showOverlaySettingsDialog = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Tune,
                                    contentDescription = "Overlay Settings",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(14.dp)
                                )
                            }

                            // Close button to remove overlay
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(2.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.75f))
                                    .clickable {
                                        overlayPlayer?.release()
                                        overlayPlayer = null
                                        overlayUri = null
                                        showNotice("Overlay removed")
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Remove Overlay",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }

                            // Active Rotation & Scale Angle readout badge at bottom-left
                            if (isOverlaySelected) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.75f),
                                    shape = RoundedCornerShape(topEnd = 6.dp),
                                    modifier = Modifier.align(Alignment.BottomStart)
                                ) {
                                    Text(
                                        text = "${overlayRotation.roundToInt()}°",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 3. CapCut Pro Multi-Track Timeline (Ruler, Filmstrip, Overlay, Text, Audio, Center Playhead)
            TimelineView(
                clips = clips,
                selectedIndex = selectedIndex,
                currentPositionMs = currentPositionMs,
                totalDurationMs = totalDurationMs,
                isPlaying = isPlaying,
                overlayUri = overlayUri,
                overlayScale = overlayScale,
                overlayStartMs = overlayStartMs,
                overlayDurationMs = overlayDurationMs,
                isOverlaySelected = isOverlaySelected,
                onTrimOverlay = { newStart, newDur ->
                    overlayStartMs = newStart
                    overlayDurationMs = newDur
                    showNotice("Overlay trimmed: ${String.format("%.1f", newDur / 1000f)}s")
                },
                onMoveOverlay = { newStart ->
                    overlayStartMs = newStart
                    showNotice("Overlay position: ${String.format("%.1f", newStart / 1000f)}s")
                },
                onSelectOverlay = {
                    isOverlaySelected = true
                    showOverlaySettingsDialog = true
                },
                textOverlays = textOverlays,
                musicUri = musicUri,
                musicName = musicName,
                onSeek = { targetMs ->
                    if (clips.isNotEmpty() && player != null) {
                        var accumulated = 0L
                        for (i in clips.indices) {
                            val clipDur = if (clips[i].durationMs > 0) clips[i].durationMs else 4000L
                            if (targetMs <= accumulated + clipDur || i == clips.lastIndex) {
                                val offsetInClip = (targetMs - accumulated).coerceIn(0L, clipDur)
                                if (selectedIndex != i) {
                                    selectedIndex = i
                                }
                                player?.seekTo(i, offsetInClip)
                                currentPositionMs = targetMs
                                break
                            }
                            accumulated += clipDur
                        }
                    }
                },
                onSelect = { selectedIndex = it },
                onReorder = { fromIndex, toIndex ->
                    if (fromIndex in clips.indices && toIndex in clips.indices && fromIndex != toIndex) {
                        saveSnapshotForUndo()
                        val list = clips.toMutableList()
                        val item = list.removeAt(fromIndex)
                        list.add(toIndex, item)
                        clips = list
                        selectedIndex = toIndex
                        showNotice("Clips reordered")
                    }
                },
                onTrimClip = { index, newStart, newEnd ->
                    if (index in clips.indices) {
                        saveSnapshotForUndo()
                        val old = clips[index]
                        val dur = (newEnd - newStart).coerceAtLeast(800L)
                        val updated = old.copy(
                            startMs = newStart,
                            endMs = newStart + dur,
                            durationMs = dur
                        )
                        clips = clips.toMutableList().apply { set(index, updated) }
                        showNotice("Trimmed clip ${index + 1}: ${String.format("%.1f", dur / 1000f)}s")
                    }
                },
                onDeleteOverlay = {
                    saveSnapshotForUndo()
                    overlayPlayer?.release()
                    overlayPlayer = null
                    overlayUri = null
                    showNotice("Overlay track cleared")
                },
                onDeleteMusic = {
                    saveSnapshotForUndo()
                    musicPlayer?.release()
                    musicPlayer = null
                    musicUri = null
                    musicName = "No music selected"
                    showNotice("Audio track removed")
                },
                onDeleteTextOverlay = { id ->
                    saveSnapshotForUndo()
                    textOverlays = textOverlays.filter { it.id != id }
                    showNotice("Text overlay removed")
                },
                onAddClip = {
                    picker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.35f)
            )

            Spacer(Modifier.height(4.dp))

            // 4. Pro Editing Dock (CapCut Horizontal Category Toolbar)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF101018),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E2C))
            ) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item {
                        ToolButton(Icons.Default.ContentCut, "Split") {
                            if (clips.isEmpty()) {
                                showNotice("No clips to split. Tap '+ Add Clip'")
                                return@ToolButton
                            }
                            var accumulated = 0L
                            var targetIndex = -1
                            var offsetInClip = 0L

                            for (i in clips.indices) {
                                val dur = if (clips[i].durationMs > 0) clips[i].durationMs else 4000L
                                if (currentPositionMs in accumulated..(accumulated + dur)) {
                                    targetIndex = i
                                    offsetInClip = currentPositionMs - accumulated
                                    break
                                }
                                accumulated += dur
                            }

                            if (targetIndex == -1) {
                                targetIndex = selectedIndex.coerceIn(0, clips.lastIndex)
                                val clipDur = if (clips[targetIndex].durationMs > 0) clips[targetIndex].durationMs else 4000L
                                offsetInClip = (clipDur / 2).coerceAtLeast(500L)
                            }

                            val clip = clips[targetIndex]
                            val clipDur = if (clip.durationMs > 0) clip.durationMs else 4000L

                            if (offsetInClip < 300L || offsetInClip > clipDur - 300L) {
                                showNotice("Move playhead inside clip to split")
                                return@ToolButton
                            }

                            saveSnapshotForUndo()
                            val firstClip = clip.copy(
                                id = UUID.randomUUID().toString(),
                                endMs = clip.startMs + offsetInClip,
                                durationMs = offsetInClip
                            )
                            val secondClip = clip.copy(
                                id = UUID.randomUUID().toString(),
                                startMs = clip.startMs + offsetInClip,
                                durationMs = clipDur - offsetInClip,
                                endMs = clip.startMs + clipDur
                            )

                            val list = clips.toMutableList()
                            list[targetIndex] = firstClip
                            list.add(targetIndex + 1, secondClip)
                            clips = list
                            selectedIndex = targetIndex
                            showNotice("Clip split at ${String.format("%.1f", offsetInClip / 1000f)}s")
                        }
                    }
                    item {
                        ToolButton(Icons.Default.Delete, "Delete") {
                            if (clips.isEmpty()) {
                                showNotice("No clips to delete")
                                return@ToolButton
                            }
                            if (selectedIndex in clips.indices) {
                                saveSnapshotForUndo()
                                val list = clips.toMutableList()
                                list.removeAt(selectedIndex)
                                clips = list
                                selectedIndex = (selectedIndex - 1).coerceAtLeast(0)
                                showNotice("Clip deleted")
                            }
                        }
                    }
                    item {
                        ToolButton(Icons.Default.ContentCopy, "Duplicate") {
                            if (clips.isEmpty()) {
                                showNotice("No clip to duplicate")
                                return@ToolButton
                            }
                            val clip = clips.getOrNull(selectedIndex)
                            if (clip != null) {
                                saveSnapshotForUndo()
                                val dup = clip.copy(id = UUID.randomUUID().toString())
                                val list = clips.toMutableList()
                                list.add(selectedIndex + 1, dup)
                                clips = list
                                selectedIndex = selectedIndex + 1
                                showNotice("Clip duplicated")
                            }
                        }
                    }
                    item {
                        ToolButton(Icons.Default.Speed, "Speed") { showSpeedDialog = true }
                    }
                    item {
                        ToolButton(Icons.Default.FilterVintage, "Filter") { showFilterDialog = true }
                    }
                    item {
                        ToolButton(Icons.Default.SwapHoriz, "Transition") { showTransitionDialog = true }
                    }
                    item {
                        ToolButton(Icons.Default.TextFields, "Text") { showTextDialog = true }
                    }
                    item {
                        ToolButton(Icons.Default.Layers, if (overlayUri != null) "Overlay Pro" else "Overlay") {
                            if (overlayUri != null) {
                                showOverlaySettingsDialog = true
                            } else {
                                overlayPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            }
                        }
                    }
                    item {
                        ToolButton(Icons.Default.MusicNote, "Audio") {
                            musicPicker.launch("audio/*")
                        }
                    }
                    item {
                        ToolButton(Icons.Default.AutoAwesome, "AI Magic") {
                            scope.launch {
                                showNotice("Generating neural edit plan...")
                                aiPlanText = com.ve2050.editor.ai.GeminiService.suggestEditPlan(
                                    "Futuristic cyberpunk 2050 video with ${clips.size} clips"
                                )
                                showAiDialog = true
                            }
                        }
                    }
                    item {
                        ToolButton(Icons.Default.Add, "Add Clip") {
                            picker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        }
                    }
                }
            }
        }

        // Floating In-App Cyber Notification HUD with smooth fade and slide animations
        AnimatedVisibility(
            visible = notificationMessage != null,
            enter = fadeIn(animationSpec = tween(250)) + slideInVertically(animationSpec = tween(250)) { -it },
            exit = fadeOut(animationSpec = tween(200)) + slideOutVertically(animationSpec = tween(200)) { -it },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 54.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF14141E),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.6f)),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E5FF))
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = notificationMessage ?: "",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }

    // Filter Dialog (CapCut Style Cards with Live Visual Preview Chips)
    if (showFilterDialog) {
        AlertDialog(
            onDismissRequest = { showFilterDialog = false },
            containerColor = Color(0xFF13131E),
            title = {
                Text(
                    "Video Filters & Color Grading",
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().height(270.dp)) {
                    items(VideoFilter.values().toList()) { filter ->
                        val isSelected = clips.getOrNull(selectedIndex)?.filter == filter
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) Color(0xFF1D2638) else Color.Transparent)
                                .clickable {
                                    val clip = clips.getOrNull(selectedIndex)
                                    if (clip != null) {
                                        saveSnapshotForUndo()
                                        val updated = clip.copy(filter = filter)
                                        clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                                        showNotice("Applied: ${filter.displayName}")
                                    }
                                    showFilterDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Visual Gradient Color Chip
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            when (filter) {
                                                VideoFilter.CYBER_NEON -> Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFFFF007F)))
                                                VideoFilter.MATRIX_HUD -> Brush.linearGradient(listOf(Color(0xFF00FF88), Color(0xFF003311)))
                                                VideoFilter.SYNTHWAVE_GLOW -> Brush.linearGradient(listOf(Color(0xFFFFB300), Color(0xFF8E24AA)))
                                                VideoFilter.THERMAL_VISION -> Brush.linearGradient(listOf(Color(0xFF0022FF), Color(0xFFFF1100)))
                                                VideoFilter.HOLO_SCANLINES -> Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFF112244)))
                                                VideoFilter.QUANTUM_GLITCH -> Brush.linearGradient(listOf(Color(0xFFFF00AA), Color(0xFF330066)))
                                                VideoFilter.VINTAGE_2020 -> Brush.linearGradient(listOf(Color(0xFFD7CCC8), Color(0xFF5D4037)))
                                                VideoFilter.NONE -> Brush.linearGradient(listOf(Color(0xFF333333), Color(0xFF555555)))
                                            }
                                        )
                                        .border(1.dp, Color(0xFF333348), RoundedCornerShape(8.dp))
                                )
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(
                                        filter.displayName,
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                    Text(filter.description, color = Color(0xFF888899), fontSize = 11.sp)
                                }
                            }
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showFilterDialog = false },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("DONE", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Speed Control Dialog (CapCut Multiplier Chips)
    if (showSpeedDialog) {
        val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f)
        val currentSpeed = clips.getOrNull(selectedIndex)?.speed ?: 1.0f
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            containerColor = Color(0xFF14141C),
            shape = RoundedCornerShape(16.dp),
            title = {
                Text(
                    "Speed Control (Slow-Mo / Velocity)",
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Active Speed: ${currentSpeed}x",
                        color = Color.White,
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(14.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(speeds) { spd ->
                            val isSelected = currentSpeed == spd
                            Button(
                                onClick = {
                                    val clip = clips.getOrNull(selectedIndex)
                                    if (clip != null) {
                                        saveSnapshotForUndo()
                                        val updated = clip.copy(speed = spd)
                                        clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                                        player?.setPlaybackSpeed(spd)
                                        showNotice("Speed: ${spd}x applied")
                                    }
                                    showSpeedDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) Color(0xFF00E5FF) else Color(0xFF222230),
                                    contentColor = if (isSelected) Color.Black else Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.height(48.dp)
                            ) {
                                Text("${spd}x", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showSpeedDialog = false },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("CANCEL", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Transition Dialog (CapCut Wipes)
    if (showTransitionDialog) {
        val transitions = TransitionType.values().toList()
        val currentTransition = clips.getOrNull(selectedIndex)?.transitionIn ?: TransitionType.NONE
        AlertDialog(
            onDismissRequest = { showTransitionDialog = false },
            containerColor = Color(0xFF14141C),
            shape = RoundedCornerShape(16.dp),
            title = {
                Text(
                    "Clip Transition Style",
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().height(240.dp)) {
                    items(transitions) { trans ->
                        val isSelected = currentTransition == trans
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF162836) else Color.Transparent)
                                .clickable {
                                    val clip = clips.getOrNull(selectedIndex)
                                    if (clip != null) {
                                        saveSnapshotForUndo()
                                        val updated = clip.copy(transitionIn = trans)
                                        clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                                        showNotice("Transition: ${trans.title}")
                                    }
                                    showTransitionDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                trans.title,
                                color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showTransitionDialog = false },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("DONE", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // AI Edit Plan Dialog
    if (showAiDialog) {
        AlertDialog(
            onDismissRequest = { showAiDialog = false },
            containerColor = Color(0xFF14141C),
            shape = RoundedCornerShape(16.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF00E5FF))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "AI Studio Edit Plan",
                        color = Color(0xFF00E5FF),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            },
            text = {
                Text(
                    aiPlanText ?: "Analyzing timeline and generating pro edit plan...",
                    color = Color.White,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showAiDialog = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("APPLY PLAN", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Text Overlay Dialog
    if (showTextDialog) {
        AlertDialog(
            onDismissRequest = { showTextDialog = false },
            containerColor = Color(0xFF14141C),
            shape = RoundedCornerShape(16.dp),
            title = { Text("Add Text Overlay", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    label = { Text("Title / Subtitle") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF333344)
                    )
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            saveSnapshotForUndo()
                            textOverlays = textOverlays + TextOverlay(
                                text = textInput,
                                startMs = 0L,
                                endMs = Long.MAX_VALUE
                            )
                            showNotice("Text overlay added")
                            textInput = ""
                        }
                        showTextDialog = false
                    },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("ADD", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showTextDialog = false },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("CANCEL", color = Color(0xFFAAAAAA))
                }
            }
        )
    }

    // Overlay Pro Studio Dialog (Opacity, Masks, Chroma Key & Transform)
    if (showOverlaySettingsDialog && overlayUri != null) {
        AlertDialog(
            onDismissRequest = { showOverlaySettingsDialog = false },
            containerColor = Color(0xFF14141C),
            shape = RoundedCornerShape(16.dp),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Layers,
                            contentDescription = null,
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Overlay Pro Studio",
                            color = Color(0xFF00E5FF),
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable { showOverlaySettingsDialog = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    // 1. Opacity Slider (CapCut pro slider)
                    Text(
                        "OPACITY (${(overlayOpacity * 100).roundToInt()}%)",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Slider(
                        value = overlayOpacity,
                        onValueChange = { overlayOpacity = it },
                        valueRange = 0.05f..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF),
                            inactiveTrackColor = Color(0xFF1E2832)
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(0.25f, 0.50f, 0.75f, 1.0f).forEach { preset ->
                            FilterChip(
                                selected = (kotlin.math.abs(overlayOpacity - preset) < 0.05f),
                                onClick = { overlayOpacity = preset },
                                label = { Text("${(preset * 100).toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF00E5FF),
                                    selectedLabelColor = Color.Black
                                ),
                                modifier = Modifier.defaultMinSize(minHeight = 40.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // 2. Mask Shapes (Circle, Rectangle, Heart, Free)
                    Text(
                        "MASK SHAPES",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OverlayMask.values().forEach { mask ->
                            val isSelectedMask = (overlayMask == mask)
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .defaultMinSize(minHeight = 48.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        overlayMask = mask
                                        showNotice("Mask applied: ${mask.displayName}")
                                    },
                                color = if (isSelectedMask) Color(0xFF142432) else Color(0xFF181822),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelectedMask) 1.5.dp else 1.dp,
                                    color = if (isSelectedMask) Color(0xFF00E5FF) else Color(0xFF282838)
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 2.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(mask.icon, fontSize = 20.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        mask.displayName.split(" ").first(),
                                        color = if (isSelectedMask) Color(0xFF00E5FF) else Color(0xFFAAAAAA),
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelectedMask) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(18.dp))

                    // 3. Chroma Key (Green Screen Removal)
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF0D1E16),
                        border = androidx.compose.foundation.BorderStroke(
                            width = 1.dp,
                            color = if (isChromaKeyEnabled) Color(0xFF00FF66) else Color(0xFF1A3828)
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("🟢", fontSize = 16.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            "Chroma Key",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            "Green Screen Removal",
                                            color = Color(0xFF70D090),
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                Switch(
                                    checked = isChromaKeyEnabled,
                                    onCheckedChange = {
                                        isChromaKeyEnabled = it
                                        showNotice(if (it) "Chroma Key Enabled (Green Screen Removed)" else "Chroma Key Disabled")
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color(0xFF00FF66),
                                        checkedTrackColor = Color(0xFF005522)
                                    )
                                )
                            }

                            if (isChromaKeyEnabled) {
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    "KEY INTENSITY: ${(chromaKeyIntensity * 100).roundToInt()}%",
                                    color = Color(0xFF90FFB0),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Slider(
                                    value = chromaKeyIntensity,
                                    onValueChange = { chromaKeyIntensity = it },
                                    valueRange = 0.1f..1.0f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color(0xFF00FF66),
                                        activeTrackColor = Color(0xFF00FF66),
                                        inactiveTrackColor = Color(0xFF0A3319)
                                    )
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // 4. Transform Quick Controls
                    Text(
                        "TRANSFORMATION",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                overlayRotation = (overlayRotation + 90f) % 360f
                                showNotice("Rotated 90° (${overlayRotation.roundToInt()}°)")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("+90°", fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                overlayOffsetX = 0f
                                overlayOffsetY = 0f
                                overlayScale = 1f
                                overlayRotation = 0f
                                showNotice("Transform reset")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Reset", fontSize = 11.sp)
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Replace / Change video button
                    OutlinedButton(
                        onClick = {
                            overlayPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFF00E5FF)
                        )
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Change Overlay Video", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showOverlaySettingsDialog = false },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("APPLY", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // 1. Export Configuration Dialog (Quality & FPS)
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            containerColor = Color(0xFF14141E),
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00E5FF).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.FileUpload,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Export Video",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable { showExportDialog = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFFAAAAAA),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Resolution / Quality Selection
                    Text(
                        "QUALITY / RESOLUTION",
                        color = Color(0xFF888899),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(Modifier.height(8.dp))

                    val qualities = listOf(
                        ExportQuality.LOW,
                        ExportQuality.MEDIUM,
                        ExportQuality.HIGH
                    )

                    qualities.forEach { quality ->
                        val isSelected = selectedExportQuality == quality
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFF12242E) else Color(0xFF1A1A26))
                                .border(
                                    1.dp,
                                    if (isSelected) Color(0xFF00E5FF) else Color(0xFF262638),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedExportQuality = quality }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedExportQuality = quality },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = Color(0xFF00E5FF),
                                    unselectedColor = Color(0xFF555566)
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = quality.label,
                                    color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${quality.resolutionText} • ${quality.description}",
                                    color = Color(0xFF888899),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(18.dp))

                    // Frame Rate Selection (FPS: 30 or 60)
                    Text(
                        "FRAME RATE (FPS)",
                        color = Color(0xFF888899),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf(30, 60).forEach { fps ->
                            val isSelected = selectedExportFps == fps
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) Color(0xFF12242E) else Color(0xFF1A1A26))
                                    .border(
                                        1.dp,
                                        if (isSelected) Color(0xFF00E5FF) else Color(0xFF262638),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { selectedExportFps = fps }
                                    .padding(vertical = 12.dp, horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "$fps FPS",
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = if (fps == 30) "Standard" else "Ultra Smooth",
                                        color = Color(0xFF888899),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Target Location Info
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0E0E18))
                            .border(1.dp, Color(0xFF222230), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Folder,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    "Save Location",
                                    color = Color(0xFFAAAAAA),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    "Gallery / Movies / VideoEditor2050",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExportDialog = false
                        isExporting = true
                        exportProgress = 0f
                        showNotice("Starting export (${selectedExportQuality.label} • ${selectedExportFps} FPS)...")
                        ExportEngine.export(
                            context = context,
                            clips = clips,
                            quality = selectedExportQuality,
                            fps = selectedExportFps,
                            textOverlays = textOverlays,
                            musicUri = musicUri,
                            overlayUri = overlayUri,
                            overlayScale = (overlayScale * 0.45f).coerceIn(0.2f, 2.5f),
                            overlayRotation = overlayRotation,
                            overlayStartMs = overlayStartMs,
                            overlayDurationMs = overlayDurationMs,
                            onProgress = { exportProgress = it },
                            onDone = { success, msg ->
                                isExporting = false
                                if (success) {
                                    exportSuccessDialogMessage = msg
                                    showNotice("Saved to Gallery / Movies")
                                } else {
                                    exportErrorDialogMessage = msg
                                    showNotice("Export failed")
                                }
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(
                        Icons.Default.FileUpload,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "START EXPORT",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showExportDialog = false },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("CANCEL", color = Color(0xFFAAAAAA), fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }

    // 2. Export Progress Modal Dialog
    if (isExporting) {
        Dialog(
            onDismissRequest = { /* Non-dismissible while active */ },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14141E)),
                border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E5FF).copy(alpha = 0.15f))
                            .border(1.dp, Color(0xFF00E5FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            progress = { exportProgress },
                            modifier = Modifier.size(36.dp),
                            color = Color(0xFF00E5FF),
                            strokeWidth = 3.dp,
                            trackColor = Color(0xFF222232)
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    Text(
                        "Exporting Video...",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        "${selectedExportQuality.label} • ${selectedExportFps} FPS",
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(Modifier.height(20.dp))

                    LinearProgressIndicator(
                        progress = { exportProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = Color(0xFF00E5FF),
                        trackColor = Color(0xFF222232)
                    )

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            if (exportProgress < 0.95f) "Rendering frames..." else "Saving to Movies...",
                            color = Color(0xFFAAAAAA),
                            fontSize = 12.sp
                        )
                        Text(
                            "${(exportProgress * 100).toInt()}%",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    Text(
                        "Please keep the app open while saving",
                        color = Color(0xFF777788),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }

    // 3. Export Success Dialog (Saved to Gallery / Movies confirmation)
    if (exportSuccessDialogMessage != null) {
        AlertDialog(
            onDismissRequest = { exportSuccessDialogMessage = null },
            containerColor = Color(0xFF14141E),
            shape = RoundedCornerShape(18.dp),
            icon = {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00E5FF).copy(alpha = 0.15f))
                        .border(1.dp, Color(0xFF00E5FF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    "Video Saved!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Saved! Your video is ready in your phone's Gallery / Movies folder.",
                        color = Color(0xFFCCCCCC),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Location: Movies/VideoEditor2050",
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { exportSuccessDialogMessage = null },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("DONE", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        )
    }

    // 4. Export Error Dialog (Clear error message)
    if (exportErrorDialogMessage != null) {
        AlertDialog(
            onDismissRequest = { exportErrorDialogMessage = null },
            containerColor = Color(0xFF181418),
            shape = RoundedCornerShape(18.dp),
            icon = {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFF3B30).copy(alpha = 0.15f))
                        .border(1.dp, Color(0xFFFF3B30), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = Color(0xFFFF3B30),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    "Export Failed",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        exportErrorDialogMessage ?: "Rendering encountered an error.",
                        color = Color(0xFFFFAAAA),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Tip: Select Medium (720p) or Low (480p) or ensure enough free storage space.",
                        color = Color(0xFFAAAAAA),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { exportErrorDialogMessage = null },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF262634),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("OK", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        )
    }
}

@Composable
private fun ToolButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.90f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "toolScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .defaultMinSize(minWidth = 56.dp, minHeight = 60.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(12.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF161622))
                .border(1.dp, Color(0xFF262636), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            color = Color(0xFFC0C0D0),
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}
