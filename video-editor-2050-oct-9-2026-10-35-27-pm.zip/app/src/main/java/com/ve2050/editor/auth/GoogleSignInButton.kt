package com.ve2050.editor.auth

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import coil.compose.AsyncImage
import com.google.firebase.auth.FirebaseUser

@Composable
fun GoogleSignInSection(
    modifier: Modifier = Modifier,
    onUserChanged: (FirebaseUser?) -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    LaunchedEffect(Unit) {
        AuthService.isFirebaseReady(context)
    }

    var currentUser by remember { mutableStateOf(AuthService.currentUser) }
    var isLoading by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val fAuth = AuthService.auth
        if (fAuth != null) {
            val listener = com.google.firebase.auth.FirebaseAuth.AuthStateListener { a ->
                currentUser = a.currentUser
                onUserChanged(a.currentUser)
            }
            fAuth.addAuthStateListener(listener)
            onDispose {
                fAuth.removeAuthStateListener(listener)
            }
        } else {
            onDispose { }
        }
    }

    val user = currentUser
    if (user != null) {
        // Authenticated Profile Badge
        Surface(
            modifier = modifier,
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF141414),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (user.photoUrl != null) {
                    AsyncImage(
                        model = user.photoUrl,
                        contentDescription = "Profile photo",
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Account",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(28.dp)
                    )
                }
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(
                        text = user.displayName ?: "Creator 2050",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        text = user.email ?: "",
                        color = Color(0xFFAAAAAA),
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
                Spacer(Modifier.width(10.dp))
                IconButton(
                    onClick = {
                        isLoading = true
                        AuthService.signOut(credentialManager, scope) {
                            isLoading = false
                            currentUser = null
                            onUserChanged(null)
                            Toast.makeText(context, "Signed out", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "Sign Out",
                        tint = Color(0xFFFF5555),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    } else {
        // Sign In with Google Button
        Button(
            onClick = {
                isLoading = true
                AuthService.isFirebaseReady(context)
                AuthService.signInWithGoogle(
                    context = context,
                    credentialManager = credentialManager,
                    scope = scope,
                    onSuccess = { authedUser ->
                        isLoading = false
                        currentUser = authedUser
                        onUserChanged(authedUser)
                        Toast.makeText(context, "Welcome, ${authedUser.displayName ?: "Creator"}!", Toast.LENGTH_SHORT).show()
                    },
                    onError = { errorMsg ->
                        isLoading = false
                        Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                    },
                    onCancelled = {
                        isLoading = false
                    }
                )
            },
            enabled = !isLoading,
            modifier = modifier.height(48.dp),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color.Black
            )
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    strokeWidth = 2.dp,
                    color = Color.Black
                )
                Spacer(Modifier.width(8.dp))
                Text("Connecting...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            } else {
                Text(
                    "G",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF4285F4)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    "Sign in with Google",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Black
                )
            }
        }
    }
}
