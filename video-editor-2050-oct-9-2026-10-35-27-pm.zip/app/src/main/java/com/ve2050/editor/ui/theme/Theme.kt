package com.ve2050.editor.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// VE2050 Palette
val CyberBlack = Color(0xFF0A0A0A)
val CyberDarkSurface = Color(0xFF141414)
val CyberCardSurface = Color(0xFF1E1E1E)
val CyberCardBorder = Color(0xFF2C2C2C)

val HoloCyan = Color(0xFF00E5FF)
val NeonMagenta = Color(0xFFFF4081)
val QuantumViolet = Color(0xFF9D4EDD)
val MatrixGreen = Color(0xFF00FF88)
val SolarAmber = Color(0xFFFFB800)
val DeepIndigo = Color(0xFF1E1B4B)

val TextPrimary = Color.White
val TextSecondary = Color(0xFF9E9E9E)
val TextMuted = Color(0xFF757575)

val TimelineScrubber = Color(0xFFFF4081)
val AudioTrackColor = Color(0xFF00E5FF)
val VideoTrackColor = Color(0xFF7928CA)
val OverlayTrackColor = Color(0xFFFF7A00)
val TextTrackColor = Color(0xFF00FF88)

val CyberGlowBrush = Brush.linearGradient(
    colors = listOf(HoloCyan, NeonMagenta)
)

val CyberCardGradient = Brush.verticalGradient(
    colors = listOf(CyberCardSurface, CyberDarkSurface)
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF00E5FF),
    onPrimary = Color.Black,
    secondary = Color(0xFFFF4081),
    background = Color(0xFF0A0A0A),
    surface = Color(0xFF141414),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun VE2050Theme(content: @Composable () -> Unit) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = Color(0xFF0A0A0A).toArgb()
                window.navigationBarColor = Color(0xFF0A0A0A).toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = DarkScheme,
        content = content
    )
}

@Composable
fun VideoEditor2050Theme(content: @Composable () -> Unit) {
    VE2050Theme(content = content)
}
