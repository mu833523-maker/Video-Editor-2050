package com.ve2050.editor.model

import android.net.Uri
import java.util.UUID

enum class TrackType(val label: String, val icon: String) {
    VIDEO("Video Track", "🎬"),
    OVERLAY("Holo Overlay", "🌌"),
    AUDIO("Audio Track", "🎵"),
    TEXT("Cyber Titles", "🔤"),
    EFFECT("Quantum FX", "⚡")
}

enum class VideoFilter(val displayName: String, val description: String) {
    NONE("Normal Raw", "Standard uncolored stream"),
    CYBER_NEON("Cyber Neon", "Intense cyan & magenta contrast with glowing highlights"),
    HOLO_SCANLINES("Holo Scanlines", "Holographic CRT raster lines & chromatic shift"),
    QUANTUM_GLITCH("Quantum Glitch", "Digital pixel offset & cyber interference"),
    MATRIX_HUD("Matrix HUD", "Digital matrix grid & cyber telemetry readout"),
    SYNTHWAVE_GLOW("Synthwave Glow", "Warm 80s synth sunset orange and deep violet"),
    THERMAL_VISION("Thermal Vision", "Infrared heat-map color spectrum"),
    VINTAGE_2020("Vintage 2020s", "Pre-quantum nostalgic digital video look")
}

enum class TransitionType(val title: String) {
    NONE("Cut"),
    CYBER_SLICE("Cyber Slice"),
    WARP_DISSOLVE("Warp Dissolve"),
    NEON_FLASH("Neon Flash"),
    QUANTUM_PIXEL("Quantum Pixel")
}

enum class AspectRatio(val displayName: String, val ratioWidth: Float, val ratioHeight: Float) {
    RATIO_16_9("16:9 Cinema", 16f, 9f),
    RATIO_9_16("9:16 Holo-Reel", 9f, 16f),
    RATIO_1_1("1:1 Quantum", 1f, 1f),
    RATIO_21_9("21:9 Ultra Cyber", 21f, 9f)
}

data class Clip(
    val id: String = java.util.UUID.randomUUID().toString(),
    val uri: Uri = Uri.EMPTY,
    val startMs: Long = 0L,
    val endMs: Long = 0L,
    val speed: Float = 1f,
    val volume: Float = 1f,
    val durationMs: Long = (endMs - startMs).coerceAtLeast(0L),
    val title: String = "Clip",
    val sourceUri: String? = if (uri != Uri.EMPTY) uri.toString() else null,
    val trackType: TrackType = TrackType.VIDEO,
    val startTimeMs: Long = startMs,
    val sourceDurationMs: Long = if (endMs > startMs) endMs - startMs else durationMs,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val filter: VideoFilter = VideoFilter.NONE,
    val filterIntensity: Float = 0.85f,
    val textOverlay: String? = null,
    val accentColorHex: String = "#00F0FF",
    val hologramDepth: Float = 0.5f,
    val aiTags: List<String> = emptyList(),
    val transitionIn: TransitionType = TransitionType.NONE
) {
    val endTimeMs: Long get() = (if (startTimeMs > 0L) startTimeMs else startMs) + durationMs

    constructor(
        id: String = java.util.UUID.randomUUID().toString(),
        title: String,
        sourceUri: String? = null,
        trackType: TrackType = TrackType.VIDEO,
        startTimeMs: Long = 0L,
        durationMs: Long = 0L,
        sourceDurationMs: Long = durationMs,
        trimStartMs: Long = 0L,
        trimEndMs: Long = 0L,
        speed: Float = 1f,
        volume: Float = 1f,
        filter: VideoFilter = VideoFilter.NONE,
        filterIntensity: Float = 0.85f,
        textOverlay: String? = null,
        accentColorHex: String = "#00F0FF",
        hologramDepth: Float = 0.5f,
        aiTags: List<String> = emptyList(),
        transitionIn: TransitionType = TransitionType.NONE
    ) : this(
        id = id,
        uri = if (!sourceUri.isNullOrEmpty()) Uri.parse(sourceUri) else Uri.EMPTY,
        startMs = startTimeMs,
        endMs = startTimeMs + durationMs,
        speed = speed,
        volume = volume,
        durationMs = durationMs,
        title = title,
        sourceUri = sourceUri,
        trackType = trackType,
        startTimeMs = startTimeMs,
        sourceDurationMs = sourceDurationMs,
        trimStartMs = trimStartMs,
        trimEndMs = trimEndMs,
        filter = filter,
        filterIntensity = filterIntensity,
        textOverlay = textOverlay,
        accentColorHex = accentColorHex,
        hologramDepth = hologramDepth,
        aiTags = aiTags,
        transitionIn = transitionIn
    )
}

enum class TextPreset(val displayName: String, val badge: String) {
    NONE("Classic White", "⚪"),
    CYBER_NEON("Cyber Neon", "🌌"),
    QUANTUM_GLITCH("Quantum Glitch", "⚡"),
    GOLDEN_METALLIC("Golden Luxury", "👑"),
    RETRO_SYNTHWAVE("Synthwave Sunset", "🌆"),
    HOLO_OUTLINE("Holo Outline", "🔲"),
    DEEP_SHADOW("Cinematic 3D", "🎬"),
    EMERALD_MATRIX("Matrix Phosphor", "🟩"),
    FIRE_BLAZE("Fiery Blaze", "🔥"),
    CHROME_FROST("Chrome Frost", "❄️"),
    MINIMAL_CAPTION("Caption Pill", "💬")
}

enum class TextFontFamily(val displayName: String) {
    SANS_SERIF("Modern Sans"),
    SERIF("Cinematic Serif"),
    MONOSPACE("Cyber Mono"),
    CURSIVE("Creative Script"),
    ARABIC_URDU("Urdu / Arabic RTL")
}

enum class TextAnimation(val displayName: String, val icon: String) {
    NONE("Static", "⏹️"),
    FADE("Fade", "🌫️"),
    POP("Spring Pop", "💥"),
    SLIDE("Slide", "➡️"),
    TYPEWRITER("Typewriter", "⌨️"),
    BOUNCE("Elastic Bounce", "🏀")
}

fun isRtlText(text: String): Boolean {
    return text.any { char ->
        val code = char.code
        (code in 0x0600..0x06FF) ||
        (code in 0x0750..0x077F) ||
        (code in 0x08A0..0x08FF) ||
        (code in 0xFB50..0xFDFF) ||
        (code in 0xFE70..0xFEFF)
    }
}

data class TextOverlay(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val startMs: Long = 0L,
    val endMs: Long = 5000L,
    val x: Float = 0f,
    val y: Float = 0f,
    val sizeSp: Float = 28f,
    val color: Int = 0xFFFFFFFF.toInt(),
    val preset: TextPreset = TextPreset.CYBER_NEON,
    val fontFamily: TextFontFamily = if (isRtlText(text)) TextFontFamily.ARABIC_URDU else TextFontFamily.SANS_SERIF,
    val isBold: Boolean = true,
    val isItalic: Boolean = false,
    val isRtl: Boolean = isRtlText(text),
    val animIn: TextAnimation = TextAnimation.POP,
    val animOut: TextAnimation = TextAnimation.FADE,
    val animDurationMs: Long = 600L,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f
)

data class TimelineTrack(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: TrackType,
    val isMuted: Boolean = false,
    val isLocked: Boolean = false,
    val clips: List<Clip> = emptyList()
)

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    val fps: Int = 60,
    val tracks: List<TimelineTrack> = emptyList(),
    val durationMs: Long = 45000L,
    val updatedAt: Long = System.currentTimeMillis(),
    val aiSummary: String? = null
)

data class ExportConfig(
    val resolution: String = "4K Ultra UHD (3840x2160)",
    val fps: Int = 60,
    val codec: String = "AV1 Neural (2050)",
    val bitrateMbps: Int = 50,
    val applyHoloScanlines: Boolean = true,
    val audioMastering: String = "Spatial Cyber Audio 7.1"
)

enum class OverlayMask(val displayName: String, val icon: String) {
    NONE("Free / No Mask", "⬜"),
    RECTANGLE("Rounded Rect", "🔲"),
    CIRCLE("Circle Mask", "⚪"),
    HEART("Heart Mask", "❤️")
}

data class OverlayClip(
    val uri: Uri = Uri.EMPTY,
    val startMs: Long = 0L,
    val durationMs: Long = 5000L,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val scale: Float = 1.0f,
    val rotation: Float = 0f,
    val opacity: Float = 1.0f,
    val mask: OverlayMask = OverlayMask.NONE,
    val isChromaKeyEnabled: Boolean = false,
    val chromaKeyColorHex: String = "#00FF00",
    val chromaKeyIntensity: Float = 0.5f
)
