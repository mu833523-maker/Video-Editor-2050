package com.ve2050.editor.ai

import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object GeminiService {

    private val API_KEY: String = try {
        val key = com.example.BuildConfig.GEMINI_API_KEY
        if (key.isNotBlank() && key != "MY_GEMINI_API_KEY") key else "YOUR_GEMINI_API_KEY"
    } catch (_: Exception) {
        "YOUR_GEMINI_API_KEY"
    }

    private val model by lazy {
        GenerativeModel(
            modelName = "gemini-2.5-flash",
            apiKey = API_KEY
        )
    }

    suspend fun generateCaption(prompt: String): String = withContext(Dispatchers.IO) {
        try {
            if (API_KEY == "YOUR_GEMINI_API_KEY" || API_KEY.isBlank()) {
                "2050 Neural AI: Kinetic rhythm detected. Suggest 12-frame quantum glitch on beat drops and cyan-magenta color grade."
            } else {
                model.generateContent(prompt).text ?: "No response"
            }
        } catch (e: Exception) {
            "2050 AI Suggestion: ${e.message?.take(80) ?: "Dynamic pacing and neon color grade applied"}"
        }
    }

    suspend fun suggestEditPlan(videoDesc: String): String =
        generateCaption("You are a video editor AI. Suggest a pro edit plan for: $videoDesc")
}
