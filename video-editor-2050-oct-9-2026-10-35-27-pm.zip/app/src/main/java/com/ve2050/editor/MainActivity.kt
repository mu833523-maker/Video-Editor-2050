package com.ve2050.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ve2050.editor.auth.AuthService
import com.ve2050.editor.ui.EditorScreen
import com.ve2050.editor.ui.HomeScreen
import com.ve2050.editor.ui.theme.VE2050Theme

open class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AuthService.isFirebaseReady(this)
        setContent {
            VE2050Theme {
                val nav = rememberNavController()
                NavHost(
                    navController = nav,
                    startDestination = "home",
                    enterTransition = {
                        fadeIn(animationSpec = tween(250)) +
                            slideIntoContainer(
                                towards = AnimatedContentTransitionScope.SlideDirection.Start,
                                animationSpec = tween(250)
                            )
                    },
                    exitTransition = {
                        fadeOut(animationSpec = tween(200))
                    },
                    popEnterTransition = {
                        fadeIn(animationSpec = tween(200))
                    },
                    popExitTransition = {
                        fadeOut(animationSpec = tween(250)) +
                            slideOutOfContainer(
                                towards = AnimatedContentTransitionScope.SlideDirection.End,
                                animationSpec = tween(250)
                            )
                    }
                ) {
                    composable("home") {
                        HomeScreen(onNewProject = { nav.navigate("editor") })
                    }
                    composable("editor") {
                        EditorScreen(onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
