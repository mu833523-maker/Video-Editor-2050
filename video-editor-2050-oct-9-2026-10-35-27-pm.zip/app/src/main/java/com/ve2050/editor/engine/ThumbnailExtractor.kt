package com.ve2050.editor.engine

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ThumbnailExtractor {
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = (maxMemory / 8).coerceAtLeast(1024 * 8) // ~8MB minimum

    private val memoryCache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
    }

    private fun buildKey(uri: Uri, timeUs: Long): String {
        return "${uri}_${timeUs / 500_000}" // Quantize by 0.5s to maximize cache hits
    }

    fun getMemoryCached(uri: Uri, timeUs: Long): Bitmap? {
        if (uri == Uri.EMPTY) return null
        return memoryCache.get(buildKey(uri, timeUs))
    }

    suspend fun getThumbnail(context: Context, uri: Uri, timeUs: Long): Bitmap? {
        if (uri == Uri.EMPTY) return null
        val key = buildKey(uri, timeUs)
        val cached = memoryCache.get(key)
        if (cached != null) return cached

        return withContext(Dispatchers.IO) {
            var retriever: MediaMetadataRetriever? = null
            try {
                retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    retriever.getScaledFrameAtTime(
                        timeUs,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                        128,
                        128
                    ) ?: retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                } else {
                    retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                }
                if (bitmap != null) {
                    memoryCache.put(key, bitmap)
                }
                bitmap
            } catch (e: Exception) {
                null
            } finally {
                try {
                    retriever?.release()
                } catch (e: Exception) {
                    // Ignore release errors
                }
            }
        }
    }

    suspend fun extractDurationMs(context: Context, uri: Uri): Long {
        if (uri == Uri.EMPTY) return 4000L
        return withContext(Dispatchers.IO) {
            var retriever: MediaMetadataRetriever? = null
            try {
                retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                val dur = durStr?.toLongOrNull()
                if (dur != null && dur > 500L) dur else 4000L
            } catch (e: Exception) {
                4000L
            } finally {
                try {
                    retriever?.release()
                } catch (e: Exception) {
                    // Ignore release errors
                }
            }
        }
    }
}
