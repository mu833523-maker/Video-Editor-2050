package com.ve2050.editor.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ve2050.editor.auth.GoogleSignInSection
import com.ve2050.editor.engine.EngineHolder
import com.ve2050.editor.engine.VideoEngine
import com.ve2050.editor.model.AspectRatio
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.Project
import com.ve2050.editor.model.TimelineTrack
import com.ve2050.editor.model.TrackType
import com.ve2050.editor.model.VideoFilter
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(onNewProject: () -> Unit) {
    var showTemplatesSheet by remember { mutableStateOf(false) }

    // Pulsing cyber glow animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowScale"
    )

    // Moving Cyber Scanline Animation
    val scanlineOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scanline"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF06060A), Color(0xFF0F0B1A), Color(0xFF06060A))
                )
            )
    ) {
        // Decorative Subtle Cyber Grid & Animated Beam
        Canvas(modifier = Modifier.fillMaxSize()) {
            val gridStep = 40.dp.toPx()
            val yOffset = scanlineOffset % size.height
            // Horizontal subtle line
            drawLine(
                color = Color(0x1800E5FF),
                start = Offset(0f, yOffset),
                end = Offset(size.width, yOffset),
                strokeWidth = 2f
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            // 1. Top Bar: Branding + Telemetry + Google Sign-In
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF00E5FF), Color(0xFF7B2CBF))
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "VE 2050",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 2.sp,
                                color = Color.White
                            )
                            Spacer(Modifier.width(6.dp))
                            Surface(
                                color = Color(0xFF00FF88).copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "PRO",
                                    color = Color(0xFF00FF88),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "NEURAL VIDEO SUITE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = Color(0xFF00E5FF)
                        )
                    }
                }

                GoogleSignInSection()
            }

            Spacer(Modifier.height(14.dp))

            // 2. Hardware Engine Telemetry HUD
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF101018),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1C1C28))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00FF88))
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "H.264 / AAC 60FPS",
                            color = Color(0xFFCCCCCC),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Text(
                        text = "CAPCUT SPEED ENGINE · READY",
                        color = Color(0xFF00E5FF),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            // 3. Hero "NEW PROJECT" Card (CapCut style)
            Card(
                onClick = onNewProject,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(134.dp),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF00E5FF), Color(0xFF9D4EDD), Color(0xFFFF007F))
                            )
                        )
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Surface(
                                color = Color.Black.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "⚡ QUANTUM TIMELINE",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.2.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "New Project",
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 0.5.sp
                            )
                            Text(
                                text = "Multi-clip · Music · Filters · Speedramps",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.95f)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(58.dp)
                                .scale(pulseGlow)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.25f))
                                .border(2.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Create",
                                tint = Color.White,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))

            // 4. Quick Studio Tools Row (CapCut Feature Icons)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                QuickToolItem(
                    icon = Icons.Default.AutoAwesome,
                    label = "AI Script",
                    badgeColor = Color(0xFF00E5FF),
                    onClick = onNewProject
                )
                QuickToolItem(
                    icon = Icons.Default.DashboardCustomize,
                    label = "Templates",
                    badgeColor = Color(0xFF9D4EDD),
                    onClick = { showTemplatesSheet = true }
                )
                QuickToolItem(
                    icon = Icons.Default.Speed,
                    label = "Velocity FX",
                    badgeColor = Color(0xFFFF007F),
                    onClick = onNewProject
                )
                QuickToolItem(
                    icon = Icons.Default.MusicNote,
                    label = "Beat Sync",
                    badgeColor = Color(0xFF00FF88),
                    onClick = onNewProject
                )
            }

            Spacer(Modifier.height(22.dp))

            // 5. Projects / Drafts Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Recent Drafts",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Templates ›",
                    fontSize = 12.sp,
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { showTemplatesSheet = true }
                )
            }

            Spacer(Modifier.height(12.dp))

            // Drafts List / Project Presets
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    DraftProjectCard(
                        title = "Cyberpunk 2050 Reel",
                        duration = "00:24",
                        clipsCount = 4,
                        ratio = "9:16",
                        accentColor = Color(0xFF00E5FF),
                        onClick = onNewProject
                    )
                }
                item {
                    DraftProjectCard(
                        title = "Synthwave Horizon Edit",
                        duration = "01:12",
                        clipsCount = 6,
                        ratio = "16:9",
                        accentColor = Color(0xFF9D4EDD),
                        onClick = onNewProject
                    )
                }
                item {
                    DraftProjectCard(
                        title = "Thermal Matrix Beat",
                        duration = "00:45",
                        clipsCount = 3,
                        ratio = "1:1",
                        accentColor = Color(0xFFFF007F),
                        onClick = onNewProject
                    )
                }
            }
        }
    }

    // Templates Bottom Sheet (CapCut Presets)
    if (showTemplatesSheet) {
        ModalBottomSheet(
            onDismissRequest = { showTemplatesSheet = false },
            containerColor = Color(0xFF121218)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "2050 Neural Templates",
                            color = Color(0xFF00E5FF),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "One-tap presets with beat sync & quantum color grading",
                            color = Color(0xFF888888),
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = { showTemplatesSheet = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }

                Spacer(Modifier.height(16.dp))

                val templates = listOf(
                    Triple("Cyberpunk Tokyo 2088", "Neon Glitch · 140 BPM · 16:9", VideoFilter.CYBER_NEON),
                    Triple("Mars Orbital Colony", "Infrared Thermal Scan · 21:9", VideoFilter.THERMAL_VISION),
                    Triple("Quantum Speedramp", "Holo-Reel Action · 120 FPS · 9:16", VideoFilter.QUANTUM_GLITCH),
                    Triple("Synthwave Horizon", "Sunset Retro Glow · 1:1", VideoFilter.SYNTHWAVE_GLOW)
                )

                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(templates) { (title, subtitle, filter) ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E26)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C2C3A)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showTemplatesSheet = false
                                    onNewProject()
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF282836)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = Color(0xFF00E5FF),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(subtitle, color = Color(0xFF888888), fontSize = 11.sp)
                                    }
                                }
                                Surface(
                                    color = Color(0xFF00E5FF).copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "USE",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickToolItem(
    icon: ImageVector,
    label: String,
    badgeColor: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF161622))
                .border(1.dp, Color(0xFF28283C), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = badgeColor,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFFCCCCCC)
        )
    }
}

@Composable
private fun DraftProjectCard(
    title: String,
    duration: String,
    clipsCount: Int,
    ratio: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF14141E)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242436))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(width = 68.dp, height = 48.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1E1E2C))
                    .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Movie,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
                Surface(
                    color = Color.Black.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(4.dp)
                ) {
                    Text(
                        text = ratio,
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "$clipsCount clips · $duration",
                        color = Color(0xFF888899),
                        fontSize = 11.sp
                    )
                }
            }

            IconButton(onClick = onClick) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Draft",
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
