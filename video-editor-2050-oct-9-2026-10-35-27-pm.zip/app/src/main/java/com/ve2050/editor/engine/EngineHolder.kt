package com.ve2050.editor.engine

import androidx.media3.common.util.UnstableApi
import com.ve2050.editor.ai.GeminiService
import kotlinx.coroutines.CoroutineScope

@UnstableApi
object EngineHolder {
    var videoEngine: VideoEngine? = null
    val exportEngine: ExportEngine get() = ExportEngine
    val geminiService: GeminiService get() = GeminiService

    fun getOrCreateVideoEngine(scope: CoroutineScope): VideoEngine {
        val current = videoEngine
        if (current != null) return current
        val created = VideoEngine(scope)
        videoEngine = created
        return created
    }
}
