package com.ve2050.editor.engine

import com.ve2050.editor.model.AspectRatio
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.Project
import com.ve2050.editor.model.TimelineTrack
import com.ve2050.editor.model.TrackType
import com.ve2050.editor.model.TransitionType
import com.ve2050.editor.model.VideoFilter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

class VideoEngine(private val scope: CoroutineScope) {

    private val _currentProject = MutableStateFlow(createDefaultProject())
    val currentProject: StateFlow<Project> = _currentProject.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentPositionMs = MutableStateFlow(0L)
    val currentPositionMs: StateFlow<Long> = _currentPositionMs.asStateFlow()

    private val _isLooping = MutableStateFlow(true)
    val isLooping: StateFlow<Boolean> = _isLooping.asStateFlow()

    private val _selectedClipId = MutableStateFlow<String?>(null)
    val selectedClipId: StateFlow<String?> = _selectedClipId.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _activeGlobalFilter = MutableStateFlow(VideoFilter.NONE)
    val activeGlobalFilter: StateFlow<VideoFilter> = _activeGlobalFilter.asStateFlow()

    private var playbackJob: Job? = null

    init {
        // Select first clip by default
        _currentProject.value.tracks.firstOrNull { it.type == TrackType.VIDEO }?.clips?.firstOrNull()?.let {
            _selectedClipId.value = it.id
        }
    }

    fun play() {
        if (_isPlaying.value) return
        _isPlaying.value = true
        startTicker()
    }

    fun pause() {
        _isPlaying.value = false
        playbackJob?.cancel()
        playbackJob = null
    }

    fun togglePlay() {
        if (_isPlaying.value) pause() else play()
    }

    fun seekTo(positionMs: Long) {
        val maxDuration = _currentProject.value.durationMs
        _currentPositionMs.value = positionMs.coerceIn(0L, maxDuration)
    }

    fun stepFrame(deltaMs: Long) {
        val target = _currentPositionMs.value + deltaMs
        seekTo(target)
    }

    fun toggleLoop() {
        _isLooping.value = !_isLooping.value
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
    }

    fun selectClip(clipId: String?) {
        _selectedClipId.value = clipId
    }

    fun setGlobalFilter(filter: VideoFilter) {
        _activeGlobalFilter.value = filter
    }

    fun setAspectRatio(aspectRatio: AspectRatio) {
        val proj = _currentProject.value
        _currentProject.value = proj.copy(aspectRatio = aspectRatio, updatedAt = System.currentTimeMillis())
    }

    fun splitClipAtPlayhead(clipId: String? = _selectedClipId.value) {
        val playhead = _currentPositionMs.value
        val project = _currentProject.value
        var targetClip: Clip? = null
        var targetTrackId: String? = null

        // Find candidate clip
        for (track in project.tracks) {
            val found = if (clipId != null) {
                track.clips.firstOrNull { it.id == clipId }
            } else {
                track.clips.firstOrNull { playhead > it.startTimeMs && playhead < it.endTimeMs }
            }
            if (found != null && playhead > found.startTimeMs && playhead < found.endTimeMs) {
                targetClip = found
                targetTrackId = track.id
                break
            }
        }

        if (targetClip == null || targetTrackId == null) return

        val splitPointInClip = playhead - targetClip.startTimeMs
        if (splitPointInClip < 200 || (targetClip.durationMs - splitPointInClip) < 200) {
            return // Prevent sub-frame splits
        }

        val firstClip = targetClip.copy(
            durationMs = splitPointInClip,
            trimEndMs = targetClip.trimEndMs + (targetClip.durationMs - splitPointInClip)
        )

        val secondClip = targetClip.copy(
            id = UUID.randomUUID().toString(),
            title = "${targetClip.title} (Part 2)",
            startTimeMs = playhead,
            durationMs = targetClip.durationMs - splitPointInClip,
            trimStartMs = targetClip.trimStartMs + splitPointInClip
        )

        val updatedTracks = project.tracks.map { track ->
            if (track.id == targetTrackId) {
                val newClips = track.clips.flatMap { c ->
                    if (c.id == targetClip.id) listOf(firstClip, secondClip) else listOf(c)
                }
                track.copy(clips = newClips)
            } else {
                track
            }
        }

        _currentProject.value = project.copy(tracks = updatedTracks, updatedAt = System.currentTimeMillis())
        _selectedClipId.value = secondClip.id
    }

    fun deleteClip(clipId: String) {
        val project = _currentProject.value
        val updatedTracks = project.tracks.map { track ->
            track.copy(clips = track.clips.filter { it.id != clipId })
        }
        _currentProject.value = project.copy(tracks = updatedTracks, updatedAt = System.currentTimeMillis())
        if (_selectedClipId.value == clipId) {
            _selectedClipId.value = null
        }
    }

    fun duplicateClip(clipId: String) {
        val project = _currentProject.value
        val updatedTracks = project.tracks.map { track ->
            val clipToDup = track.clips.firstOrNull { it.id == clipId }
            if (clipToDup != null) {
                val nextStart = clipToDup.endTimeMs
                val duplicated = clipToDup.copy(
                    id = UUID.randomUUID().toString(),
                    title = "${clipToDup.title} (Copy)",
                    startTimeMs = nextStart
                )
                track.copy(clips = (track.clips + duplicated).sortedBy { it.startTimeMs })
            } else {
                track
            }
        }
        recalculateDuration(updatedTracks)
    }

    fun updateClip(clip: Clip) {
        val project = _currentProject.value
        val updatedTracks = project.tracks.map { track ->
            track.copy(clips = track.clips.map { if (it.id == clip.id) clip else it })
        }
        _currentProject.value = project.copy(tracks = updatedTracks, updatedAt = System.currentTimeMillis())
    }

    fun trimClip(clipId: String, newStartTimeMs: Long, newDurationMs: Long) {
        val project = _currentProject.value
        val updatedTracks = project.tracks.map { track ->
            track.copy(clips = track.clips.map { c ->
                if (c.id == clipId) {
                    c.copy(
                        startTimeMs = newStartTimeMs.coerceAtLeast(0L),
                        durationMs = newDurationMs.coerceAtLeast(500L)
                    )
                } else c
            }.sortedBy { it.startTimeMs })
        }
        recalculateDuration(updatedTracks)
    }

    fun setClipSpeed(clipId: String, speed: Float) {
        val project = _currentProject.value
        val updatedTracks = project.tracks.map { track ->
            track.copy(clips = track.clips.map { c ->
                if (c.id == clipId) {
                    val newDur = (c.sourceDurationMs / speed).toLong()
                    c.copy(speed = speed, durationMs = newDur)
                } else c
            })
        }
        recalculateDuration(updatedTracks)
    }

    fun setClipFilter(clipId: String, filter: VideoFilter) {
        val project = _currentProject.value
        val updatedTracks = project.tracks.map { track ->
            track.copy(clips = track.clips.map { if (it.id == clipId) it.copy(filter = filter) else it })
        }
        _currentProject.value = project.copy(tracks = updatedTracks, updatedAt = System.currentTimeMillis())
    }

    fun addMediaClip(
        title: String,
        uri: String?,
        trackType: TrackType = TrackType.VIDEO,
        durationMs: Long = 6000L
    ) {
        val project = _currentProject.value
        val targetTrack = project.tracks.firstOrNull { it.type == trackType }
            ?: project.tracks.first()

        val nextStart = targetTrack.clips.maxOfOrNull { it.endTimeMs } ?: 0L
        val newClip = Clip(
            title = title,
            sourceUri = uri,
            trackType = trackType,
            startTimeMs = nextStart,
            durationMs = durationMs,
            sourceDurationMs = durationMs,
            filter = if (trackType == TrackType.VIDEO) VideoFilter.CYBER_NEON else VideoFilter.NONE,
            accentColorHex = when (trackType) {
                TrackType.VIDEO -> "#00F0FF"
                TrackType.OVERLAY -> "#FF007F"
                TrackType.AUDIO -> "#00FF88"
                TrackType.TEXT -> "#FFB800"
                TrackType.EFFECT -> "#9D4EDD"
            }
        )

        val updatedTracks = project.tracks.map { t ->
            if (t.id == targetTrack.id) t.copy(clips = t.clips + newClip) else t
        }
        recalculateDuration(updatedTracks)
        _selectedClipId.value = newClip.id
    }

    fun addTextOverlay(text: String, durationMs: Long = 5000L) {
        val project = _currentProject.value
        var textTrack = project.tracks.firstOrNull { it.type == TrackType.TEXT }
        val newTracks = if (textTrack == null) {
            val created = TimelineTrack(name = "Cyber Titles", type = TrackType.TEXT)
            textTrack = created
            project.tracks + created
        } else project.tracks

        val playhead = _currentPositionMs.value
        val clip = Clip(
            title = text.take(16),
            trackType = TrackType.TEXT,
            startTimeMs = playhead,
            durationMs = durationMs,
            textOverlay = text,
            accentColorHex = "#00FF88"
        )

        val finalTracks = newTracks.map { t ->
            if (t.id == textTrack.id) t.copy(clips = t.clips + clip) else t
        }
        recalculateDuration(finalTracks)
        _selectedClipId.value = clip.id
    }

    fun loadProject(project: Project) {
        pause()
        _currentProject.value = project
        _currentPositionMs.value = 0L
        _selectedClipId.value = project.tracks.firstOrNull { it.type == TrackType.VIDEO }?.clips?.firstOrNull()?.id
    }

    private fun recalculateDuration(tracks: List<TimelineTrack>) {
        val maxEnd = tracks.flatMap { it.clips }.maxOfOrNull { it.endTimeMs } ?: 30000L
        val newTotal = maxEnd.coerceAtLeast(15000L)
        _currentProject.value = _currentProject.value.copy(
            tracks = tracks,
            durationMs = newTotal,
            updatedAt = System.currentTimeMillis()
        )
    }

    private fun startTicker() {
        playbackJob?.cancel()
        playbackJob = scope.launch(Dispatchers.Default) {
            val intervalMs = 33L // ~30-60fps smooth scrubber update
            while (isActive && _isPlaying.value) {
                delay(intervalMs)
                val step = (intervalMs * _playbackSpeed.value).toLong()
                val next = _currentPositionMs.value + step
                val total = _currentProject.value.durationMs

                if (next >= total) {
                    if (_isLooping.value) {
                        _currentPositionMs.value = 0L
                    } else {
                        _currentPositionMs.value = total
                        _isPlaying.value = false
                        break
                    }
                } else {
                    _currentPositionMs.value = next
                }
            }
        }
    }

    // Resolves current active clips at playhead
    fun getActiveClipsAtPlayhead(): List<Clip> {
        val pos = _currentPositionMs.value
        return _currentProject.value.tracks
            .filterNot { it.isMuted }
            .flatMap { it.clips }
            .filter { pos >= it.startTimeMs && pos < it.endTimeMs }
    }

    fun getActiveVideoClip(): Clip? {
        val pos = _currentPositionMs.value
        return _currentProject.value.tracks
            .firstOrNull { it.type == TrackType.VIDEO && !it.isMuted }
            ?.clips?.firstOrNull { pos >= it.startTimeMs && pos < it.endTimeMs }
    }

    fun getActiveOverlayClip(): Clip? {
        val pos = _currentPositionMs.value
        return _currentProject.value.tracks
            .firstOrNull { it.type == TrackType.OVERLAY && !it.isMuted }
            ?.clips?.firstOrNull { pos >= it.startTimeMs && pos < it.endTimeMs }
    }

    fun getActiveTextClip(): Clip? {
        val pos = _currentPositionMs.value
        return _currentProject.value.tracks
            .firstOrNull { it.type == TrackType.TEXT && !it.isMuted }
            ?.clips?.firstOrNull { pos >= it.startTimeMs && pos < it.endTimeMs }
    }

    companion object {
        fun createDefaultProject(): Project {
            val videoTrack = TimelineTrack(
                name = "Video Track 1",
                type = TrackType.VIDEO,
                clips = listOf(
                    Clip(
                        id = "c1",
                        title = "Neo-Kyoto Skyway",
                        startTimeMs = 0L,
                        durationMs = 9000L,
                        filter = VideoFilter.CYBER_NEON,
                        accentColorHex = "#00F0FF",
                        aiTags = listOf("Cyberpunk", "City", "Night", "Hovercars")
                    ),
                    Clip(
                        id = "c2",
                        title = "Quantum Core Chamber",
                        startTimeMs = 9000L,
                        durationMs = 11000L,
                        filter = VideoFilter.QUANTUM_GLITCH,
                        accentColorHex = "#9D4EDD",
                        aiTags = listOf("Reactor", "Plasma", "Sci-Fi"),
                        transitionIn = TransitionType.CYBER_SLICE
                    ),
                    Clip(
                        id = "c3",
                        title = "Holographic Neural Drone",
                        startTimeMs = 20000L,
                        durationMs = 12000L,
                        filter = VideoFilter.HOLO_SCANLINES,
                        accentColorHex = "#00F0FF",
                        aiTags = listOf("Drone", "Hologram", "Aerial"),
                        transitionIn = TransitionType.WARP_DISSOLVE
                    ),
                    Clip(
                        id = "c4",
                        title = "Orbital Dawn 2050",
                        startTimeMs = 32000L,
                        durationMs = 13000L,
                        filter = VideoFilter.SYNTHWAVE_GLOW,
                        accentColorHex = "#FF007F",
                        aiTags = listOf("Orbit", "Sunrise", "Space Station"),
                        transitionIn = TransitionType.NEON_FLASH
                    )
                )
            )

            val overlayTrack = TimelineTrack(
                name = "Holo Overlay Track",
                type = TrackType.OVERLAY,
                clips = listOf(
                    Clip(
                        id = "ov1",
                        title = "Cyber Telemetry HUD",
                        startTimeMs = 4000L,
                        durationMs = 8000L,
                        filter = VideoFilter.MATRIX_HUD,
                        accentColorHex = "#00FF88",
                        textOverlay = "SYSTEM: ONLINE // 120 FPS // NEURAL SYNC"
                    ),
                    Clip(
                        id = "ov2",
                        title = "Quantum Interference",
                        startTimeMs = 18000L,
                        durationMs = 6000L,
                        filter = VideoFilter.QUANTUM_GLITCH,
                        accentColorHex = "#FF007F"
                    )
                )
            )

            val audioTrack = TimelineTrack(
                name = "Audio Track 1",
                type = TrackType.AUDIO,
                clips = listOf(
                    Clip(
                        id = "a1",
                        title = "Synthwave Odyssey - Master Track",
                        startTimeMs = 0L,
                        durationMs = 45000L,
                        accentColorHex = "#00D4FF",
                        volume = 0.9f
                    )
                )
            )

            val textTrack = TimelineTrack(
                name = "Cyber Titles",
                type = TrackType.TEXT,
                clips = listOf(
                    Clip(
                        id = "t1",
                        title = "Title Intro",
                        startTimeMs = 1000L,
                        durationMs = 6000L,
                        textOverlay = "PROJECT 2050: THE QUANTUM FRONTIER",
                        accentColorHex = "#FFB800"
                    ),
                    Clip(
                        id = "t2",
                        title = "Location Tag",
                        startTimeMs = 10000L,
                        durationMs = 5000L,
                        textOverlay = "SECTOR 09 - CORE CHAMBER",
                        accentColorHex = "#00F0FF"
                    )
                )
            )

            return Project(
                id = "proj-default-2050",
                title = "Cyberpunk Neo-Kyoto 2050",
                aspectRatio = AspectRatio.RATIO_16_9,
                fps = 60,
                durationMs = 45000L,
                tracks = listOf(videoTrack, overlayTrack, audioTrack, textTrack)
            )
        }
    }
}
