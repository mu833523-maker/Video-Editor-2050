package com.example

class MainActivity : com.ve2050.editor.MainActivity()
