package com.ve2050.editor.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.ve2050.editor.audio.AudioEngine
import com.ve2050.editor.engine.ExportEngine
import com.ve2050.editor.engine.ExportQuality
import com.ve2050.editor.engine.ThumbnailExtractor
import com.ve2050.editor.model.BeatMarker
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.OverlayMask
import com.ve2050.editor.model.ProjectDraft
import com.ve2050.editor.model.ProjectRepository
import com.ve2050.editor.model.SpeedCurvePreset
import com.ve2050.editor.model.TextAnimation
import com.ve2050.editor.model.TextFontFamily
import com.ve2050.editor.model.TextOverlay
import com.ve2050.editor.model.TextPreset
import com.ve2050.editor.model.TransitionType
import com.ve2050.editor.model.VideoFilter
import com.ve2050.editor.model.VoiceEffect
import com.ve2050.editor.model.isRtlText
import com.ve2050.editor.model.TextKeyframe
import com.ve2050.editor.ui.audio.AudioStudioTab
import com.ve2050.editor.ui.audio.VoiceStudioDialog
import com.ve2050.editor.ui.speed.SpeedCurveStudioDialog
import com.ve2050.editor.ui.text.InteractiveTextOverlayView
import com.ve2050.editor.ui.text.TextProStudioDialog
import com.ve2050.editor.engine.ProxyVideoManager
import com.ve2050.editor.ui.adjust.AdjustStudioDialog
import com.ve2050.editor.ui.audio.VoiceoverRecorderDialog
import com.ve2050.editor.ui.stickers.StickersStudioDialog
import com.ve2050.editor.ui.transform.TransformStudioDialog
import com.ve2050.editor.ui.trim.PrecisionTrimDialog
import com.ve2050.editor.ui.volume.VolumeStudioDialog
import com.ve2050.editor.ui.vfx.VfxShaderOverlay
import com.ve2050.editor.ui.vfx.VfxStudioDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.roundToInt

val HeartShape = object : Shape {
    override fun createOutline(
        size: androidx.compose.ui.geometry.Size,
        layoutDirection: androidx.compose.ui.unit.LayoutDirection,
        density: androidx.compose.ui.unit.Density
    ): Outline {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.5f, h * 0.88f)
            cubicTo(w * 0.08f, h * 0.60f, 0f, h * 0.22f, w * 0.25f, h * 0.08f)
            cubicTo(w * 0.42f, 0f, w * 0.5f, h * 0.18f, w * 0.5f, h * 0.24f)
            cubicTo(w * 0.5f, h * 0.18f, w * 0.58f, 0f, w * 0.75f, h * 0.08f)
            cubicTo(w, h * 0.22f, w * 0.92f, h * 0.60f, w * 0.5f, h * 0.88f)
            close()
        }
        return Outline.Generic(path)
    }
}

data class EditorHistoryState(
    val clips: List<Clip>,
    val selectedIndex: Int,
    val textOverlays: List<TextOverlay>,
    val overlayUri: Uri?,
    val overlayStartMs: Long,
    val overlayDurationMs: Long,
    val musicUri: Uri?,
    val musicName: String,
    val voiceEffect: VoiceEffect = VoiceEffect.ORIGINAL,
    val audioPitch: Float = 1.0f,
    val audioSpeed: Float = 1.0f,
    val audioVolume: Float = 1.0f
)

@OptIn(UnstableApi::class)
@Composable
fun EditorScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    var clips by remember { mutableStateOf(listOf<Clip>()) }
    var textOverlays by remember { mutableStateOf(listOf<TextOverlay>()) }
    var selectedTextId by remember { mutableStateOf<String?>(null) }
    var showTextDialog by remember { mutableStateOf(false) }
    var showFilterDialog by remember { mutableStateOf(false) }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showSpeedCurveDialog by remember { mutableStateOf(false) }
    var showTransitionDialog by remember { mutableStateOf(false) }
    var showVolumeDialog by remember { mutableStateOf(false) }
    var showAdjustDialog by remember { mutableStateOf(false) }
    var showTransformDialog by remember { mutableStateOf(false) }
    var showStickersDialog by remember { mutableStateOf(false) }
    var showTrimDialog by remember { mutableStateOf(false) }
    var showVoiceoverRecorderDialog by remember { mutableStateOf(false) }
    var editingTextOverlayId by remember { mutableStateOf<String?>(null) }
    var textInput by remember { mutableStateOf("") }
    var selectedTextPreset by remember { mutableStateOf(TextPreset.CYBER_NEON) }
    var selectedTextFont by remember { mutableStateOf(TextFontFamily.SANS_SERIF) }
    var selectedTextColor by remember { mutableIntStateOf(0xFFFFFFFF.toInt()) }
    var selectedTextSize by remember { mutableFloatStateOf(28f) }
    var isTextBold by remember { mutableStateOf(true) }
    var isTextItalic by remember { mutableStateOf(false) }
    var isTextRtl by remember { mutableStateOf(false) }
    var selectedAnimIn by remember { mutableStateOf(TextAnimation.POP) }
    var selectedAnimOut by remember { mutableStateOf(TextAnimation.FADE) }
    var selectedAnimDurationMs by remember { mutableLongStateOf(600L) }
    var selectedIndex by remember { mutableIntStateOf(0) }
    var isExporting by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableFloatStateOf(0f) }
    var showExportDialog by remember { mutableStateOf(false) }
    var selectedExportQuality by remember { mutableStateOf(ExportQuality.MEDIUM) }
    var selectedExportFps by remember { mutableIntStateOf(30) }
    var exportErrorDialogMessage by remember { mutableStateOf<String?>(null) }
    var exportSuccessDialogMessage by remember { mutableStateOf<String?>(null) }
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var totalDurationMs by remember { mutableLongStateOf(0L) }
    var musicUri by remember { mutableStateOf<Uri?>(null) }
    var musicPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var musicName by remember { mutableStateOf("No music selected") }
    var showVoiceStudioDialog by remember { mutableStateOf(false) }
    var initialAudioStudioTab by remember { mutableStateOf(AudioStudioTab.VOICE_CLONE) }
    var voiceEffect by remember { mutableStateOf(VoiceEffect.ORIGINAL) }
    var audioPitch by remember { mutableFloatStateOf(1.0f) }
    var audioSpeed by remember { mutableFloatStateOf(1.0f) }
    var audioVolume by remember { mutableFloatStateOf(1.0f) }
    var isBeatSyncEnabled by remember { mutableStateOf(false) }
    var beatMarkers by remember { mutableStateOf(listOf<BeatMarker>()) }
    val audioEngine = remember { AudioEngine(context) }

    DisposableEffect(audioEngine) {
        com.ve2050.editor.engine.PlaybackCoordinator.registerAudioEngine(audioEngine)
        onDispose {
            com.ve2050.editor.engine.PlaybackCoordinator.unregisterAudioEngine(audioEngine)
            audioEngine.release()
        }
    }
    var overlayUri by remember { mutableStateOf<Uri?>(null) }
    var overlayPlayer by remember { mutableStateOf<ExoPlayer?>(null) }
    var overlayOffsetX by remember { mutableFloatStateOf(0f) }
    var overlayOffsetY by remember { mutableFloatStateOf(0f) }
    var overlayScale by remember { mutableFloatStateOf(1f) }
    var overlayRotation by remember { mutableFloatStateOf(0f) }
    var overlayOpacity by remember { mutableFloatStateOf(1f) }
    var overlayMask by remember { mutableStateOf(OverlayMask.NONE) }
    var isChromaKeyEnabled by remember { mutableStateOf(false) }
    var chromaKeyIntensity by remember { mutableFloatStateOf(0.6f) }
    var overlayStartMs by remember { mutableLongStateOf(0L) }
    var overlayDurationMs by remember { mutableLongStateOf(6000L) }
    var isOverlaySelected by remember { mutableStateOf(true) }
    var showOverlaySettingsDialog by remember { mutableStateOf(false) }
    var showAiDialog by remember { mutableStateOf(false) }
    var aiPlanText by remember { mutableStateOf<String?>(null) }
    var selectedAspectRatio by remember { mutableStateOf("9:16") }
    var notificationMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val currentDraftId = remember { java.util.UUID.randomUUID().toString() }

    fun persistCurrentDraft() {
        if (clips.isNotEmpty()) {
            val totalMs = clips.sumOf { it.durationMs }
            val dateStr = java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            ProjectRepository.saveProject(
                context,
                ProjectDraft(
                    id = currentDraftId,
                    title = "Project $dateStr",
                    clipsCount = clips.size,
                    durationMs = totalMs,
                    updatedAt = System.currentTimeMillis(),
                    aspectRatio = selectedAspectRatio
                )
            )
        }
    }

    fun stopAndExitEditor() {
        persistCurrentDraft()
        isPlaying = false
        com.ve2050.editor.engine.PlaybackCoordinator.pauseAll()
        player?.pause()
        player?.stop()
        musicPlayer?.pause()
        musicPlayer?.stop()
        overlayPlayer?.pause()
        overlayPlayer?.stop()
        audioEngine.stopSpeaking()
        onBack()
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_STOP) {
                isPlaying = false
                com.ve2050.editor.engine.PlaybackCoordinator.pauseAll()
                player?.pause()
                musicPlayer?.pause()
                overlayPlayer?.pause()
                audioEngine.stopSpeaking()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            com.ve2050.editor.engine.PlaybackCoordinator.pauseAll()
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    BackHandler {
        stopAndExitEditor()
    }

    val undoStack = remember { mutableStateListOf<EditorHistoryState>() }
    val redoStack = remember { mutableStateListOf<EditorHistoryState>() }

    fun showNotice(msg: String) {
        notificationMessage = msg
        scope.launch {
            delay(2400)
            if (notificationMessage == msg) {
                notificationMessage = null
            }
        }
    }

    fun saveSnapshotForUndo() {
        undoStack.add(
            EditorHistoryState(
                clips = clips,
                selectedIndex = selectedIndex,
                textOverlays = textOverlays,
                overlayUri = overlayUri,
                overlayStartMs = overlayStartMs,
                overlayDurationMs = overlayDurationMs,
                musicUri = musicUri,
                musicName = musicName
            )
        )
        if (undoStack.size > 20) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val last = undoStack.removeAt(undoStack.lastIndex)
            redoStack.add(
                EditorHistoryState(
                    clips = clips,
                    selectedIndex = selectedIndex,
                    textOverlays = textOverlays,
                    overlayUri = overlayUri,
                    overlayStartMs = overlayStartMs,
                    overlayDurationMs = overlayDurationMs,
                    musicUri = musicUri,
                    musicName = musicName
                )
            )
            clips = last.clips
            selectedIndex = last.selectedIndex.coerceIn(0, (last.clips.size - 1).coerceAtLeast(0))
            textOverlays = last.textOverlays
            overlayUri = last.overlayUri
            overlayStartMs = last.overlayStartMs
            overlayDurationMs = last.overlayDurationMs
            musicUri = last.musicUri
            musicName = last.musicName
            showNotice("Undo")
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeAt(redoStack.lastIndex)
            undoStack.add(
                EditorHistoryState(
                    clips = clips,
                    selectedIndex = selectedIndex,
                    textOverlays = textOverlays,
                    overlayUri = overlayUri,
                    overlayStartMs = overlayStartMs,
                    overlayDurationMs = overlayDurationMs,
                    musicUri = musicUri,
                    musicName = musicName
                )
            )
            clips = next.clips
            selectedIndex = next.selectedIndex.coerceIn(0, (next.clips.size - 1).coerceAtLeast(0))
            textOverlays = next.textOverlays
            overlayUri = next.overlayUri
            overlayStartMs = next.overlayStartMs
            overlayDurationMs = next.overlayDurationMs
            musicUri = next.musicUri
            musicName = next.musicName
            showNotice("Redo")
        }
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(10)
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            saveSnapshotForUndo()
            scope.launch {
                val newClips = uris.map { uri ->
                    val duration = ThumbnailExtractor.extractDurationMs(context, uri)
                    Clip(
                        uri = uri,
                        startMs = 0L,
                        endMs = duration,
                        durationMs = duration
                    )
                }
                clips = clips + newClips
                persistCurrentDraft()
                showNotice("Added ${uris.size} clip(s) to timeline")
                // Background proxy generation for lag-free preview & scrubbing
                newClips.forEach { clip ->
                    scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                        ProxyVideoManager.generateProxy(context, clip.uri) { proxyUri ->
                            clips = clips.map { if (it.id == clip.id) it.copy(proxyUri = proxyUri) else it }
                        }
                    }
                }
            }
        }
    }

    fun setupMusicPlayer(uri: Uri) {
        musicPlayer?.let { com.ve2050.editor.engine.PlaybackCoordinator.unregisterPlayer(it) }
        musicPlayer?.release()
        val created = ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            playbackParameters = PlaybackParameters(audioSpeed, audioPitch)
            volume = audioVolume.coerceIn(0f, 1f)
            repeatMode = Player.REPEAT_MODE_ALL
            prepare()
            if (isPlaying) {
                seekTo(currentPositionMs)
                play()
            }
        }
        com.ve2050.editor.engine.PlaybackCoordinator.registerPlayer(created)
        musicPlayer = created
    }

    val musicPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            saveSnapshotForUndo()
            musicUri = uri
            musicName = "Imported Audio Track"
            setupMusicPlayer(uri)
            showNotice("Audio loaded & synchronized")
        }
    }

    val overlayPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            saveSnapshotForUndo()
            overlayUri = uri
            overlayOffsetX = 0f
            overlayOffsetY = 0f
            overlayScale = 1f
            overlayRotation = 0f
            overlayOpacity = 1f
            overlayMask = OverlayMask.NONE
            isChromaKeyEnabled = false
            overlayStartMs = currentPositionMs
            overlayDurationMs = if (totalDurationMs > 0) minOf(totalDurationMs - currentPositionMs, 8000L).coerceAtLeast(3000L) else 8000L
            isOverlaySelected = true
            overlayPlayer?.let { com.ve2050.editor.engine.PlaybackCoordinator.unregisterPlayer(it) }
            overlayPlayer?.release()
            val created = ExoPlayer.Builder(context).build().apply {
                setMediaItem(MediaItem.fromUri(uri))
                repeatMode = Player.REPEAT_MODE_ALL
                prepare()
                if (isPlaying) play()
            }
            com.ve2050.editor.engine.PlaybackCoordinator.registerPlayer(created)
            overlayPlayer = created
            showNotice("Overlay video added! Drag, pinch-resize & rotate active")
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            musicPlayer?.let { com.ve2050.editor.engine.PlaybackCoordinator.unregisterPlayer(it) }
            overlayPlayer?.let { com.ve2050.editor.engine.PlaybackCoordinator.unregisterPlayer(it) }
            musicPlayer?.release()
            overlayPlayer?.release()
        }
    }

    // Stable ExoPlayer lifecycle
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
        }
    }

    DisposableEffect(exoPlayer) {
        player = exoPlayer
        com.ve2050.editor.engine.PlaybackCoordinator.registerPlayer(exoPlayer)
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val index = exoPlayer.currentMediaItemIndex
                if (index in clips.indices) {
                    selectedIndex = index
                    val clipSpd = clips[index].speed
                    exoPlayer.playbackParameters = PlaybackParameters(clipSpd * audioSpeed, audioPitch)
                }
            }
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                if (playing) {
                    musicPlayer?.let { mp ->
                        mp.playbackParameters = PlaybackParameters(audioSpeed, audioPitch)
                        mp.volume = audioVolume.coerceIn(0f, 1f)
                        mp.seekTo(currentPositionMs)
                        mp.play()
                    }
                    overlayPlayer?.play()
                } else {
                    musicPlayer?.pause()
                    overlayPlayer?.pause()
                }
            }
        }
        exoPlayer.addListener(listener)
        onDispose {
            isPlaying = false
            com.ve2050.editor.engine.PlaybackCoordinator.unregisterPlayer(exoPlayer)
            com.ve2050.editor.engine.PlaybackCoordinator.pauseAll()
            exoPlayer.pause()
            exoPlayer.stop()
            exoPlayer.removeListener(listener)
            exoPlayer.release()
            musicPlayer?.pause()
            musicPlayer?.stop()
            musicPlayer?.release()
            overlayPlayer?.pause()
            overlayPlayer?.stop()
            overlayPlayer?.release()
            audioEngine.stopSpeaking()
        }
    }

    // Keep playback parameters (speed + voice pitch) always active across video & music
    LaunchedEffect(audioPitch, audioSpeed, selectedIndex, clips) {
        val clipSpd = if (selectedIndex in clips.indices) clips[selectedIndex].speed else 1.0f
        exoPlayer.playbackParameters = PlaybackParameters(clipSpd * audioSpeed, audioPitch)
        musicPlayer?.playbackParameters = PlaybackParameters(audioSpeed, audioPitch)
    }

    // Synchronize media items when clips list changes
    LaunchedEffect(clips) {
        val validClips = clips.filter { it.uri != Uri.EMPTY }
        if (validClips.isNotEmpty()) {
            val mediaItems = validClips.map { MediaItem.fromUri(it.previewUri) }
            val currentIdx = exoPlayer.currentMediaItemIndex
            val currentPos = exoPlayer.currentPosition
            exoPlayer.setMediaItems(mediaItems)
            if (selectedIndex in validClips.indices) {
                exoPlayer.seekTo(selectedIndex, currentPos.coerceAtLeast(0L))
                val clipSpd = validClips[selectedIndex].speed
                exoPlayer.playbackParameters = PlaybackParameters(clipSpd * audioSpeed, audioPitch)
            }
            exoPlayer.prepare()
        } else {
            exoPlayer.clearMediaItems()
        }
    }

    // Playhead progress ticker & total duration
    LaunchedEffect(exoPlayer, isPlaying, clips) {
        while (isActive) {
            val dur = clips.sumOf { if (it.durationMs > 0) it.durationMs else 4000L }
            totalDurationMs = dur
            if (clips.isNotEmpty()) {
                val curItemIndex = exoPlayer.currentMediaItemIndex
                val posInItem = exoPlayer.currentPosition.coerceAtLeast(0L)
                var accumulated = 0L
                for (i in 0 until minOf(curItemIndex, clips.size)) {
                    accumulated += if (clips[i].durationMs > 0) clips[i].durationMs else 4000L
                }
                currentPositionMs = (accumulated + posInItem).coerceIn(0L, dur)
            } else {
                currentPositionMs = 0L
            }
            delay(80)
        }
    }

    LaunchedEffect(selectedIndex) {
        if (selectedIndex in clips.indices) {
            if (exoPlayer.currentMediaItemIndex != selectedIndex) {
                exoPlayer.seekToDefaultPosition(selectedIndex)
            }
            exoPlayer.setPlaybackSpeed(clips[selectedIndex].speed)
        }
    }

    // Synchronize overlay playback position and state with timeline
    LaunchedEffect(currentPositionMs, overlayStartMs, overlayDurationMs, overlayPlayer, isPlaying) {
        val oPlayer = overlayPlayer ?: return@LaunchedEffect
        if (overlayUri != null) {
            val relTime = currentPositionMs - overlayStartMs
            if (relTime in 0L..overlayDurationMs) {
                if (kotlin.math.abs(oPlayer.currentPosition - relTime) > 350L) {
                    oPlayer.seekTo(relTime)
                }
                if (isPlaying && !oPlayer.isPlaying) {
                    oPlayer.play()
                }
            } else {
                if (oPlayer.isPlaying) {
                    oPlayer.pause()
                }
            }
        }
    }

    // Equalizer animation
    val infiniteTransition = rememberInfiniteTransition(label = "eq")
    val eqWave1 by infiniteTransition.animateFloat(
        initialValue = 4f, targetValue = 18f,
        animationSpec = infiniteRepeatable(tween(400, easing = FastOutLinearInEasing), RepeatMode.Reverse), label = "eq1"
    )
    val eqWave2 by infiniteTransition.animateFloat(
        initialValue = 16f, targetValue = 6f,
        animationSpec = infiniteRepeatable(tween(350, easing = LinearOutSlowInEasing), RepeatMode.Reverse), label = "eq2"
    )
    val eqWave3 by infiniteTransition.animateFloat(
        initialValue = 8f, targetValue = 22f,
        animationSpec = infiniteRepeatable(tween(450, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "eq3"
    )

    fun formatTime(ms: Long): String {
        val totalSecs = (ms / 1000).coerceAtLeast(0L)
        val mins = totalSecs / 60
        val secs = totalSecs % 60
        return String.format("%02d:%02d", mins, secs)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0C0C10))
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Pro Header Bar (CapCut style)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Back button with min 48dp touch target
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable(onClick = {
                                stopAndExitEditor()
                            }),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF161622))
                                .border(1.dp, Color(0xFF242434), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(Modifier.width(4.dp))

                    // Aspect Ratio Selector Pill with min 48dp touch height
                    Surface(
                        onClick = {
                            selectedAspectRatio = when (selectedAspectRatio) {
                                "9:16" -> "16:9"
                                "16:9" -> "1:1"
                                "1:1" -> "4:3"
                                else -> "9:16"
                            }
                            showNotice("Aspect Ratio: $selectedAspectRatio")
                        },
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF161622),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF28283C)),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.AspectRatio,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = selectedAspectRatio,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(Modifier.width(4.dp))

                    // Undo Button with min 48dp touch target
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable(enabled = undoStack.isNotEmpty(), onClick = { undo() }),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (undoStack.isNotEmpty()) Color(0xFF161622) else Color(0xFF101018))
                                .border(1.dp, if (undoStack.isNotEmpty()) Color(0xFF242434) else Color(0xFF181822), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Undo,
                                contentDescription = "Undo",
                                tint = if (undoStack.isNotEmpty()) Color(0xFF00E5FF) else Color(0xFF444455),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Redo Button with min 48dp touch target
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable(enabled = redoStack.isNotEmpty(), onClick = { redo() }),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (redoStack.isNotEmpty()) Color(0xFF161622) else Color(0xFF101018))
                                .border(1.dp, if (redoStack.isNotEmpty()) Color(0xFF242434) else Color(0xFF181822), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.Redo,
                                contentDescription = "Redo",
                                tint = if (redoStack.isNotEmpty()) Color(0xFF00E5FF) else Color(0xFF444455),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Export Action Button (Solid Cyan accent, min 48dp height touch target, single line text)
                Button(
                    onClick = {
                        if (clips.isNotEmpty()) {
                            showExportDialog = true
                        } else {
                            showNotice("Add at least 1 video clip to export")
                        }
                    },
                    enabled = clips.isNotEmpty() && !isExporting,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        disabledContainerColor = Color(0xFF1E1E28),
                        contentColor = Color.Black,
                        disabledContentColor = Color(0xFF555566)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .defaultMinSize(minWidth = 104.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        if (isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.Black
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "${(exportProgress * 100).toInt()}%",
                                color = Color.Black,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false
                            )
                        } else {
                            Icon(
                                Icons.Default.FileUpload,
                                contentDescription = null,
                                tint = if (clips.isNotEmpty()) Color.Black else Color(0xFF666677),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                "EXPORT",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp,
                                color = if (clips.isNotEmpty()) Color.Black else Color(0xFF666677),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }

            // 2. Video Preview Monitor (Framed with Aspect Ratio - ~40% screen)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.40f)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF050508))
                    .border(1.dp, Color(0xFF1E1E28), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                val ratioFloat = when (selectedAspectRatio) {
                    "9:16" -> 9f / 16f
                    "16:9" -> 16f / 9f
                    "1:1" -> 1f / 1f
                    "4:3" -> 4f / 3f
                    else -> 9f / 16f
                }

                // Framed Video Canvas conforming dynamically to selected aspect ratio
                Box(
                    modifier = Modifier
                        .fillMaxHeight(0.96f)
                        .aspectRatio(ratioFloat, matchHeightConstraintsFirst = true)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black)
                        .border(1.dp, Color(0xFF28283C), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    val p = player
                    if (p == null) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF14141E)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Movie,
                                    contentDescription = null,
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                            Spacer(Modifier.height(12.dp))
                            Text(
                                "Import clips to start editing",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Tap '+ Add Clip' below to build your timeline",
                                color = Color(0xFF777788),
                                fontSize = 11.sp
                            )
                        }
                    } else {
                        val activeClip = clips.getOrNull(selectedIndex)
                        AndroidView(
                            factory = { ctx ->
                                PlayerView(ctx).apply {
                                    useController = false
                                    resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                                    this.player = p
                                }
                            },
                            update = {
                                it.player = p
                                it.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
                            },
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    if (activeClip != null) {
                                        rotationZ = activeClip.rotationDegrees
                                        scaleX = if (activeClip.isMirrored) -1f else 1f
                                    }
                                }
                        )

                        // Real-time Adjustments (Brightness, Contrast, HD Enhance)
                        if (activeClip != null) {
                            if (activeClip.brightness != 0f) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            if (activeClip.brightness > 0f)
                                                Color.White.copy(alpha = activeClip.brightness.coerceIn(0f, 0.65f))
                                            else
                                                Color.Black.copy(alpha = kotlin.math.abs(activeClip.brightness).coerceIn(0f, 0.65f))
                                        )
                                )
                            }
                            if (activeClip.hdEnhance) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .border(1.2.dp, Color(0x4400E5FF))
                                        .background(Color(0x0800E5FF))
                                )
                            }
                        }
                    }

                // Real-time Video Filter Shader Overlay (Shadi VFX, Rose Petals, Bokeh, 4K HD, etc.)
                val currentClip = clips.getOrNull(selectedIndex)
                if (currentClip != null && currentClip.filter != VideoFilter.NONE) {
                    VfxShaderOverlay(
                        filter = currentClip.filter,
                        intensity = 1.0f,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Floating Tap-To-Play/Pause Overlay
                if (player != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable {
                                if (isPlaying) player?.pause() else player?.play()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (!isPlaying) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.65f))
                                    .border(1.5.dp, Color(0xFF00E5FF), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(38.dp)
                                )
                            }
                        }
                    }

                    // Floating Timecode Badge
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.75f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF28283C)),
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "${formatTime(currentPositionMs)} / ${formatTime(totalDurationMs)}",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    // CapCut Pro Keyframe Diamond Button on Player (when Text overlay is selected)
                    if (selectedTextId != null) {
                        val activeText = textOverlays.find { it.id == selectedTextId }
                        if (activeText != null) {
                            val hasKfHere = activeText.keyframes.any { kotlin.math.abs(it.timeMs - currentPositionMs) < 300L }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (hasKfHere) Color(0xFF00E5FF) else Color(0xDD121522),
                                border = androidx.compose.foundation.BorderStroke(1.2.dp, Color(0xFF00E5FF)),
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(10.dp)
                                    .clickable {
                                        saveSnapshotForUndo()
                                        val existingIdx = activeText.keyframes.indexOfFirst { kotlin.math.abs(it.timeMs - currentPositionMs) < 300L }
                                        val updatedKfs = if (existingIdx >= 0) {
                                            showNotice("♦ Keyframe removed at ${String.format("%.2f", currentPositionMs / 1000f)}s")
                                            activeText.keyframes.filterIndexed { idx, _ -> idx != existingIdx }
                                        } else {
                                            showNotice("♦ Keyframe added at ${String.format("%.2f", currentPositionMs / 1000f)}s")
                                            (activeText.keyframes + TextKeyframe(
                                                timeMs = currentPositionMs,
                                                x = activeText.x,
                                                y = activeText.y,
                                                scale = activeText.scale,
                                                rotation = activeText.rotation,
                                                opacity = activeText.opacity
                                            )).sortedBy { it.timeMs }
                                        }
                                        textOverlays = textOverlays.map { if (it.id == activeText.id) it.copy(keyframes = updatedKfs) else it }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "♦",
                                        color = if (hasKfHere) Color.Black else Color(0xFF00E5FF),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = if (hasKfHere) "- KEYFRAME" else "+ KEYFRAME",
                                        color = if (hasKfHere) Color.Black else Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                // Picture-in-Picture (Overlay) Window with Drag, 2-Finger Resize & Rotate, Masks, Opacity & Chroma Key
                if (overlayUri != null && overlayPlayer != null) {
                    val isOverlayActive = !isPlaying || (currentPositionMs in overlayStartMs..(overlayStartMs + overlayDurationMs))

                    if (isOverlayActive) {
                        val currentMaskShape: Shape = when (overlayMask) {
                            OverlayMask.NONE -> RoundedCornerShape(10.dp)
                            OverlayMask.RECTANGLE -> RoundedCornerShape(26.dp)
                            OverlayMask.CIRCLE -> CircleShape
                            OverlayMask.HEART -> HeartShape
                        }
                        val overlayBoxWidth = if (overlayMask == OverlayMask.CIRCLE || overlayMask == OverlayMask.HEART) 125.dp else 145.dp
                        val overlayBoxHeight = if (overlayMask == OverlayMask.CIRCLE || overlayMask == OverlayMask.HEART) 125.dp else 95.dp

                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .offset { IntOffset(overlayOffsetX.roundToInt(), overlayOffsetY.roundToInt()) }
                                .graphicsLayer(
                                    scaleX = overlayScale,
                                    scaleY = overlayScale,
                                    rotationZ = overlayRotation,
                                    alpha = overlayOpacity
                                )
                                .size(width = overlayBoxWidth, height = overlayBoxHeight)
                                .clip(currentMaskShape)
                                .background(Color.Black)
                                .border(
                                    width = if (isOverlaySelected) 2.dp else 1.2.dp,
                                    color = if (isChromaKeyEnabled) Color(0xFF00FF66) else if (isOverlaySelected) Color(0xFF00E5FF) else Color(0xFF263238),
                                    shape = currentMaskShape
                                )
                                .pointerInput(Unit) {
                                    detectTransformGestures { _, pan, zoom, rotation ->
                                        overlayScale = (overlayScale * zoom).coerceIn(0.25f, 3.5f)
                                        overlayRotation = (overlayRotation + rotation) % 360f
                                        overlayOffsetX += pan.x
                                        overlayOffsetY += pan.y
                                        isOverlaySelected = true
                                    }
                                }
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    PlayerView(ctx).apply {
                                        useController = false
                                        this.player = overlayPlayer
                                    }
                                },
                                update = { it.player = overlayPlayer },
                                modifier = Modifier.fillMaxSize()
                            )

                            // Chroma Key Green-Screen Removal Visual Effect Layer
                            if (isChromaKeyEnabled) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.radialGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    Color(0xFF00FF66).copy(alpha = 0.12f * chromaKeyIntensity)
                                                )
                                            )
                                        )
                                )
                            }

                            // PIP & Rotation/Scale Telemetry Badge
                            Surface(
                                color = if (isChromaKeyEnabled) Color(0xFF005522).copy(alpha = 0.85f) else Color(0xFF00E5FF).copy(alpha = 0.9f),
                                shape = RoundedCornerShape(bottomEnd = 6.dp),
                                modifier = Modifier.align(Alignment.TopStart)
                            ) {
                                Text(
                                    text = if (isChromaKeyEnabled) "KEY" else "PIP",
                                    color = if (isChromaKeyEnabled) Color.White else Color.Black,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }

                            // Quick Overlay Settings Action Gear
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(2.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.75f))
                                    .clickable { showOverlaySettingsDialog = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Tune,
                                    contentDescription = "Overlay Settings",
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(14.dp)
                                )
                            }

                            // Close button to remove overlay
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomEnd)
                                    .padding(2.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.75f))
                                    .clickable {
                                        overlayPlayer?.release()
                                        overlayPlayer = null
                                        overlayUri = null
                                        showNotice("Overlay removed")
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Remove Overlay",
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                            }

                            // Active Rotation & Scale Angle readout badge at bottom-left
                            if (isOverlaySelected) {
                                Surface(
                                    color = Color.Black.copy(alpha = 0.75f),
                                    shape = RoundedCornerShape(topEnd = 6.dp),
                                    modifier = Modifier.align(Alignment.BottomStart)
                                ) {
                                    Text(
                                        text = "${overlayRotation.roundToInt()}°",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Interactive Pro Text Overlays on Video Canvas
                textOverlays.forEach { textOverlay ->
                    val isTextActive = if (isPlaying) {
                        currentPositionMs in textOverlay.startMs..textOverlay.endMs
                    } else {
                        (currentPositionMs in textOverlay.startMs..textOverlay.endMs) || (textOverlay.id == selectedTextId)
                    }
                    if (isTextActive) {
                        InteractiveTextOverlayView(
                            overlay = textOverlay,
                            currentPositionMs = currentPositionMs,
                            isSelected = (textOverlay.id == selectedTextId),
                            onSelect = { selectedTextId = textOverlay.id },
                            onEdit = {
                                editingTextOverlayId = textOverlay.id
                                showTextDialog = true
                            },
                            onDelete = {
                                saveSnapshotForUndo()
                                textOverlays = textOverlays.filter { it.id != textOverlay.id }
                                if (selectedTextId == textOverlay.id) selectedTextId = null
                                showNotice("Text overlay removed")
                            },
                            onTransformChange = { newX, newY, newScale, newRotation ->
                                val kfIdx = textOverlay.keyframes.indexOfFirst {
                                    kotlin.math.abs(it.timeMs - currentPositionMs) < 300L
                                }
                                if (kfIdx >= 0) {
                                    val updatedKfs = textOverlay.keyframes.toMutableList().apply {
                                        this[kfIdx] = this[kfIdx].copy(x = newX, y = newY, scale = newScale, rotation = newRotation)
                                    }
                                    textOverlays = textOverlays.map { if (it.id == textOverlay.id) it.copy(keyframes = updatedKfs) else it }
                                } else {
                                    textOverlays = textOverlays.map { if (it.id == textOverlay.id) it.copy(x = newX, y = newY, scale = newScale, rotation = newRotation) else it }
                                }
                            },
                            onToggleKeyframe = { timeMs ->
                                saveSnapshotForUndo()
                                val existingIdx = textOverlay.keyframes.indexOfFirst { kotlin.math.abs(it.timeMs - timeMs) < 300L }
                                val updatedKfs = if (existingIdx >= 0) {
                                    showNotice("♦ Keyframe removed at ${String.format("%.2f", timeMs / 1000f)}s")
                                    textOverlay.keyframes.filterIndexed { idx, _ -> idx != existingIdx }
                                } else {
                                    showNotice("♦ Keyframe added at ${String.format("%.2f", timeMs / 1000f)}s")
                                    (textOverlay.keyframes + TextKeyframe(
                                        timeMs = timeMs,
                                        x = textOverlay.x,
                                        y = textOverlay.y,
                                        scale = textOverlay.scale,
                                        rotation = textOverlay.rotation,
                                        opacity = textOverlay.opacity
                                    )).sortedBy { it.timeMs }
                                }
                                textOverlays = textOverlays.map { if (it.id == textOverlay.id) it.copy(keyframes = updatedKfs) else it }
                            }
                        )
                    }
                }
                } // End inner aspect ratio Box
            } // End outer Monitor Box

            fun splitClipAtCurrentPlayhead() {
                if (clips.isEmpty()) {
                    showNotice("No clips to split. Tap '+ Add Clip'")
                    return
                }
                var accumulated = 0L
                var targetIndex = -1
                var offsetInClip = 0L

                for (i in clips.indices) {
                    val dur = if (clips[i].durationMs > 0) clips[i].durationMs else 4000L
                    if (currentPositionMs in accumulated..(accumulated + dur)) {
                        targetIndex = i
                        offsetInClip = currentPositionMs - accumulated
                        break
                    }
                    accumulated += dur
                }

                if (targetIndex == -1) {
                    targetIndex = selectedIndex.coerceIn(0, clips.lastIndex)
                    val clipDur = if (clips[targetIndex].durationMs > 0) clips[targetIndex].durationMs else 4000L
                    offsetInClip = (clipDur / 2).coerceAtLeast(500L)
                }

                val clip = clips[targetIndex]
                val clipDur = if (clip.durationMs > 0) clip.durationMs else 4000L

                if (offsetInClip < 300L || offsetInClip > clipDur - 300L) {
                    showNotice("Move playhead inside clip to split")
                    return
                }

                saveSnapshotForUndo()
                val firstClip = clip.copy(
                    id = java.util.UUID.randomUUID().toString(),
                    endMs = clip.startMs + offsetInClip,
                    durationMs = offsetInClip
                )
                val secondClip = clip.copy(
                    id = java.util.UUID.randomUUID().toString(),
                    startMs = clip.startMs + offsetInClip,
                    durationMs = clipDur - offsetInClip,
                    endMs = clip.startMs + clipDur
                )

                val list = clips.toMutableList()
                list[targetIndex] = firstClip
                list.add(targetIndex + 1, secondClip)
                clips = list
                selectedIndex = targetIndex + 1
                showNotice("Split clip at ${String.format("%.1f", currentPositionMs / 1000f)}s")
            }

            // 3. CapCut Pro Multi-Track Timeline (Ruler, Filmstrip, Overlay, Text, Audio, Center Playhead)
            TimelineView(
                clips = clips,
                selectedIndex = selectedIndex,
                currentPositionMs = currentPositionMs,
                totalDurationMs = totalDurationMs,
                isPlaying = isPlaying,
                overlayUri = overlayUri,
                overlayScale = overlayScale,
                overlayStartMs = overlayStartMs,
                overlayDurationMs = overlayDurationMs,
                isOverlaySelected = isOverlaySelected,
                onSplitClip = { splitClipAtCurrentPlayhead() },
                beatMarkers = beatMarkers,
                isBeatSyncEnabled = isBeatSyncEnabled,
                onToggleBeatSync = {
                    isBeatSyncEnabled = !isBeatSyncEnabled
                    if (isBeatSyncEnabled) {
                        val totalDur = if (totalDurationMs > 0) totalDurationMs else clips.sumOf { it.durationMs }
                        beatMarkers = audioEngine.detectBeatsForAudio(maxOf(totalDur, 10000L))
                        showNotice("🎵 Beat Sync ON: Rhythm snap markers active!")
                    } else {
                        showNotice("Beat Sync OFF")
                    }
                },
                onTrimOverlay = { newStart, newDur ->
                    overlayStartMs = newStart
                    overlayDurationMs = newDur
                    showNotice("Overlay trimmed: ${String.format("%.1f", newDur / 1000f)}s")
                },
                onMoveOverlay = { newStart ->
                    overlayStartMs = newStart
                    showNotice("Overlay position: ${String.format("%.1f", newStart / 1000f)}s")
                },
                onSelectOverlay = {
                    isOverlaySelected = true
                    showOverlaySettingsDialog = true
                },
                textOverlays = textOverlays,
                selectedTextOverlayId = selectedTextId,
                onSelectTextOverlay = { id ->
                    selectedTextId = id
                    val target = textOverlays.find { it.id == id }
                    if (target != null) {
                        player?.seekTo(target.startMs)
                        currentPositionMs = target.startMs
                    }
                },
                onTrimTextOverlay = { id, newStart, newEnd ->
                    saveSnapshotForUndo()
                    textOverlays = textOverlays.map { if (it.id == id) it.copy(startMs = newStart, endMs = newEnd) else it }
                },
                onMoveTextOverlay = { id, newStart ->
                    saveSnapshotForUndo()
                    textOverlays = textOverlays.map { if (it.id == id) {
                        val dur = it.endMs - it.startMs
                        it.copy(startMs = newStart, endMs = newStart + dur)
                    } else it }
                },
                musicUri = musicUri,
                musicName = musicName,
                onSeek = { targetMs ->
                    musicPlayer?.seekTo(targetMs)
                    if (clips.isNotEmpty() && player != null) {
                        var accumulated = 0L
                        for (i in clips.indices) {
                            val clipDur = if (clips[i].durationMs > 0) clips[i].durationMs else 4000L
                            if (targetMs <= accumulated + clipDur || i == clips.lastIndex) {
                                val offsetInClip = (targetMs - accumulated).coerceIn(0L, clipDur)
                                if (selectedIndex != i) {
                                    selectedIndex = i
                                }
                                player?.setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC)
                                player?.seekTo(i, offsetInClip)
                                currentPositionMs = targetMs
                                break
                            }
                            accumulated += clipDur
                        }
                    }
                },
                onSelect = { selectedIndex = it },
                onReorder = { fromIndex, toIndex ->
                    if (fromIndex in clips.indices && toIndex in clips.indices && fromIndex != toIndex) {
                        saveSnapshotForUndo()
                        val list = clips.toMutableList()
                        val item = list.removeAt(fromIndex)
                        list.add(toIndex, item)
                        clips = list
                        selectedIndex = toIndex
                        showNotice("Clips reordered")
                    }
                },
                onTrimClip = { index, newStart, newEnd ->
                    if (index in clips.indices) {
                        saveSnapshotForUndo()
                        val old = clips[index]
                        val dur = (newEnd - newStart).coerceAtLeast(800L)
                        val updated = old.copy(
                            startMs = newStart,
                            endMs = newStart + dur,
                            durationMs = dur
                        )
                        clips = clips.toMutableList().apply { set(index, updated) }
                        showNotice("Trimmed clip ${index + 1}: ${String.format("%.1f", dur / 1000f)}s")
                    }
                },
                onDeleteOverlay = {
                    saveSnapshotForUndo()
                    overlayPlayer?.release()
                    overlayPlayer = null
                    overlayUri = null
                    showNotice("Overlay track cleared")
                },
                onDeleteMusic = {
                    saveSnapshotForUndo()
                    musicPlayer?.release()
                    musicPlayer = null
                    musicUri = null
                    musicName = "No music selected"
                    showNotice("Audio track removed")
                },
                onSelectMusic = {
                    showVoiceStudioDialog = true
                },
                onDeleteTextOverlay = { id ->
                    saveSnapshotForUndo()
                    textOverlays = textOverlays.filter { it.id != id }
                    showNotice("Text overlay removed")
                },
                onAddClip = {
                    picker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.35f)
            )

            Spacer(Modifier.height(4.dp))

            // 4. Pro Editing Dock (CapCut Horizontal Category Toolbar)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF101018),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E2C))
            ) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item {
                        ToolButton(
                            icon = Icons.Default.ContentCut,
                            label = "Split",
                            accentColor = Color(0xFF00E5FF),
                            onClick = { splitClipAtCurrentPlayhead() }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.Tune,
                            label = "Trim",
                            accentColor = Color(0xFF00E5FF),
                            onClick = { showTrimDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.Speed,
                            label = "Speed",
                            accentColor = Color(0xFFFFB703),
                            onClick = { showSpeedDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.Timeline,
                            label = "Velocity",
                            accentColor = Color(0xFFFF7700),
                            isHighlighted = true,
                            onClick = { showSpeedCurveDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.VolumeUp,
                            label = "Volume",
                            accentColor = Color(0xFF00FF88),
                            onClick = { showVolumeDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.Delete,
                            label = "Delete",
                            accentColor = Color(0xFFFF3366),
                            onClick = {
                                if (clips.isEmpty()) {
                                    showNotice("No clips to delete")
                                    return@ToolButton
                                }
                                if (selectedIndex in clips.indices) {
                                    saveSnapshotForUndo()
                                    val list = clips.toMutableList()
                                    list.removeAt(selectedIndex)
                                    clips = list
                                    selectedIndex = (selectedIndex - 1).coerceAtLeast(0)
                                    showNotice("Clip deleted")
                                }
                            }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.ContentCopy,
                            label = "Duplicate",
                            accentColor = Color(0xFF7000FF),
                            onClick = {
                                if (clips.isEmpty()) {
                                    showNotice("No clip to duplicate")
                                    return@ToolButton
                                }
                                val clip = clips.getOrNull(selectedIndex)
                                if (clip != null) {
                                    saveSnapshotForUndo()
                                    val dup = clip.copy(id = UUID.randomUUID().toString())
                                    val list = clips.toMutableList()
                                    list.add(selectedIndex + 1, dup)
                                    clips = list
                                    selectedIndex = selectedIndex + 1
                                    showNotice("Clip duplicated")
                                }
                            }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.TextFields,
                            label = "Text",
                            accentColor = Color(0xFF38BDF8),
                            onClick = {
                                editingTextOverlayId = null
                                showTextDialog = true
                            }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.AutoAwesome,
                            label = "Stickers",
                            accentColor = Color(0xFFFF4081),
                            isHighlighted = true,
                            onClick = { showStickersDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.FilterVintage,
                            label = "Filters & VFX",
                            accentColor = Color(0xFFFF007F),
                            onClick = { showFilterDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.SwapHoriz,
                            label = "Transition",
                            accentColor = Color(0xFF00F5D4),
                            onClick = { showTransitionDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.ColorLens,
                            label = "Adjust",
                            accentColor = Color(0xFFFFB703),
                            onClick = { showAdjustDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.Crop,
                            label = "Crop / Ratio",
                            accentColor = Color(0xFF00E5FF),
                            onClick = { showTransformDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.Layers,
                            label = if (overlayUri != null) "Overlay Pro" else "Overlay",
                            accentColor = Color(0xFFB5179E),
                            onClick = {
                                if (overlayUri != null) {
                                    showOverlaySettingsDialog = true
                                } else {
                                    overlayPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                    )
                                }
                            }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.Mic,
                            label = "Voiceover",
                            accentColor = Color(0xFF00FF88),
                            isHighlighted = true,
                            onClick = { showVoiceoverRecorderDialog = true }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.GraphicEq,
                            label = "AI Voice Clone",
                            accentColor = Color(0xFF00E5FF),
                            onClick = {
                                initialAudioStudioTab = AudioStudioTab.VOICE_CLONE
                                showVoiceStudioDialog = true
                            }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.RecordVoiceOver,
                            label = if (musicUri != null) "Voice Studio" else "Audio & TTS",
                            accentColor = Color(0xFF00FF88),
                            onClick = {
                                initialAudioStudioTab = AudioStudioTab.TTS
                                showVoiceStudioDialog = true
                            }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.AutoAwesome,
                            label = "AI Magic",
                            accentColor = Color(0xFF8338EC),
                            onClick = {
                                scope.launch {
                                    showNotice("Generating neural edit plan...")
                                    aiPlanText = com.ve2050.editor.ai.GeminiService.suggestEditPlan(
                                        "Futuristic cyberpunk 2050 video with ${clips.size} clips"
                                    )
                                    showAiDialog = true
                                }
                            }
                        )
                    }
                    item {
                        ToolButton(
                            icon = Icons.Default.Add,
                            label = "Add Clip",
                            accentColor = Color(0xFF00E5FF),
                            onClick = {
                                picker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            }
                        )
                    }
                }
            }
        }

        // Floating In-App Cyber Notification HUD with smooth fade and slide animations
        AnimatedVisibility(
            visible = notificationMessage != null,
            enter = fadeIn(animationSpec = tween(250)) + slideInVertically(animationSpec = tween(250)) { -it },
            exit = fadeOut(animationSpec = tween(200)) + slideOutVertically(animationSpec = tween(200)) { -it },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 54.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF14141E),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.6f)),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E5FF))
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = notificationMessage ?: "",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }

    // Pro VFX & Shadi Filter Studio (Wedding, HD Clarity, Atmosphere, Cyber)
    if (showFilterDialog) {
        val currentClip = clips.getOrNull(selectedIndex)
        VfxStudioDialog(
            currentFilter = currentClip?.filter ?: VideoFilter.NONE,
            currentIntensity = 1.0f,
            onDismiss = { showFilterDialog = false },
            onApplyFilter = { filter, intensity ->
                if (selectedIndex in clips.indices) {
                    saveSnapshotForUndo()
                    val updated = clips[selectedIndex].copy(filter = filter)
                    clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                    showNotice("Applied VFX: ${filter.displayName} (${filter.urduLabel})")
                }
                showFilterDialog = false
            },
            onApplyToAll = { filter, intensity ->
                saveSnapshotForUndo()
                clips = clips.map { it.copy(filter = filter) }
                showNotice("Applied to all clips: ${filter.displayName}")
                showFilterDialog = false
            }
        )
    }

    // Speed Control Dialog (CapCut Smooth 0.1x to 10.0x Slow-Mo / Fast-Motion)
    if (showSpeedDialog) {
        val speeds = listOf(0.1f, 0.2f, 0.5f, 1.0f, 2.0f, 5.0f, 10.0f)
        val currentSpeed = clips.getOrNull(selectedIndex)?.speed ?: 1.0f
        var speedSliderValue by remember { mutableFloatStateOf(currentSpeed) }
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            containerColor = Color(0xFF14141C),
            shape = RoundedCornerShape(16.dp),
            title = {
                Text(
                    "Speed Control (0.1x - 10.0x)",
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Speed: ${String.format("%.2f", speedSliderValue)}x",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            if (speedSliderValue < 1f) "⚡ Smooth Slow Motion" else if (speedSliderValue > 1f) "⏩ Fast Motion" else "Standard 1.0x",
                            color = Color(0xFF00E5FF),
                            fontSize = 11.sp
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Slider(
                        value = speedSliderValue,
                        onValueChange = {
                            speedSliderValue = it
                            val clip = clips.getOrNull(selectedIndex)
                            if (clip != null) {
                                val updated = clip.copy(speed = it)
                                clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                                player?.setPlaybackSpeed(it)
                            }
                        },
                        valueRange = 0.1f..10.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF)
                        )
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("Quick Presets:", color = Color.Gray, fontSize = 11.sp)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(speeds) { spd ->
                            val isSelected = kotlin.math.abs(speedSliderValue - spd) < 0.05f
                            Button(
                                onClick = {
                                    speedSliderValue = spd
                                    val clip = clips.getOrNull(selectedIndex)
                                    if (clip != null) {
                                        saveSnapshotForUndo()
                                        val updated = clip.copy(speed = spd)
                                        clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                                        player?.setPlaybackSpeed(spd)
                                        showNotice("Speed: ${spd}x applied")
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) Color(0xFF00E5FF) else Color(0xFF222230),
                                    contentColor = if (isSelected) Color.Black else Color.White
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Text("${spd}x", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        saveSnapshotForUndo()
                        showSpeedDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    modifier = Modifier.height(44.dp)
                ) {
                    Text("DONE", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // Transition Dialog (CapCut Wipes)
    if (showTransitionDialog) {
        val transitions = TransitionType.values().toList()
        val currentTransition = clips.getOrNull(selectedIndex)?.transitionIn ?: TransitionType.NONE
        AlertDialog(
            onDismissRequest = { showTransitionDialog = false },
            containerColor = Color(0xFF14141C),
            shape = RoundedCornerShape(16.dp),
            title = {
                Text(
                    "Clip Transition Style",
                    color = Color(0xFF00E5FF),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                LazyColumn(modifier = Modifier.fillMaxWidth().height(240.dp)) {
                    items(transitions) { trans ->
                        val isSelected = currentTransition == trans
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .defaultMinSize(minHeight = 48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFF162836) else Color.Transparent)
                                .clickable {
                                    val clip = clips.getOrNull(selectedIndex)
                                    if (clip != null) {
                                        saveSnapshotForUndo()
                                        val updated = clip.copy(transitionIn = trans)
                                        clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                                        showNotice("Transition: ${trans.title}")
                                    }
                                    showTransitionDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                trans.title,
                                color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                            if (isSelected) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showTransitionDialog = false },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("DONE", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // 2027 Velocity Speed Curve Studio Dialog (Gift Feature)
    if (showSpeedCurveDialog) {
        val currentClip = clips.getOrNull(selectedIndex)
        SpeedCurveStudioDialog(
            initialSpeed = currentClip?.speed ?: 1.0f,
            onDismiss = { showSpeedCurveDialog = false },
            onApplySpeedCurve = { preset, averageSpeed ->
                if (selectedIndex in clips.indices) {
                    saveSnapshotForUndo()
                    val old = clips[selectedIndex]
                    val updated = old.copy(speed = averageSpeed)
                    clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                    if (selectedIndex == 0) {
                        player?.setPlaybackSpeed(averageSpeed)
                    }
                    showNotice("⚡ Applied ${preset.title} Velocity Curve (${String.format("%.2f", averageSpeed)}x)")
                }
            }
        )
    }

    // Precision Frame Trim Dialog
    if (showTrimDialog) {
        val currentClip = clips.getOrNull(selectedIndex)
        if (currentClip != null) {
            val clipDur = if (currentClip.durationMs > 0) currentClip.durationMs else 4000L
            PrecisionTrimDialog(
                initialStartMs = currentClip.startMs,
                initialEndMs = currentClip.endMs.takeIf { it > currentClip.startMs } ?: (currentClip.startMs + clipDur),
                maxDurationMs = currentClip.sourceDurationMs.coerceAtLeast(clipDur),
                onDismiss = { showTrimDialog = false },
                onApply = { newStart, newEnd ->
                    saveSnapshotForUndo()
                    val dur = (newEnd - newStart).coerceAtLeast(500L)
                    val updated = currentClip.copy(
                        startMs = newStart,
                        endMs = newEnd,
                        durationMs = dur
                    )
                    clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                    showTrimDialog = false
                    showNotice("Trimmed clip ${selectedIndex + 1}: ${String.format("%.2f", dur / 1000f)}s")
                }
            )
        } else {
            showTrimDialog = false
            showNotice("No clip selected to trim")
        }
    }

    // Clip Volume Dialog (0% - 200%)
    if (showVolumeDialog) {
        val currentClip = clips.getOrNull(selectedIndex)
        if (currentClip != null) {
            VolumeStudioDialog(
                initialVolume = currentClip.volume,
                onDismiss = { showVolumeDialog = false },
                onApply = { newVol ->
                    saveSnapshotForUndo()
                    val updated = currentClip.copy(volume = newVol)
                    clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                    showVolumeDialog = false
                    showNotice("Clip volume: ${(newVol * 100).toInt()}%")
                }
            )
        } else {
            showVolumeDialog = false
            showNotice("No clip selected for volume adjustment")
        }
    }

    // Video Adjustment Studio Dialog (Brightness, Contrast, Saturation, HD Enhance)
    if (showAdjustDialog) {
        val currentClip = clips.getOrNull(selectedIndex)
        if (currentClip != null) {
            AdjustStudioDialog(
                initialBrightness = currentClip.brightness,
                initialContrast = currentClip.contrast,
                initialSaturation = currentClip.saturation,
                initialHdEnhance = currentClip.hdEnhance,
                onDismiss = { showAdjustDialog = false },
                onApply = { b, c, s, hd ->
                    saveSnapshotForUndo()
                    val updated = currentClip.copy(
                        brightness = b,
                        contrast = c,
                        saturation = s,
                        hdEnhance = hd
                    )
                    clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                    showAdjustDialog = false
                    showNotice("Video adjustments applied")
                }
            )
        } else {
            showAdjustDialog = false
            showNotice("No clip selected for adjustment")
        }
    }

    // Transform & Canvas Dialog (Rotate 90°, Mirror, 9:16/16:9/1:1)
    if (showTransformDialog) {
        val currentClip = clips.getOrNull(selectedIndex)
        TransformStudioDialog(
            initialRotation = currentClip?.rotationDegrees ?: 0f,
            initialMirrored = currentClip?.isMirrored ?: false,
            currentAspectRatio = selectedAspectRatio,
            onDismiss = { showTransformDialog = false },
            onApply = { rot, mirror, ratio ->
                saveSnapshotForUndo()
                if (currentClip != null && selectedIndex in clips.indices) {
                    val updated = currentClip.copy(
                        rotationDegrees = rot,
                        isMirrored = mirror
                    )
                    clips = clips.toMutableList().apply { set(selectedIndex, updated) }
                }
                selectedAspectRatio = ratio
                showTransformDialog = false
                showNotice("Transform & Canvas updated: $ratio")
            }
        )
    }

    // Stickers & Badges Studio Dialog
    if (showStickersDialog) {
        StickersStudioDialog(
            currentPlayheadMs = currentPositionMs,
            onDismiss = { showStickersDialog = false },
            onAddSticker = { stickerOverlay ->
                saveSnapshotForUndo()
                textOverlays = textOverlays + stickerOverlay
                selectedTextId = stickerOverlay.id
                showNotice("Sticker added: ${stickerOverlay.text.take(12)}")
            }
        )
    }

    // Voiceover Live Mic Recorder Dialog
    if (showVoiceoverRecorderDialog) {
        VoiceoverRecorderDialog(
            onDismiss = { showVoiceoverRecorderDialog = false },
            onAttachVoiceover = { uri, title ->
                saveSnapshotForUndo()
                musicUri = uri
                musicName = title
                setupMusicPlayer(uri)
                persistCurrentDraft()
                showVoiceoverRecorderDialog = false
                showNotice("Voiceover added to timeline: $title")
            }
        )
    }

    // AI Edit Plan Dialog
    if (showAiDialog) {
        AlertDialog(
            onDismissRequest = { showAiDialog = false },
            containerColor = Color(0xFF14141C),
            shape = RoundedCornerShape(16.dp),
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF00E5FF))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "AI Studio Edit Plan",
                        color = Color(0xFF00E5FF),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            },
            text = {
                Text(
                    aiPlanText ?: "Analyzing timeline and generating pro edit plan...",
                    color = Color.White,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showAiDialog = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("APPLY PLAN", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // CapCut Pro Text Studio Dialog (Urdu, English, Styles, Presets & Keyframes)
    if (showTextDialog) {
        val overlayToEdit = textOverlays.find { it.id == editingTextOverlayId }
        TextProStudioDialog(
            initialOverlay = overlayToEdit,
            currentPlayheadMs = currentPositionMs,
            onDismiss = {
                showTextDialog = false
                editingTextOverlayId = null
            },
            onSave = { updatedOverlay ->
                saveSnapshotForUndo()
                if (overlayToEdit != null) {
                    textOverlays = textOverlays.map { if (it.id == updatedOverlay.id) updatedOverlay else it }
                    showNotice("Text updated: ${updatedOverlay.text.take(15)}")
                } else {
                    textOverlays = textOverlays + updatedOverlay
                    selectedTextId = updatedOverlay.id
                    player?.seekTo(updatedOverlay.startMs)
                    currentPositionMs = updatedOverlay.startMs
                    showNotice("Text added: ${updatedOverlay.text.take(15)}")
                }
                showTextDialog = false
                editingTextOverlayId = null
            },
            onDelete = {
                if (overlayToEdit != null) {
                    saveSnapshotForUndo()
                    textOverlays = textOverlays.filter { it.id != overlayToEdit.id }
                    if (selectedTextId == overlayToEdit.id) selectedTextId = null
                    showNotice("Text overlay removed")
                }
                showTextDialog = false
                editingTextOverlayId = null
            }
        )
    }

    // CapCut Pro Voice & Audio Studio Dialog (TTS, Voice Changer, Mic Record & SFX)
    if (showVoiceStudioDialog) {
        VoiceStudioDialog(
            currentMusicUri = musicUri,
            currentVoiceEffect = voiceEffect,
            currentVolume = audioVolume,
            audioEngine = audioEngine,
            currentVideoUri = clips.firstOrNull()?.uri,
            initialTab = initialAudioStudioTab,
            onDismiss = { showVoiceStudioDialog = false },
            onApplyVoiceEffect = { effect, pitch, speed, volume ->
                saveSnapshotForUndo()
                voiceEffect = effect
                audioPitch = pitch
                audioSpeed = speed
                audioVolume = volume
                val clipSpd = if (selectedIndex in clips.indices) clips[selectedIndex].speed else 1.0f
                exoPlayer.playbackParameters = PlaybackParameters(clipSpd * audioSpeed, audioPitch)
                musicPlayer?.playbackParameters = PlaybackParameters(audioSpeed, audioPitch)
                musicPlayer?.volume = audioVolume.coerceIn(0f, 1f)
                persistCurrentDraft()
                showNotice("Voice effect applied: ${effect.displayName}")
            },
            onAttachAudioUri = { uri, title ->
                saveSnapshotForUndo()
                musicUri = uri
                musicName = title
                setupMusicPlayer(uri)
                persistCurrentDraft()
                showNotice("Audio track added: $title")
            },
            onClearAudio = {
                saveSnapshotForUndo()
                musicPlayer?.release()
                musicPlayer = null
                musicUri = null
                musicName = "No music selected"
                persistCurrentDraft()
                showNotice("Audio track removed")
            },
            onPickMusicFromFile = {
                musicPicker.launch("audio/*")
            }
        )
    }

    // Overlay Pro Studio Dialog (Opacity, Masks, Chroma Key & Transform)
    if (showOverlaySettingsDialog && overlayUri != null) {
        AlertDialog(
            onDismissRequest = { showOverlaySettingsDialog = false },
            containerColor = Color(0xFF14141C),
            shape = RoundedCornerShape(16.dp),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Layers,
                            contentDescription = null,
                            tint = Color(0xFF00E5FF),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Overlay Pro Studio",
                            color = Color(0xFF00E5FF),
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .clickable { showOverlaySettingsDialog = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    // 1. Opacity Slider (CapCut pro slider)
                    Text(
                        "OPACITY (${(overlayOpacity * 100).roundToInt()}%)",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Slider(
                        value = overlayOpacity,
                        onValueChange = { overlayOpacity = it },
                        valueRange = 0.05f..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF),
                            inactiveTrackColor = Color(0xFF1E2832)
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(0.25f, 0.50f, 0.75f, 1.0f).forEach { preset ->
                            FilterChip(
                                selected = (kotlin.math.abs(overlayOpacity - preset) < 0.05f),
                                onClick = { overlayOpacity = preset },
                                label = { Text("${(preset * 100).toInt()}%", fontSize = 11.sp, fontWeight = FontWeight.Medium) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF00E5FF),
                                    selectedLabelColor = Color.Black
                                ),
                                modifier = Modifier.defaultMinSize(minHeight = 40.dp)
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // 2. Mask Shapes (Circle, Rectangle, Heart, Free)
                    Text(
                        "MASK SHAPES",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OverlayMask.values().forEach { mask ->
                            val isSelectedMask = (overlayMask == mask)
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .defaultMinSize(minHeight = 48.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        overlayMask = mask
                                        showNotice("Mask applied: ${mask.displayName}")
                                    },
                                color = if (isSelectedMask) Color(0xFF142432) else Color(0xFF181822),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelectedMask) 1.5.dp else 1.dp,
                                    color = if (isSelectedMask) Color(0xFF00E5FF) else Color(0xFF282838)
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 2.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(mask.icon, fontSize = 20.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        mask.displayName.split(" ").first(),
                                        color = if (isSelectedMask) Color(0xFF00E5FF) else Color(0xFFAAAAAA),
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelectedMask) FontWeight.Bold else FontWeight.Normal,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(18.dp))

                    // 3. Chroma Key (Green Screen Removal)
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF0D1E16),
                        border = androidx.compose.foundation.BorderStroke(
                            width = 1.dp,
                            color = if (isChromaKeyEnabled) Color(0xFF00FF66) else Color(0xFF1A3828)
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("🟢", fontSize = 16.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            "Chroma Key",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            "Green Screen Removal",
                                            color = Color(0xFF70D090),
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                Switch(
                                    checked = isChromaKeyEnabled,
                                    onCheckedChange = {
                                        isChromaKeyEnabled = it
                                        showNotice(if (it) "Chroma Key Enabled (Green Screen Removed)" else "Chroma Key Disabled")
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color(0xFF00FF66),
                                        checkedTrackColor = Color(0xFF005522)
                                    )
                                )
                            }

                            if (isChromaKeyEnabled) {
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    "KEY INTENSITY: ${(chromaKeyIntensity * 100).roundToInt()}%",
                                    color = Color(0xFF90FFB0),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Slider(
                                    value = chromaKeyIntensity,
                                    onValueChange = { chromaKeyIntensity = it },
                                    valueRange = 0.1f..1.0f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color(0xFF00FF66),
                                        activeTrackColor = Color(0xFF00FF66),
                                        inactiveTrackColor = Color(0xFF0A3319)
                                    )
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // 4. Transform Quick Controls
                    Text(
                        "TRANSFORMATION",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                overlayRotation = (overlayRotation + 90f) % 360f
                                showNotice("Rotated 90° (${overlayRotation.roundToInt()}°)")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("+90°", fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                overlayOffsetX = 0f
                                overlayOffsetY = 0f
                                overlayScale = 1f
                                overlayRotation = 0f
                                showNotice("Transform reset")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Reset", fontSize = 11.sp)
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Replace / Change video button
                    OutlinedButton(
                        onClick = {
                            overlayPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFF00E5FF)
                        )
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Change Overlay Video", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showOverlaySettingsDialog = false },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("APPLY", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    // 1. Export Configuration Dialog (Quality & FPS)
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            containerColor = Color(0xFF14141E),
            shape = RoundedCornerShape(20.dp),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00E5FF).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.FileUpload,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Export Video",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable { showExportDialog = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFFAAAAAA),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    // Resolution / Quality Selection
                    Text(
                        "QUALITY / RESOLUTION",
                        color = Color(0xFF888899),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(Modifier.height(8.dp))

                    val qualities = listOf(
                        ExportQuality.MEDIUM,
                        ExportQuality.HIGH,
                        ExportQuality.UHD_4K,
                        ExportQuality.LOW
                    )

                    qualities.forEach { quality ->
                        val isSelected = selectedExportQuality == quality
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) Color(0xFF12242E) else Color(0xFF1A1A26))
                                .border(
                                    1.dp,
                                    if (isSelected) Color(0xFF00E5FF) else Color(0xFF262638),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedExportQuality = quality }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedExportQuality = quality },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = Color(0xFF00E5FF),
                                    unselectedColor = Color(0xFF555566)
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = quality.label,
                                    color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${quality.resolutionText} • ${quality.description}",
                                    color = Color(0xFF888899),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(18.dp))

                    // Frame Rate Selection (FPS: 30 or 60)
                    Text(
                        "FRAME RATE (FPS)",
                        color = Color(0xFF888899),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        listOf(30, 60).forEach { fps ->
                            val isSelected = selectedExportFps == fps
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) Color(0xFF12242E) else Color(0xFF1A1A26))
                                    .border(
                                        1.dp,
                                        if (isSelected) Color(0xFF00E5FF) else Color(0xFF262638),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { selectedExportFps = fps }
                                    .padding(vertical = 12.dp, horizontal = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "$fps FPS",
                                        color = if (isSelected) Color(0xFF00E5FF) else Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = if (fps == 30) "Standard" else "Ultra Smooth",
                                        color = Color(0xFF888899),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Target Location Info
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0E0E18))
                            .border(1.dp, Color(0xFF222230), RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Folder,
                                contentDescription = null,
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    "Save Location",
                                    color = Color(0xFFAAAAAA),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    "Gallery / Movies / VideoEditor2050",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showExportDialog = false
                        isExporting = true
                        exportProgress = 0f
                        showNotice("Starting export (${selectedExportQuality.label} • ${selectedExportFps} FPS)...")
                        ExportEngine.export(
                            context = context,
                            clips = clips,
                            quality = selectedExportQuality,
                            fps = selectedExportFps,
                            textOverlays = textOverlays,
                            musicUri = musicUri,
                            overlayUri = overlayUri,
                            overlayScale = (overlayScale * 0.45f).coerceIn(0.2f, 2.5f),
                            overlayRotation = overlayRotation,
                            overlayStartMs = overlayStartMs,
                            overlayDurationMs = overlayDurationMs,
                            audioPitch = audioPitch,
                            audioSpeed = audioSpeed,
                            voiceEffect = voiceEffect,
                            onProgress = { exportProgress = it },
                            onDone = { success, msg ->
                                isExporting = false
                                if (success) {
                                    exportSuccessDialogMessage = msg
                                    showNotice("Saved to Gallery / Movies")
                                } else {
                                    exportErrorDialogMessage = msg
                                    showNotice("Export failed")
                                }
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(
                        Icons.Default.FileUpload,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "START EXPORT",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showExportDialog = false },
                    modifier = Modifier.height(48.dp)
                ) {
                    Text("CANCEL", color = Color(0xFFAAAAAA), fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }

    // 2. Export Progress Modal Dialog
    if (isExporting) {
        Dialog(
            onDismissRequest = { /* Non-dismissible while active */ },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF14141E)),
                border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E5FF).copy(alpha = 0.15f))
                            .border(1.dp, Color(0xFF00E5FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            progress = { exportProgress },
                            modifier = Modifier.size(36.dp),
                            color = Color(0xFF00E5FF),
                            strokeWidth = 3.dp,
                            trackColor = Color(0xFF222232)
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    Text(
                        "Exporting Video...",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )

                    Spacer(Modifier.height(4.dp))

                    Text(
                        "${selectedExportQuality.label} • ${selectedExportFps} FPS",
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(Modifier.height(20.dp))

                    LinearProgressIndicator(
                        progress = { exportProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = Color(0xFF00E5FF),
                        trackColor = Color(0xFF222232)
                    )

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            if (exportProgress < 0.95f) "Rendering frames..." else "Saving to Movies...",
                            color = Color(0xFFAAAAAA),
                            fontSize = 12.sp
                        )
                        Text(
                            "${(exportProgress * 100).toInt()}%",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    Text(
                        "Please keep the app open while saving",
                        color = Color(0xFF777788),
                        fontSize = 11.sp
                    )
                }
            }
        }
    }

    // 3. Export Success Dialog (Saved to Gallery / Movies confirmation)
    if (exportSuccessDialogMessage != null) {
        AlertDialog(
            onDismissRequest = { exportSuccessDialogMessage = null },
            containerColor = Color(0xFF14141E),
            shape = RoundedCornerShape(18.dp),
            icon = {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00E5FF).copy(alpha = 0.15f))
                        .border(1.dp, Color(0xFF00E5FF), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    "Video Saved!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Saved! Your video is ready in your phone's Gallery / Movies folder.",
                        color = Color(0xFFCCCCCC),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Location: Movies/VideoEditor2050",
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { exportSuccessDialogMessage = null },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00E5FF),
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("DONE", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        )
    }

    // 4. Export Error Dialog (Clear error message)
    if (exportErrorDialogMessage != null) {
        AlertDialog(
            onDismissRequest = { exportErrorDialogMessage = null },
            containerColor = Color(0xFF181418),
            shape = RoundedCornerShape(18.dp),
            icon = {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFF3B30).copy(alpha = 0.15f))
                        .border(1.dp, Color(0xFFFF3B30), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = Color(0xFFFF3B30),
                        modifier = Modifier.size(28.dp)
                    )
                }
            },
            title = {
                Text(
                    "Export Failed",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        exportErrorDialogMessage ?: "Rendering encountered an error.",
                        color = Color(0xFFFFAAAA),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Tip: Select Medium (720p) or Low (480p) or ensure enough free storage space.",
                        color = Color(0xFFAAAAAA),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { exportErrorDialogMessage = null },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF262634),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Text("OK", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
            }
        )
    }
}

@Composable
private fun ToolButton(
    icon: ImageVector,
    label: String,
    accentColor: Color = Color(0xFF00E5FF),
    isHighlighted: Boolean = false,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "toolScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .defaultMinSize(minWidth = 58.dp, minHeight = 64.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(14.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .padding(horizontal = 4.dp, vertical = 3.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF1E2136), Color(0xFF101222))
                    )
                )
                .border(
                    1.2.dp,
                    Brush.verticalGradient(
                        listOf(
                            if (isHighlighted) accentColor else accentColor.copy(alpha = 0.50f),
                            Color(0xFF262A42)
                        )
                    ),
                    RoundedCornerShape(14.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            text = label,
            color = if (isHighlighted) Color.White else Color(0xFFD4D8E8),
            fontSize = 10.sp,
            fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.SemiBold,
            letterSpacing = 0.2.sp,
            maxLines = 1
        )
    }
}
