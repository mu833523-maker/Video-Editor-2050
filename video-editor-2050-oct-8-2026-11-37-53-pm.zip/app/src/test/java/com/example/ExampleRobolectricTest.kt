package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.TrackType
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Video Editor 2050", appName)
  }

  @Test
  fun `clip default values are valid in android environment`() {
    val clip = Clip(title = "Main Clip")
    assertEquals("Main Clip", clip.title)
    assertEquals(TrackType.VIDEO, clip.trackType)
    assertEquals(1.0f, clip.speed, 0.001f)
  }
}
