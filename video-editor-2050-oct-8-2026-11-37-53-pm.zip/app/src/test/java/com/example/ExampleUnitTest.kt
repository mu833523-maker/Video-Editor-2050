package com.example

import com.ve2050.editor.model.TrackType
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun overlayTrackType_isAvailable() {
    val trackType = TrackType.OVERLAY
    assertEquals("Holo Overlay", trackType.label)
    assertEquals("🌌", trackType.icon)
  }
}
