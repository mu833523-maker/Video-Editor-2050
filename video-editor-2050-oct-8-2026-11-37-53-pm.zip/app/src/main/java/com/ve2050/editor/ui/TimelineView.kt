package com.ve2050.editor.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Filter
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.Project
import com.ve2050.editor.model.TimelineTrack
import com.ve2050.editor.model.TrackType
import com.ve2050.editor.model.VideoFilter
import com.ve2050.editor.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun TimelineView(
    clips: List<Clip>,
    selectedIndex: Int,
    overlayUri: android.net.Uri? = null,
    onSelect: (Int) -> Unit,
    onReorder: (Int, Int) -> Unit = { _, _ -> },
    onDeleteOverlay: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        color = Color(0xFF101018),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E2C))
    ) {
        Column(modifier = Modifier.padding(vertical = 6.dp)) {
            // Track Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Movie,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "MAIN TRACK",
                        color = Color(0xFF888899),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    "${clips.size} clips",
                    color = Color(0xFF666677),
                    fontSize = 10.sp
                )
            }

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(clips) { index, clip ->
                    val isSelected = index == selectedIndex
                    Box(
                        modifier = Modifier
                            .width(110.dp)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF181824))
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF282838),
                                shape = RoundedCornerShape(10.dp)
                            )
                            .pointerInput(index) {
                                detectTapGesturesCompat { onSelect(index) }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = clip.uri,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, Color(0xAA000000))
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Clip ${index + 1}",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (clip.speed != 1.0f) {
                                Surface(
                                    color = Color(0xFF00E5FF),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        "${clip.speed}x",
                                        color = Color.Black,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Separate Overlay (PiP) Track on timeline
            if (overlayUri != null) {
                Spacer(Modifier.height(4.dp))
                HorizontalDivider(color = Color(0xFF1E1E2C), thickness = 1.dp)
                Spacer(Modifier.height(4.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Layers,
                            contentDescription = null,
                            tint = Color(0xFFB026FF),
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "OVERLAY TRACK (PIP)",
                            color = Color(0xFFB026FF),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        "1 overlay clip",
                        color = Color(0xFF888899),
                        fontSize = 10.sp
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(110.dp)
                            .height(68.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF1A1228))
                            .border(
                                width = 1.5.dp,
                                color = Color(0xFFB026FF),
                                shape = RoundedCornerShape(10.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = overlayUri,
                            contentDescription = "Overlay preview",
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, Color(0xBB000000))
                                    )
                                )
                        )
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "PiP Clip",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                color = Color(0xFFB026FF),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    "PIP",
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Black,
                                    modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }

                    if (onDeleteOverlay != null) {
                        Spacer(Modifier.width(10.dp))
                        IconButton(
                            onClick = onDeleteOverlay,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                Icons.Default.Delete,
                                contentDescription = "Delete overlay",
                                tint = Color(0xFFFF5555),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// Simple tap helper
private suspend fun androidx.compose.ui.input.pointer.PointerInputScope.detectTapGesturesCompat(
    onTap: () -> Unit
) {
    detectTapGestures(onTap = { onTap() })
}

// Multi-Track Timeline Editor Integration
@Composable
fun TimelineView(
    project: Project,
    currentPositionMs: Long,
    selectedClipId: String?,
    onSeek: (Long) -> Unit,
    onSelectClip: (String?) -> Unit,
    onSplitClip: () -> Unit,
    onDeleteClip: (String) -> Unit,
    onDuplicateClip: (String) -> Unit,
    onChangeSpeed: (String, Float) -> Unit,
    onOpenFilterDialog: (String) -> Unit,
    onAddClipToTrack: (TrackType) -> Unit,
    modifier: Modifier = Modifier
) {
    val primaryTrack = project.tracks.firstOrNull { it.type == TrackType.VIDEO } ?: project.tracks.firstOrNull()
    val clips = primaryTrack?.clips ?: emptyList()
    val selectedIndex = clips.indexOfFirst { it.id == selectedClipId }.let { if (it >= 0) it else 0 }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CyberDarkSurface)
            .border(1.dp, CyberCardBorder)
            .testTag("timeline_view_container")
    ) {
        // Quick Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CyberCardSurface)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onSplitClip,
                    modifier = Modifier.size(36.dp).testTag("action_split_clip")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCut,
                        contentDescription = "Split Clip",
                        tint = HoloCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (selectedClipId != null) {
                    IconButton(
                        onClick = { onDuplicateClip(selectedClipId) },
                        modifier = Modifier.size(36.dp).testTag("action_duplicate_clip")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Duplicate Clip",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { onOpenFilterDialog(selectedClipId) },
                        modifier = Modifier.size(36.dp).testTag("action_filter_clip")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Filter,
                            contentDescription = "Filter",
                            tint = NeonMagenta,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { onChangeSpeed(selectedClipId, 1.5f) },
                        modifier = Modifier.size(36.dp).testTag("action_speed_clip")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Speed 1.5x",
                            tint = SolarAmber,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { onDeleteClip(selectedClipId) },
                        modifier = Modifier.size(36.dp).testTag("action_delete_clip")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Clip",
                            tint = Color(0xFFFF4D4D),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Text(
                text = "${clips.size} CLIPS · ${project.durationMs / 1000}s",
                color = HoloCyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        // Timeline Clip Track Row
        TimelineView(
            clips = clips,
            selectedIndex = selectedIndex,
            onSelect = { idx ->
                val clip = clips.getOrNull(idx)
                onSelectClip(clip?.id)
                clip?.let { onSeek(it.startTimeMs) }
            },
            onReorder = { _, _ -> }
        )
    }
}
