package com.ve2050.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.ve2050.editor.auth.AuthService
import com.ve2050.editor.ui.EditorScreen
import com.ve2050.editor.ui.HomeScreen
import com.ve2050.editor.ui.theme.VE2050Theme

open class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AuthService.isFirebaseReady(this)
        setContent {
            VE2050Theme {
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(onNewProject = { nav.navigate("editor") })
                    }
                    composable("editor") {
                        EditorScreen(onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
