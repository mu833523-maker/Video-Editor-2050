package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.OverlayClip
import com.ve2050.editor.model.OverlayMask
import com.ve2050.editor.model.TrackType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Video Editor 2050", appName)
  }

  @Test
  fun `clip default values are valid in android environment`() {
    val clip = Clip(title = "Main Clip")
    assertEquals("Main Clip", clip.title)
    assertEquals(TrackType.VIDEO, clip.trackType)
    assertEquals(1.0f, clip.speed, 0.001f)
  }

  @Test
  fun `overlay clip default values and properties in android environment`() {
    val overlay = OverlayClip(
      startMs = 1500L,
      durationMs = 4500L,
      scale = 1.25f,
      rotation = 45f,
      opacity = 0.8f,
      mask = OverlayMask.HEART,
      isChromaKeyEnabled = true,
      chromaKeyIntensity = 0.7f
    )
    assertEquals(1500L, overlay.startMs)
    assertEquals(4500L, overlay.durationMs)
    assertEquals(1.25f, overlay.scale, 0.001f)
    assertEquals(45f, overlay.rotation, 0.001f)
    assertEquals(0.8f, overlay.opacity, 0.001f)
    assertEquals(OverlayMask.HEART, overlay.mask)
    assertTrue(overlay.isChromaKeyEnabled)
    assertEquals(0.7f, overlay.chromaKeyIntensity, 0.001f)
  }
}

