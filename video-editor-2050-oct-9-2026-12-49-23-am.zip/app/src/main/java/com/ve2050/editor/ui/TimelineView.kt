package com.ve2050.editor.ui

import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.Project
import com.ve2050.editor.model.TextOverlay
import com.ve2050.editor.model.TimelineTrack
import com.ve2050.editor.model.TrackType
import com.ve2050.editor.model.VideoFilter
import com.ve2050.editor.ui.theme.*
import kotlin.math.roundToInt

@Composable
fun TimelineView(
    clips: List<Clip>,
    selectedIndex: Int,
    currentPositionMs: Long = 0L,
    totalDurationMs: Long = 0L,
    isPlaying: Boolean = false,
    overlayUri: Uri? = null,
    overlayScale: Float = 1f,
    overlayStartMs: Long = 0L,
    overlayDurationMs: Long = 5000L,
    textOverlays: List<TextOverlay> = emptyList(),
    musicUri: Uri? = null,
    musicName: String? = null,
    onSeek: (Long) -> Unit = {},
    onSelect: (Int) -> Unit = {},
    onReorder: (Int, Int) -> Unit = { _, _ -> },
    onTrimClip: (Int, Long, Long) -> Unit = { _, _, _ -> },
    onTrimOverlay: ((Long, Long) -> Unit)? = null,
    onMoveOverlay: ((Long) -> Unit)? = null,
    onSelectOverlay: (() -> Unit)? = null,
    isOverlaySelected: Boolean = false,
    onDeleteOverlay: (() -> Unit)? = null,
    onDeleteMusic: (() -> Unit)? = null,
    onDeleteTextOverlay: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current

    // Zoom state (pixels per second scaling)
    var zoomFactor by remember { mutableFloatStateOf(1f) }
    val baseDpPerSecond = 50f
    val dpPerSecond = (baseDpPerSecond * zoomFactor).coerceIn(22f, 220f)

    // Reorder state
    var draggedClipIndex by remember { mutableStateOf<Int?>(null) }
    var dragAccumulatedX by remember { mutableFloatStateOf(0f) }

    // Scroll state for synchronized multi-track scrolling
    val scrollState = rememberScrollState()

    // Total duration calculation
    val effectiveTotalMs = remember(clips, totalDurationMs) {
        val calculated = clips.sumOf { if (it.durationMs > 0) it.durationMs else 4000L }
        if (totalDurationMs > 0) maxOf(calculated, totalDurationMs) else maxOf(calculated, 10000L)
    }

    // Scrubbing detection & seek callback
    var isUserScrubbing by remember { mutableStateOf(false) }

    // When user scrolls timeline, calculate time under center playhead and seek
    LaunchedEffect(scrollState.value, isUserScrubbing) {
        if (isUserScrubbing || scrollState.isScrollInProgress) {
            val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
            if (pxPerSec > 0) {
                val scrolledTimeMs = ((scrollState.value / pxPerSec) * 1000f).toLong().coerceIn(0L, effectiveTotalMs)
                onSeek(scrolledTimeMs)
            }
        }
    }

    // Auto-scroll when video is playing
    LaunchedEffect(currentPositionMs, isPlaying, dpPerSecond) {
        if (isPlaying && !scrollState.isScrollInProgress) {
            val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
            val targetScrollPx = ((currentPositionMs / 1000f) * pxPerSec).roundToInt()
            scrollState.scrollTo(targetScrollPx)
        }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp),
        color = Color(0xFF0C0C12),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E1E2C))
    ) {
        Column(modifier = Modifier.padding(bottom = 6.dp)) {
            // CapCut Multi-Track Control Header with Zoom & Timecode
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.Movie,
                        contentDescription = null,
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "TIMELINE",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${clips.size} clips · ${effectiveTotalMs / 1000}s",
                        color = Color(0xFF777788),
                        fontSize = 10.sp
                    )
                }

                // Zoom controls & pinch feedback
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { zoomFactor = (zoomFactor - 0.25f).coerceAtLeast(0.5f) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.ZoomOut, contentDescription = "Zoom out", tint = Color(0xFF888899), modifier = Modifier.size(15.dp))
                    }
                    Text(
                        text = "${String.format("%.1f", zoomFactor)}x",
                        color = Color(0xFF00E5FF),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    IconButton(
                        onClick = { zoomFactor = (zoomFactor + 0.25f).coerceAtMost(3.5f) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.ZoomIn, contentDescription = "Zoom in", tint = Color(0xFF888899), modifier = Modifier.size(15.dp))
                    }
                }
            }

            // Timeline Viewport with Fixed Center Playhead
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 180.dp)
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, zoom, _ ->
                            zoomFactor = (zoomFactor * zoom).coerceIn(0.5f, 3.5f)
                        }
                    }
            ) {
                val viewportWidth = maxWidth
                val halfViewportWidth = viewportWidth / 2

                // Horizontally scrollable multi-track container
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(scrollState)
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = {
                                    isUserScrubbing = true
                                    tryAwaitRelease()
                                    isUserScrubbing = false
                                }
                            )
                        }
                ) {
                    Column(
                        modifier = Modifier
                            .padding(start = halfViewportWidth, end = halfViewportWidth)
                            .wrapContentWidth(align = Alignment.Start)
                    ) {
                        // 1. Time Ruler (Seconds & Sub-second ticks)
                        TimeRuler(
                            totalDurationMs = effectiveTotalMs,
                            dpPerSecond = dpPerSecond
                        )

                        Spacer(Modifier.height(4.dp))

                        // 2. Main Video Filmstrip Track
                        Row(
                            modifier = Modifier
                                .height(64.dp)
                                .wrapContentWidth(align = Alignment.Start),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            clips.forEachIndexed { index, clip ->
                                val isSelected = index == selectedIndex
                                val clipDurationMs = if (clip.durationMs > 0) clip.durationMs else 4000L
                                val clipWidthDp = ((clipDurationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(64.dp)
                                val isDraggingThis = draggedClipIndex == index

                                Box(
                                    modifier = Modifier
                                        .width(clipWidthDp)
                                        .fillMaxHeight()
                                        .graphicsLayer {
                                            if (isDraggingThis) {
                                                translationX = dragAccumulatedX
                                                scaleX = 1.05f
                                                scaleY = 1.05f
                                                shadowElevation = 8.dp.toPx()
                                            }
                                        }
                                        .padding(horizontal = 1.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF161622))
                                        .border(
                                            width = if (isSelected || isDraggingThis) 2.dp else 1.dp,
                                            color = if (isDraggingThis) Color(0xFFFFD700) else if (isSelected) Color(0xFF00E5FF) else Color(0xFF242436),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .pointerInput(index, clips.size) {
                                            detectDragGesturesAfterLongPress(
                                                onDragStart = {
                                                    draggedClipIndex = index
                                                    dragAccumulatedX = 0f
                                                    onSelect(index)
                                                },
                                                onDrag = { change, dragAmount ->
                                                    change.consume()
                                                    dragAccumulatedX += dragAmount.x
                                                    val slotThresholdPx = with(density) { 50.dp.toPx() }
                                                    if (dragAccumulatedX > slotThresholdPx && index < clips.lastIndex) {
                                                        onReorder(index, index + 1)
                                                        draggedClipIndex = index + 1
                                                        dragAccumulatedX = 0f
                                                    } else if (dragAccumulatedX < -slotThresholdPx && index > 0) {
                                                        onReorder(index, index - 1)
                                                        draggedClipIndex = index - 1
                                                        dragAccumulatedX = 0f
                                                    }
                                                },
                                                onDragEnd = {
                                                    draggedClipIndex = null
                                                    dragAccumulatedX = 0f
                                                },
                                                onDragCancel = {
                                                    draggedClipIndex = null
                                                    dragAccumulatedX = 0f
                                                }
                                            )
                                        }
                                        .clickable { onSelect(index) }
                                ) {
                                    // Filmstrip thumbnail frames repetition
                                    FilmstripRow(
                                        uri = clip.uri,
                                        widthDp = clipWidthDp
                                    )

                                    // Sprocket border gradient overlay
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.verticalGradient(
                                                    listOf(Color.Black.copy(alpha = 0.5f), Color.Transparent, Color.Black.copy(alpha = 0.7f))
                                                )
                                            )
                                    )

                                    // Clip Info Pill
                                    Row(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .fillMaxWidth()
                                            .padding(horizontal = 6.dp, vertical = 3.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${index + 1}. ${clip.title.take(8)}",
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = "${String.format("%.1f", clipDurationMs / 1000f)}s",
                                            color = Color(0xFF00E5FF),
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    // CapCut Trim Handles on selected clip
                                    if (isSelected && !isDraggingThis) {
                                        // Left Trim Handle
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.CenterStart)
                                                .width(16.dp)
                                                .fillMaxHeight()
                                                .background(Color(0xFF00E5FF), RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp))
                                                .pointerInput(index) {
                                                    detectDragGestures { change, dragAmount ->
                                                        change.consume()
                                                        val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                        if (pxPerSec > 0) {
                                                            val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                            val newStart = (clip.startMs + deltaMs).coerceAtLeast(0L)
                                                            val newDur = (clipDurationMs - deltaMs).coerceAtLeast(800L)
                                                            onTrimClip(index, newStart, newStart + newDur)
                                                        }
                                                    }
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Box(Modifier.size(width = 2.dp, height = 6.dp).background(Color.Black))
                                                Box(Modifier.size(width = 2.dp, height = 6.dp).background(Color.Black))
                                            }
                                        }

                                        // Right Trim Handle
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.CenterEnd)
                                                .width(16.dp)
                                                .fillMaxHeight()
                                                .background(Color(0xFF00E5FF), RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp))
                                                .pointerInput(index) {
                                                    detectDragGestures { change, dragAmount ->
                                                        change.consume()
                                                        val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                        if (pxPerSec > 0) {
                                                            val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                            val newDur = (clipDurationMs + deltaMs).coerceAtLeast(800L)
                                                            onTrimClip(index, clip.startMs, clip.startMs + newDur)
                                                        }
                                                    }
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Box(Modifier.size(width = 2.dp, height = 6.dp).background(Color.Black))
                                                Box(Modifier.size(width = 2.dp, height = 6.dp).background(Color.Black))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // 3. Overlay Track (PiP) - scrolls synchronously with Trim & Move handles
                        if (overlayUri != null) {
                            Spacer(Modifier.height(5.dp))
                            val overlayStartOffsetDp = ((overlayStartMs / 1000f) * dpPerSecond).dp
                            val overlayWidthDp = ((overlayDurationMs / 1000f) * dpPerSecond).dp.coerceAtLeast(80.dp)

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(38.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .offset(x = overlayStartOffsetDp)
                                        .width(overlayWidthDp)
                                        .fillMaxHeight()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0xFF221438))
                                        .border(
                                            width = if (isOverlaySelected) 2.dp else 1.2.dp,
                                            color = if (isOverlaySelected) Color(0xFFE040FB) else Color(0xFFB026FF),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .pointerInput(overlayStartMs, effectiveTotalMs) {
                                            detectDragGestures { change, dragAmount ->
                                                change.consume()
                                                val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                if (pxPerSec > 0) {
                                                    val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                    val maxStart = (effectiveTotalMs - 400L).coerceAtLeast(0L)
                                                    val newStart = (overlayStartMs + deltaMs).coerceIn(0L, maxStart)
                                                    onMoveOverlay?.invoke(newStart)
                                                }
                                            }
                                        }
                                        .clickable { onSelectOverlay?.invoke() }
                                ) {
                                    // Overlay Content row
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .padding(horizontal = 18.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color.Black)
                                        ) {
                                            AsyncImage(
                                                model = overlayUri,
                                                contentDescription = "PiP overlay",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                        Spacer(Modifier.width(6.dp))
                                        Icon(
                                            Icons.Default.Layers,
                                            contentDescription = null,
                                            tint = Color(0xFFE040FB),
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Column {
                                            Text(
                                                text = "PIP OVERLAY",
                                                color = Color.White,
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1
                                            )
                                            Text(
                                                text = "${String.format("%.1f", overlayStartMs / 1000f)}s - ${String.format("%.1f", (overlayStartMs + overlayDurationMs) / 1000f)}s",
                                                color = Color(0xFFCE93D8),
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                        Spacer(Modifier.weight(1f))
                                        if (onDeleteOverlay != null) {
                                            IconButton(onClick = onDeleteOverlay, modifier = Modifier.size(20.dp)) {
                                                Icon(
                                                    Icons.Default.Close,
                                                    contentDescription = "Delete PiP",
                                                    tint = Color(0xFFFF5555),
                                                    modifier = Modifier.size(12.dp)
                                                )
                                            }
                                        }
                                    }

                                    // CapCut Left Trim Handle for Overlay
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.CenterStart)
                                            .width(16.dp)
                                            .fillMaxHeight()
                                            .background(
                                                Color(0xFFB026FF),
                                                RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp)
                                            )
                                            .pointerInput(overlayStartMs, overlayDurationMs) {
                                                detectDragGestures { change, dragAmount ->
                                                    change.consume()
                                                    val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                    if (pxPerSec > 0) {
                                                        val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                        val newStart = (overlayStartMs + deltaMs).coerceAtLeast(0L)
                                                        val newDur = (overlayDurationMs - deltaMs).coerceAtLeast(500L)
                                                        onTrimOverlay?.invoke(newStart, newDur)
                                                    }
                                                }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Box(Modifier.size(width = 2.dp, height = 6.dp).background(Color.White))
                                            Box(Modifier.size(width = 2.dp, height = 6.dp).background(Color.White))
                                        }
                                    }

                                    // CapCut Right Trim Handle for Overlay
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.CenterEnd)
                                            .width(16.dp)
                                            .fillMaxHeight()
                                            .background(
                                                Color(0xFFB026FF),
                                                RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp)
                                            )
                                            .pointerInput(overlayStartMs, overlayDurationMs) {
                                                detectDragGestures { change, dragAmount ->
                                                    change.consume()
                                                    val pxPerSec = with(density) { dpPerSecond.dp.toPx() }
                                                    if (pxPerSec > 0) {
                                                        val deltaMs = ((dragAmount.x / pxPerSec) * 1000f).toLong()
                                                        val newDur = (overlayDurationMs + deltaMs).coerceAtLeast(500L)
                                                        onTrimOverlay?.invoke(overlayStartMs, newDur)
                                                    }
                                                }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                            Box(Modifier.size(width = 2.dp, height = 6.dp).background(Color.White))
                                            Box(Modifier.size(width = 2.dp, height = 6.dp).background(Color.White))
                                        }
                                    }
                                }
                            }
                        }

                        // 4. Text Overlays Track - scrolls synchronously
                        if (textOverlays.isNotEmpty()) {
                            Spacer(Modifier.height(4.dp))
                            Row(
                                modifier = Modifier
                                    .wrapContentWidth(align = Alignment.Start)
                                    .height(28.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                textOverlays.forEach { textOverlay ->
                                    val overlayDur = if (textOverlay.endMs > textOverlay.startMs && textOverlay.endMs < Long.MAX_VALUE)
                                        textOverlay.endMs - textOverlay.startMs
                                    else effectiveTotalMs
                                    val textWidthDp = ((overlayDur / 1000f) * dpPerSecond).dp.coerceIn(60.dp, 280.dp)

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .width(textWidthDp)
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF0F2630))
                                            .border(1.dp, Color(0xFF00F0FF), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 6.dp)
                                    ) {
                                        Icon(Icons.Default.TextFields, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(12.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            text = textOverlay.text,
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (onDeleteTextOverlay != null) {
                                            IconButton(onClick = { onDeleteTextOverlay(textOverlay.id) }, modifier = Modifier.size(18.dp)) {
                                                Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFFAAAAAA), modifier = Modifier.size(10.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // 5. Audio Track - scrolls synchronously with waveform
                        if (musicUri != null) {
                            Spacer(Modifier.height(4.dp))
                            val audioWidthDp = ((effectiveTotalMs / 1000f) * dpPerSecond).dp.coerceAtLeast(80.dp)

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .width(audioWidthDp)
                                    .height(30.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF0B2418))
                                    .border(1.dp, Color(0xFF00FF88).copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                    .padding(horizontal = 6.dp)
                            ) {
                                Icon(Icons.Default.MusicNote, contentDescription = null, tint = Color(0xFF00FF88), modifier = Modifier.size(12.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = musicName ?: "Audio Track",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f)
                                )

                                // Simulated Audio Waveform Bar across track
                                Canvas(modifier = Modifier.width(60.dp).height(12.dp)) {
                                    val barWidth = 3f
                                    val gap = 2f
                                    var x = 0f
                                    var i = 0
                                    while (x < size.width) {
                                        val h = ((i * 7 + 11) % 10 + 2).toFloat()
                                        drawRect(
                                            color = Color(0xFF00FF88),
                                            topLeft = Offset(x, size.height - h),
                                            size = Size(barWidth, h)
                                        )
                                        x += barWidth + gap
                                        i++
                                    }
                                }

                                if (onDeleteMusic != null) {
                                    Spacer(Modifier.width(4.dp))
                                    IconButton(onClick = onDeleteMusic, modifier = Modifier.size(18.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Delete Audio", tint = Color(0xFFFF5555), modifier = Modifier.size(10.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                // Fixed CapCut Center Playhead Line with Diamond/Inverted Triangle Cursor
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(2.dp)
                        .align(Alignment.Center)
                        .background(Color.White)
                        .shadow(4.dp, shape = RoundedCornerShape(1.dp))
                )

                // Diamond Top Cursor for Playhead
                PlayheadCursor(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .offset(y = 0.dp)
                )
            }
        }
    }
}

// CapCut Filmstrip repeating frames inside each clip
@Composable
private fun FilmstripRow(
    uri: Uri,
    widthDp: androidx.compose.ui.unit.Dp
) {
    val frameWidth = 44.dp
    val frameCount = (widthDp / frameWidth).toInt().coerceAtLeast(1)

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.Start
    ) {
        repeat(frameCount) {
            Box(
                modifier = Modifier
                    .width(frameWidth)
                    .fillMaxHeight()
                    .border(width = 0.5.dp, color = Color(0x33000000))
            ) {
                AsyncImage(
                    model = uri,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
        }
    }
}

// CapCut Top Ruler with seconds and ticks
@Composable
private fun TimeRuler(
    totalDurationMs: Long,
    dpPerSecond: Float
) {
    val totalSeconds = (totalDurationMs / 1000f).toInt().coerceAtLeast(1)
    val totalWidthDp = (totalSeconds * dpPerSecond).dp

    Box(
        modifier = Modifier
            .width(totalWidthDp)
            .height(20.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val pxPerSec = (dpPerSecond * density)
            for (sec in 0..totalSeconds) {
                val x = sec * pxPerSec
                // Major tick line
                drawLine(
                    color = Color(0xFF6E6E78),
                    start = Offset(x, 10f),
                    end = Offset(x, size.height),
                    strokeWidth = 1.5f
                )
                // Half second minor tick
                if (pxPerSec > 35f && sec < totalSeconds) {
                    val halfX = x + pxPerSec / 2f
                    drawLine(
                        color = Color(0xFF3E3E48),
                        start = Offset(halfX, 16f),
                        end = Offset(halfX, size.height),
                        strokeWidth = 1f
                    )
                }
            }
        }

        // Time labels
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Start
        ) {
            val step = if (dpPerSecond < 35f) 2 else 1
            for (sec in 0..totalSeconds step step) {
                Box(
                    modifier = Modifier
                        .width((step * dpPerSecond).dp)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.TopStart
                ) {
                    val mins = sec / 60
                    val s = sec % 60
                    Text(
                        text = String.format("%02d:%02d", mins, s),
                        color = Color(0xFF8E8E98),
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.offset(x = 2.dp, y = (-2).dp)
                    )
                }
            }
        }
    }
}

// CapCut Inverted Triangle / Diamond Playhead Cursor
@Composable
private fun PlayheadCursor(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(width = 12.dp, height = 8.dp)) {
        val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(size.width, 0f)
            lineTo(size.width / 2f, size.height)
            close()
        }
        drawPath(path = path, color = Color.White)
    }
}

// Simple tap helper
private suspend fun androidx.compose.ui.input.pointer.PointerInputScope.detectTapGesturesCompat(
    onTap: () -> Unit
) {
    detectTapGestures(onTap = { onTap() })
}

// Multi-Track Timeline Editor Integration (Overload for backward compatibility)
@Composable
fun TimelineView(
    project: Project,
    currentPositionMs: Long,
    selectedClipId: String?,
    onSeek: (Long) -> Unit,
    onSelectClip: (String?) -> Unit,
    onSplitClip: () -> Unit,
    onDeleteClip: (String) -> Unit,
    onDuplicateClip: (String) -> Unit,
    onChangeSpeed: (String, Float) -> Unit,
    onOpenFilterDialog: (String) -> Unit,
    onAddClipToTrack: (TrackType) -> Unit,
    modifier: Modifier = Modifier
) {
    val primaryTrack = project.tracks.firstOrNull { it.type == TrackType.VIDEO } ?: project.tracks.firstOrNull()
    val clips = primaryTrack?.clips ?: emptyList()
    val selectedIndex = clips.indexOfFirst { it.id == selectedClipId }.let { if (it >= 0) it else 0 }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(CyberDarkSurface)
            .border(1.dp, CyberCardBorder)
            .testTag("timeline_view_container")
    ) {
        // Quick Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CyberCardSurface)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onSplitClip,
                    modifier = Modifier.size(36.dp).testTag("action_split_clip")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCut,
                        contentDescription = "Split Clip",
                        tint = HoloCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (selectedClipId != null) {
                    IconButton(
                        onClick = { onDuplicateClip(selectedClipId) },
                        modifier = Modifier.size(36.dp).testTag("action_duplicate_clip")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Duplicate Clip",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { onOpenFilterDialog(selectedClipId) },
                        modifier = Modifier.size(36.dp).testTag("action_filter_clip")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Filter,
                            contentDescription = "Filter",
                            tint = NeonMagenta,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { onChangeSpeed(selectedClipId, 1.5f) },
                        modifier = Modifier.size(36.dp).testTag("action_speed_clip")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Speed 1.5x",
                            tint = SolarAmber,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { onDeleteClip(selectedClipId) },
                        modifier = Modifier.size(36.dp).testTag("action_delete_clip")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Clip",
                            tint = Color(0xFFFF4D4D),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Text(
                text = "${clips.size} CLIPS · ${project.durationMs / 1000}s",
                color = HoloCyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        // Timeline Clip Track Row
        TimelineView(
            clips = clips,
            selectedIndex = selectedIndex,
            currentPositionMs = currentPositionMs,
            totalDurationMs = project.durationMs,
            onSeek = onSeek,
            onSelect = { idx ->
                val clip = clips.getOrNull(idx)
                onSelectClip(clip?.id)
                clip?.let { onSeek(it.startTimeMs) }
            },
            onReorder = { _, _ -> }
        )
    }
}

