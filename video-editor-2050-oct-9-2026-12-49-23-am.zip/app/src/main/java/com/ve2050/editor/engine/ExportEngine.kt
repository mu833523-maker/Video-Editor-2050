package com.ve2050.editor.engine

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.*
import com.ve2050.editor.model.Clip
import com.ve2050.editor.model.TextOverlay
import kotlinx.coroutines.*
import java.io.File
import java.io.FileInputStream

@UnstableApi
object ExportEngine {

    fun export(
        context: Context,
        clips: List<Clip>,
        textOverlays: List<TextOverlay>,
        musicUri: Uri?,
        overlayUri: Uri? = null,
        overlayScale: Float = 0.5f,
        overlayRotation: Float = 0f,
        overlayStartMs: Long = 0L,
        overlayDurationMs: Long = 0L,
        onProgress: (Float) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        if (clips.isEmpty()) {
            onDone(false, "No clips to export")
            return
        }

        val outputFile = File(context.cacheDir, "ve2050_${System.currentTimeMillis()}.mp4")

        val editedItems = clips.map { clip ->
            val builder = MediaItem.Builder().setUri(clip.uri)
            if (clip.endMs > clip.startMs) {
                builder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(clip.startMs)
                        .setEndPositionMs(clip.endMs)
                        .build()
                )
            }
            EditedMediaItem.Builder(builder.build()).build()
        }

        val videoSequence = EditedMediaItemSequence(editedItems)
        val sequences = mutableListOf(videoSequence)

        if (overlayUri != null && overlayUri != Uri.EMPTY) {
            val overlayBuilder = MediaItem.Builder().setUri(overlayUri)
            if (overlayDurationMs > 0L) {
                overlayBuilder.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(overlayStartMs.coerceAtLeast(0L))
                        .setEndPositionMs((overlayStartMs + overlayDurationMs).coerceAtLeast(500L))
                        .build()
                )
            }
            val overlayMediaItem = overlayBuilder.build()
            val scaleEffect = ScaleAndRotateTransformation.Builder()
                .setScale(overlayScale.coerceIn(0.2f, 2.5f), overlayScale.coerceIn(0.2f, 2.5f))
                .setRotationDegrees(overlayRotation)
                .build()
            val overlayEditedItem = EditedMediaItem.Builder(overlayMediaItem)
                .setEffects(Effects(emptyList(), listOf(scaleEffect)))
                .build()
            sequences.add(EditedMediaItemSequence(listOf(overlayEditedItem)))
        }

        if (musicUri != null && musicUri != Uri.EMPTY) {
            val audioMediaItem = MediaItem.Builder().setUri(musicUri).build()
            val audioEditedItem = EditedMediaItem.Builder(audioMediaItem).build()
            sequences.add(EditedMediaItemSequence(listOf(audioEditedItem)))
        }

        val composition = Composition.Builder(sequences).build()

        var progressJob: Job? = null

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, r: ExportResult) {
                    progressJob?.cancel()
                    CoroutineScope(Dispatchers.Main).launch {
                        onProgress(1f)
                        val uri = withContext(Dispatchers.IO) { saveToGallery(context, outputFile) }
                        outputFile.delete()
                        if (uri != null) onDone(true, "Video exported & saved to Gallery! 🎬")
                        else onDone(false, "Failed to save into Gallery")
                    }
                }
                override fun onError(c: Composition, r: ExportResult, e: ExportException) {
                    progressJob?.cancel()
                    outputFile.delete()
                    onDone(false, "Export error: ${e.message}")
                }
            })
            .build()

        progressJob = CoroutineScope(Dispatchers.Main).launch {
            val progressHolder = ProgressHolder()
            while (isActive) {
                delay(200)
                val state = transformer.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(progressHolder.progress / 100f)
                }
            }
        }

        try {
            transformer.start(composition, outputFile.absolutePath)
        } catch (e: Exception) {
            progressJob.cancel()
            outputFile.delete()
            onDone(false, "Start error: ${e.message}")
        }
    }

    fun export(
        context: Context,
        clips: List<Clip>,
        onProgress: (Float) -> Unit,
        onDone: (Boolean, String) -> Unit
    ) {
        export(
            context = context,
            clips = clips,
            textOverlays = emptyList(),
            musicUri = null,
            overlayUri = null,
            overlayScale = 0.5f,
            onProgress = onProgress,
            onDone = onDone
        )
    }

    private fun saveToGallery(context: Context, file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VE2050_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoEditor2050")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val resolver = context.contentResolver
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val uri = resolver.insert(collection, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(file).use { it.copyTo(out) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.update(uri, ContentValues().apply {
                    put(MediaStore.Video.Media.IS_PENDING, 0)
                }, null, null)
            }
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }
}
